import { useState, useEffect, useCallback } from 'react';
import { auth, userApi }            from './lib/supabase.js';
import { initPi }                   from './lib/pi.js';
import { companiesApi, subscriptionsApi, loadCompanyState } from './lib/api.js';
import AuthScreen        from './components/AuthScreen.jsx';
import CompanySelector   from './components/CompanySelector.jsx';
import SubscriptionModal from './components/SubscriptionModal.jsx';
import AppAccounting     from './AppAccounting.jsx';

// ─── ÉTATS GLOBAUX ───────────────────────────────────────────
const STAGE = {
  LOADING:  'loading',
  AUTH:     'auth',
  COMPANY:  'company',
  APP:      'app',
};

export default function AppWeb3() {
  const [stage,        setStage]        = useState(STAGE.LOADING);
  const [authUser,     setAuthUser]     = useState(null);
  const [profile,      setProfile]      = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [companies,    setCompanies]    = useState([]);
  const [company,      setCompany]      = useState(null);
  const [appState,     setAppState]     = useState(null);
  const [loadingMsg,   setLoadingMsg]   = useState('Initialisation...');
  const [showSub,      setShowSub]      = useState(false);
  const [piReady,      setPiReady]      = useState(false);

  // ─── INIT Pi SDK ──────────────────────────────────────────
  useEffect(() => {
    const ok = initPi();
    setPiReady(ok);
  }, []);

  // ─── VÉRIFIER SESSION AU DÉMARRAGE ───────────────────────
  useEffect(() => {
    const boot = async () => {
      const session = await auth.getSession();
      if (session?.user) {
        await loadUserData(session.user);
      } else {
        setStage(STAGE.AUTH);
      }
    };
    boot();

    const sub = auth.onAuthChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        await loadUserData(session.user);
      } else if (event === 'SIGNED_OUT') {
        resetState();
      }
    });
    return () => sub.unsubscribe();
  }, []);

  // ─── CHARGER DONNÉES UTILISATEUR ─────────────────────────
  const loadUserData = async (user) => {
    setStage(STAGE.LOADING);
    setLoadingMsg('Chargement du profil...');
    setAuthUser(user);

    try {
      const { data: prof } = await userApi.getProfile();
      setProfile(prof);

      setLoadingMsg('Vérification abonnement...');
      const { data: sub } = await subscriptionsApi.getActive();
      setSubscription(sub);

      setLoadingMsg('Chargement des entreprises...');
      const { data: cos } = await companiesApi.list();
      setCompanies(cos || []);

      // Si l'utilisateur n'a pas d'abonnement actif et pas de trial
      if (!sub && (!cos || cos.length === 0)) {
        setStage(STAGE.AUTH);
        setShowSub(true);
      } else if (cos && cos.length === 1) {
        await openCompany(cos[0]);
      } else {
        setStage(STAGE.COMPANY);
      }
    } catch (err) {
      console.error('Erreur chargement:', err);
      setStage(STAGE.AUTH);
    }
  };

  // ─── OUVRIR UNE ENTREPRISE ────────────────────────────────
  const openCompany = useCallback(async (co) => {
    setStage(STAGE.LOADING);
    setLoadingMsg(`Ouverture de ${co.nomEntreprise}...`);
    try {
      const state = await loadCompanyState(co.id);
      setCompany(co);
      setAppState(state);
      setStage(STAGE.APP);
    } catch (err) {
      console.error(err);
      setStage(STAGE.COMPANY);
    }
  }, []);

  // ─── DÉCONNEXION ─────────────────────────────────────────
  const handleLogout = useCallback(async () => {
    await auth.signOut();
    resetState();
  }, []);

  // ─── CHANGER D'ENTREPRISE ────────────────────────────────
  const handleSwitchCompany = useCallback(async () => {
    const { data: cos } = await companiesApi.list();
    setCompanies(cos || []);
    setStage(STAGE.COMPANY);
    setCompany(null);
    setAppState(null);
  }, []);

  // ─── ABONNEMENT SOUSCRIT ─────────────────────────────────
  const handleSubscribed = useCallback(async (plan) => {
    setShowSub(false);
    // Recharger l'abonnement
    const { data: sub } = await subscriptionsApi.getActive();
    setSubscription(sub);
    // Continuer vers sélection entreprise si nécessaire
    if (!company) {
      const { data: cos } = await companiesApi.list();
      setCompanies(cos || []);
      setStage(companies.length > 0 ? STAGE.COMPANY : STAGE.COMPANY);
    }
  }, [company, companies]);

  // ─── RESET ───────────────────────────────────────────────
  const resetState = () => {
    setAuthUser(null); setProfile(null); setSubscription(null);
    setCompanies([]); setCompany(null); setAppState(null);
    setStage(STAGE.AUTH);
  };

  // ─── BADGE ABONNEMENT pour AppAccounting ─────────────────
  const subscriptionBadge = subscription ? {
    plan:      subscription.plan,
    expiresAt: subscription.expiresAt,
    daysLeft:  Math.max(0, Math.ceil((new Date(subscription.expiresAt) - Date.now()) / 86400000)),
  } : null;

  // ═════════════════════════════════════════════════════════
  //  RENDU
  // ═════════════════════════════════════════════════════════

  // Chargement
  if (stage === STAGE.LOADING) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',background:'var(--void)',gap:16,position:'relative',zIndex:1}}>
      <div style={{position:'fixed',inset:0,backgroundImage:'linear-gradient(var(--b1) 1px,transparent 1px),linear-gradient(90deg,var(--b1) 1px,transparent 1px)',backgroundSize:'40px 40px',opacity:.3,zIndex:0}}/>
      <div style={{
        width:56,height:56,
        background:'rgba(0,229,255,.1)',border:'1px solid var(--cyan2)',
        clipPath:'polygon(8px 0%,100% 0%,100% calc(100% - 8px),calc(100% - 8px) 100%,0% 100%,0% 8px)',
        display:'flex',alignItems:'center',justifyContent:'center',
        fontFamily:'var(--fh)',fontWeight:700,fontSize:22,color:'var(--cyan)',
        animation:'glow 2s ease-in-out infinite',position:'relative',zIndex:1,
      }}>NX</div>
      <div style={{fontFamily:'var(--fm)',fontSize:11,color:'var(--tx3)',letterSpacing:'2px',textTransform:'uppercase',position:'relative',zIndex:1}}>
        {loadingMsg}
      </div>
      <style>{`@keyframes glow{0%,100%{box-shadow:0 0 20px rgba(0,229,255,.3)}50%{box-shadow:0 0 40px rgba(0,229,255,.6)}}`}</style>
    </div>
  );

  // Auth
  if (stage === STAGE.AUTH) return (
    <>
      <AuthScreen onAuth={loadUserData} piReady={piReady}/>
      {showSub && profile && (
        <SubscriptionModal
          user={profile}
          subscription={null}
          companyId={null}
          onClose={()=>setShowSub(false)}
          onSubscribed={handleSubscribed}
        />
      )}
    </>
  );

  // Sélection entreprise
  if (stage === STAGE.COMPANY) return (
    <>
      <CompanySelector
        companies={companies}
        subscription={subscription}
        user={profile}
        onSelect={openCompany}
        onCreated={async (co) => {
          const { data: cos } = await companiesApi.list();
          setCompanies(cos || []);
          await openCompany(co);
        }}
        onSubscribe={()=>setShowSub(true)}
      />
      {showSub && (
        <SubscriptionModal
          user={profile}
          subscription={subscription}
          companyId={null}
          onClose={()=>setShowSub(false)}
          onSubscribed={handleSubscribed}
        />
      )}
    </>
  );

  // Application comptable
  if (stage === STAGE.APP && appState) return (
    <>
      <AppAccounting
        initialState={appState}
        companyId={company.id}
        user={profile}
        subscription={subscriptionBadge}
        piReady={piReady}
        onLogout={handleLogout}
        onSwitchCompany={handleSwitchCompany}
        onSubscribe={()=>setShowSub(true)}
      />
      {showSub && (
        <SubscriptionModal
          user={profile}
          subscription={subscription}
          companyId={company.id}
          onClose={()=>setShowSub(false)}
          onSubscribed={handleSubscribed}
        />
      )}
    </>
  );

  return null;
}
