import { useState } from 'react';
import { auth } from '../lib/supabase.js';

// ─── ÉCRAN D'AUTHENTIFICATION ─────────────────────────────────
export default function AuthScreen({ onAuth }) {
  const [mode, setMode]       = useState('login');     // login | signup | magic
  const [email, setEmail]     = useState('');
  const [password, setPass]   = useState('');
  const [name, setName]       = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const [sent, setSent]       = useState(false);

  const handle = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (mode === 'magic') {
        const { error: err } = await auth.signInWithMagicLink(email);
        if (err) throw err;
        setSent(true);
      } else if (mode === 'signup') {
        const { error: err } = await auth.signUp(email, password, name);
        if (err) throw err;
        setSent(true);
      } else {
        const { data, error: err } = await auth.signIn(email, password);
        if (err) throw err;
        onAuth(data.user);
      }
    } catch (err) {
      setError(err.message || 'Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  if (sent) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh',background:'var(--void)'}}>
      <div style={CARD}>
        <div style={{fontSize:'2rem',marginBottom:16,textAlign:'center'}}>📧</div>
        <div style={TITLE}>Vérifiez votre email</div>
        <div style={SUB}>Un lien de connexion a été envoyé à <strong style={{color:'var(--cyan)'}}>{email}</strong>. Cliquez dessus pour accéder à Africompta.</div>
        <button style={{...BTN,marginTop:20,width:'100%'}} onClick={()=>setSent(false)}>← Retour</button>
      </div>
    </div>
  );

  return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100vh',background:'var(--void)',position:'relative',zIndex:1}}>
      {/* Grille de fond */}
      <div style={{position:'fixed',inset:0,backgroundImage:'linear-gradient(var(--b1) 1px,transparent 1px),linear-gradient(90deg,var(--b1) 1px,transparent 1px)',backgroundSize:'40px 40px',opacity:.3,zIndex:0}}/>

      <div style={{...CARD,position:'relative',zIndex:1}}>
        {/* Logo */}
        <div style={{textAlign:'center',marginBottom:24}}>
          <div style={{
            width:52,height:52,margin:'0 auto 12px',
            background:'rgba(0,229,255,.1)',border:'1px solid var(--cyan2)',
            clipPath:'polygon(8px 0%,100% 0%,100% calc(100% - 8px),calc(100% - 8px) 100%,0% 100%,0% 8px)',
            display:'flex',alignItems:'center',justifyContent:'center',
            fontFamily:'var(--fh)',fontWeight:700,fontSize:20,color:'var(--cyan)',
            boxShadow:'0 0 20px rgba(0,229,255,.2)',
          }}>NX</div>
          <div style={{fontFamily:'var(--fh)',fontSize:'1.6rem',fontWeight:700,color:'var(--tx)',letterSpacing:2,textTransform:'uppercase'}}>
            Afri<span style={{color:'var(--cyan)'}}>compta</span>
          </div>
          <div style={{fontSize:10,color:'var(--tx4)',fontFamily:'var(--fm)',letterSpacing:'3px',marginTop:4,textTransform:'uppercase'}}>
            NEXUS · Comptabilité Web3
          </div>
        </div>

        {/* Tabs mode */}
        <div style={{display:'flex',gap:2,background:'rgba(8,20,40,.8)',border:'1px solid var(--b2)',padding:3,marginBottom:20,
          clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))'}}>
          {[['login','Connexion'],['signup','Inscription'],['magic','Magic Link']].map(([m,l])=>(
            <button key={m} onClick={()=>{setMode(m);setError('');}} style={{
              flex:1,padding:'7px 8px',border:'1px solid transparent',background:mode===m?'var(--cyan-g)':'transparent',
              color:mode===m?'var(--cyan)':'var(--tx3)',fontFamily:'var(--fm)',fontSize:10,cursor:'pointer',
              textTransform:'uppercase',letterSpacing:'1.5px',transition:'all .15s',
              ...(mode===m?{borderColor:'rgba(0,229,255,.2)',boxShadow:'0 0 8px rgba(0,229,255,.08)'}:{}),
            }}>{l}</button>
          ))}
        </div>

        <form onSubmit={handle}>
          {mode === 'signup' && (
            <div style={{marginBottom:14}}>
              <label style={LBL}>Nom complet</label>
              <input value={name} onChange={e=>setName(e.target.value)} placeholder="Jean-Baptiste Koffi" required style={INP}/>
            </div>
          )}
          <div style={{marginBottom:14}}>
            <label style={LBL}>Email</label>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="contact@monentreprise.com" required style={INP}/>
          </div>
          {mode !== 'magic' && (
            <div style={{marginBottom:20}}>
              <label style={LBL}>Mot de passe</label>
              <input type="password" value={password} onChange={e=>setPass(e.target.value)} placeholder="••••••••" required minLength={6} style={INP}/>
            </div>
          )}
          {error && (
            <div style={{background:'rgba(255,23,68,.1)',border:'1px solid rgba(255,23,68,.3)',color:'#ff5252',padding:'8px 12px',fontSize:12,fontFamily:'var(--fm)',marginBottom:14,
              clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)'}}>
              ⚠ {error}
            </div>
          )}
          <button type="submit" disabled={loading} style={{...BTN,width:'100%',justifyContent:'center',opacity:loading?.6:1}}>
            {loading ? '...' : mode==='signup' ? 'Créer le compte' : mode==='magic' ? 'Envoyer le lien' : 'Se connecter'}
          </button>
        </form>

        <div style={{marginTop:20,padding:'14px',background:'rgba(0,229,255,.04)',border:'1px solid rgba(0,229,255,.1)',
          clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))'}}>
          <div style={{fontSize:10,color:'var(--cyan)',fontFamily:'var(--fm)',letterSpacing:'2px',textTransform:'uppercase',marginBottom:6}}>
            Pi Network (Phase 3)
          </div>
          <div style={{fontSize:11.5,color:'var(--tx3)',lineHeight:1.6}}>
            L'authentification Pi Network sera disponible après soumission de l'app sur le portail développeur Pi.
          </div>
        </div>
      </div>
    </div>
  );
}

// Styles inline NEXUS
const CARD = {
  background:'rgba(11,26,53,.95)',border:'1px solid var(--b3)',padding:'28px 30px',
  width:'100%',maxWidth:420,
  clipPath:'polygon(0 0,calc(100% - 20px) 0,100% 20px,100% 100%,20px 100%,0 calc(100% - 20px))',
  backdropFilter:'blur(24px)',boxShadow:'0 0 60px rgba(0,229,255,.06),0 20px 60px rgba(0,0,0,.8)',
};
const TITLE = {fontFamily:'var(--fh)',fontSize:'1.3rem',fontWeight:700,color:'var(--tx)',textAlign:'center',textTransform:'uppercase',letterSpacing:2,marginBottom:8};
const SUB   = {fontSize:13,color:'var(--tx2)',textAlign:'center',lineHeight:1.7};
const LBL   = {display:'block',fontSize:9,fontWeight:600,color:'var(--tx3)',textTransform:'uppercase',letterSpacing:'2px',fontFamily:'var(--fm)',marginBottom:5};
const INP   = {
  display:'block',width:'100%',background:'var(--cosmos)',border:'1px solid var(--b2)',
  padding:'9px 12px',color:'var(--tx)',fontFamily:'var(--fm)',fontSize:12,outline:'none',
  clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)',
};
const BTN   = {
  display:'inline-flex',alignItems:'center',gap:8,padding:'9px 18px',
  background:'var(--cyan-g)',border:'1px solid var(--cyan2)',color:'var(--cyan)',
  fontFamily:'var(--fh)',fontSize:12,fontWeight:600,cursor:'pointer',
  textTransform:'uppercase',letterSpacing:'2px',transition:'all .15s',
  clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)',
  boxShadow:'0 0 12px rgba(0,229,255,.15)',
};
