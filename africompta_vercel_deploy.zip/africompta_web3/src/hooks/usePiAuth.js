import { useState, useCallback } from 'react';
import { authenticatePi, isPiAvailable } from '../lib/pi.js';
import { supabase }                       from '../lib/supabase.js';

// ─── HOOK : Authentification Pi Network ──────────────────────
export default function usePiAuth() {
  const [piUser,   setPiUser]   = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState('');

  const login = useCallback(async () => {
    setLoading(true);
    setError('');

    try {
      // 1. Authentifier avec Pi Network
      const { user: piU, accessToken } = await authenticatePi();

      // 2. Créer / récupérer l'utilisateur Supabase via Pi username
      //    On utilise un email fictif unique basé sur le Pi username
      const fakeEmail = `${piU.username}@pi.africompta.app`;
      const fakePass  = 'pi_' + piU.uid; // Mot de passe déterministe

      // Tenter la connexion d'abord
      let { data, error: signInErr } = await supabase.auth.signInWithPassword({
        email:    fakeEmail,
        password: fakePass,
      });

      // Si l'utilisateur n'existe pas → créer le compte
      if (signInErr?.message?.includes('Invalid login credentials')) {
        const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
          email:    fakeEmail,
          password: fakePass,
          options:  {
            data: {
              display_name: piU.username,
              pi_username:  piU.username,
              pi_uid:       piU.uid,
            },
            emailRedirectTo: undefined, // Pas de confirmation email
          },
        });
        if (signUpErr) throw signUpErr;
        data = signUpData;
      } else if (signInErr) {
        throw signInErr;
      }

      // 3. Mettre à jour pi_username dans la table users
      if (data?.user) {
        await supabase
          .from('users')
          .update({
            pi_username:  piU.username,
            display_name: piU.username,
          })
          .eq('auth_id', data.user.id);
      }

      setPiUser({ ...piU, accessToken });
      return { user: data?.user, piUser: piU };

    } catch (err) {
      const msg = err.message || 'Erreur d\'authentification Pi';
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return { piUser, loading, error, login, isPiAvailable: isPiAvailable() };
}
