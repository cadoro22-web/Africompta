-- ═══════════════════════════════════════════════════════════════
--  AFRICOMPTA — SCHÉMA SUPABASE MULTI-TENANT
--  Version Web3 avec Pi Network
--  Chaque entreprise est isolée par Row Level Security
-- ═══════════════════════════════════════════════════════════════

-- Extensions nécessaires
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── 1. UTILISATEURS (Pi Network ou Email) ─────────────────────
CREATE TABLE IF NOT EXISTS public.users (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  auth_id      UUID UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  pi_username  TEXT UNIQUE,          -- identifiant Pi Network
  email        TEXT,
  display_name TEXT,
  plan         TEXT NOT NULL DEFAULT 'starter'
               CHECK (plan IN ('starter', 'business', 'enterprise')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 2. ABONNEMENTS ────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.subscriptions (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  plan            TEXT NOT NULL CHECK (plan IN ('starter', 'business', 'enterprise')),
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active', 'expired', 'cancelled', 'trial')),
  starts_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at      TIMESTAMPTZ NOT NULL,
  -- Pi Network payment info
  pi_payment_id   TEXT,
  pi_txid         TEXT,
  amount_pi       NUMERIC(10,2),
  -- Mobile Money fallback
  mobile_money_ref TEXT,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 3. ENTREPRISES (multi-tenant) ─────────────────────────────
CREATE TABLE IF NOT EXISTS public.companies (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  owner_id        UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  nom_entreprise  TEXT NOT NULL,
  adresse         TEXT DEFAULT '',
  telephone       TEXT DEFAULT '',
  email           TEXT DEFAULT '',
  sigle           TEXT DEFAULT '',
  rccm            TEXT DEFAULT '',
  ifu             TEXT DEFAULT '',
  plan_comptable  TEXT NOT NULL DEFAULT 'OHADA'
                  CHECK (plan_comptable IN ('OHADA', 'PCG')),
  devise          TEXT NOT NULL DEFAULT 'FCFA',
  taux_tva        NUMERIC(5,2) NOT NULL DEFAULT 18,
  exercice_debut  DATE NOT NULL DEFAULT '2025-01-01',
  exercice_fin    DATE NOT NULL DEFAULT '2025-12-31',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 4. PLAN COMPTABLE ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.comptes (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  code        TEXT NOT NULL,
  libelle     TEXT NOT NULL,
  classe      TEXT NOT NULL,
  type        TEXT NOT NULL CHECK (type IN ('actif','passif','charge','produit','autre')),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, code)
);

-- ─── 5. ARTICLES / STOCKS ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.articles (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  code        TEXT NOT NULL,
  designation TEXT NOT NULL,
  categorie   TEXT DEFAULT '',
  unite       TEXT DEFAULT 'pièce',
  prix_achat  NUMERIC(15,2) NOT NULL DEFAULT 0,
  prix_vente  NUMERIC(15,2) NOT NULL DEFAULT 0,
  stock       NUMERIC(15,3) NOT NULL DEFAULT 0,
  stock_min   NUMERIC(15,3) NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, code)
);

CREATE TABLE IF NOT EXISTS public.mouvements_stock (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  article_id  UUID NOT NULL REFERENCES public.articles(id) ON DELETE CASCADE,
  date        DATE NOT NULL,
  type        TEXT NOT NULL CHECK (type IN ('entree', 'sortie')),
  qte         NUMERIC(15,3) NOT NULL,
  motif       TEXT DEFAULT '',
  ref         TEXT DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 6. SERVICES ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.services (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  code            TEXT NOT NULL,
  designation     TEXT NOT NULL,
  unite           TEXT DEFAULT 'heure',
  prix_unitaire   NUMERIC(15,2) NOT NULL DEFAULT 0,
  tva             BOOLEAN NOT NULL DEFAULT TRUE,
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, code)
);

-- ─── 7. CLIENTS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.clients (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  code        TEXT NOT NULL,
  nom         TEXT NOT NULL,
  adresse     TEXT DEFAULT '',
  telephone   TEXT DEFAULT '',
  email       TEXT DEFAULT '',
  solde       NUMERIC(15,2) NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, code)
);

-- ─── 8. FOURNISSEURS ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.fournisseurs (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  code        TEXT NOT NULL,
  nom         TEXT NOT NULL,
  adresse     TEXT DEFAULT '',
  telephone   TEXT DEFAULT '',
  email       TEXT DEFAULT '',
  solde       NUMERIC(15,2) NOT NULL DEFAULT 0,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, code)
);

-- ─── 9. FACTURES ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.factures (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id     UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  numero         TEXT NOT NULL,
  date           DATE NOT NULL,
  client_id      UUID REFERENCES public.clients(id),
  lignes         JSONB NOT NULL DEFAULT '[]',
  statut         TEXT NOT NULL DEFAULT 'en attente'
                 CHECK (statut IN ('en attente', 'payée', 'annulée')),
  mode_paiement  TEXT DEFAULT '',
  notes          TEXT DEFAULT '',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, numero)
);

-- ─── 10. ACHATS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.achats (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  numero          TEXT NOT NULL,
  date            DATE NOT NULL,
  fournisseur_id  UUID REFERENCES public.fournisseurs(id),
  lignes          JSONB NOT NULL DEFAULT '[]',
  statut          TEXT NOT NULL DEFAULT 'en attente'
                  CHECK (statut IN ('en attente', 'reçue', 'annulée')),
  mode_paiement   TEXT DEFAULT '',
  notes           TEXT DEFAULT '',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, numero)
);

-- ─── 11. ÉCRITURES COMPTABLES ──────────────────────────────────
CREATE TABLE IF NOT EXISTS public.ecritures (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  date        DATE NOT NULL,
  journal     TEXT NOT NULL CHECK (journal IN ('AN','VT','AC','BQ','OD','PAIE')),
  libelle     TEXT NOT NULL,
  lignes      JSONB NOT NULL DEFAULT '[]',
  reference   TEXT DEFAULT '',
  valide      BOOLEAN NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 12. EMPLOYÉS & PAIE ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.employes (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  matricule       TEXT NOT NULL,
  nom             TEXT NOT NULL,
  poste           TEXT DEFAULT '',
  departement     TEXT DEFAULT '',
  date_embauche   DATE,
  sal_base        NUMERIC(15,2) NOT NULL DEFAULT 0,
  primes          JSONB NOT NULL DEFAULT '[]',
  statut          TEXT NOT NULL DEFAULT 'actif'
                  CHECK (statut IN ('actif', 'inactif')),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, matricule)
);

CREATE TABLE IF NOT EXISTS public.parametres_paie (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  taux_cnps_sal   NUMERIC(5,2) NOT NULL DEFAULT 3.6,
  taux_cnps_pat   NUMERIC(5,2) NOT NULL DEFAULT 16.4,
  taux_its        NUMERIC(5,2) NOT NULL DEFAULT 15,
  smig            NUMERIC(15,2) NOT NULL DEFAULT 52000,
  plafond_cnps    NUMERIC(15,2) NOT NULL DEFAULT 600000,
  UNIQUE(company_id)
);

CREATE TABLE IF NOT EXISTS public.bulletins (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  mois        TEXT NOT NULL,
  employe_id  UUID NOT NULL REFERENCES public.employes(id) ON DELETE CASCADE,
  sal_base    NUMERIC(15,2) NOT NULL DEFAULT 0,
  primes      JSONB NOT NULL DEFAULT '[]',
  cotisations JSONB NOT NULL DEFAULT '{}',
  salaire_net NUMERIC(15,2) NOT NULL DEFAULT 0,
  statut      TEXT NOT NULL DEFAULT 'brouillon'
              CHECK (statut IN ('brouillon', 'payé')),
  date        DATE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 13. RAPPROCHEMENT BANCAIRE ────────────────────────────────
CREATE TABLE IF NOT EXISTS public.releves_bancaires (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id  UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  date        DATE NOT NULL,
  libelle     TEXT NOT NULL,
  montant     NUMERIC(15,2) NOT NULL,
  type        TEXT NOT NULL CHECK (type IN ('credit', 'debit')),
  ref         TEXT DEFAULT '',
  rapproche   BOOLEAN NOT NULL DEFAULT FALSE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.rapprochements (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id            UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  date                  DATE NOT NULL,
  solde_bancaire        NUMERIC(15,2) NOT NULL DEFAULT 0,
  solde_comptable       NUMERIC(15,2) NOT NULL DEFAULT 0,
  ecart                 NUMERIC(15,2) NOT NULL DEFAULT 0,
  nb_lignes_rapprochees INTEGER NOT NULL DEFAULT 0,
  statut                TEXT NOT NULL DEFAULT 'avec écart'
                        CHECK (statut IN ('équilibré', 'avec écart')),
  created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── 14. DÉCLARATIONS TVA ──────────────────────────────────────
CREATE TABLE IF NOT EXISTS public.declarations_tva (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id      UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  periode         TEXT NOT NULL,
  tva_collectee   NUMERIC(15,2) NOT NULL DEFAULT 0,
  tva_deductible  NUMERIC(15,2) NOT NULL DEFAULT 0,
  tva_nette       NUMERIC(15,2) NOT NULL DEFAULT 0,
  statut          TEXT NOT NULL DEFAULT 'brouillon'
                  CHECK (statut IN ('brouillon', 'comptabilisée', 'déposée')),
  date_depot      DATE,
  ref             TEXT DEFAULT '',
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(company_id, periode)
);

-- ═══════════════════════════════════════════════════════════════
--  ROW LEVEL SECURITY — Isolation totale par entreprise
-- ═══════════════════════════════════════════════════════════════

-- Helper function : liste des company_id accessibles par l'utilisateur connecté
CREATE OR REPLACE FUNCTION public.my_company_ids()
RETURNS SETOF UUID AS $$
  SELECT id FROM public.companies WHERE owner_id = (
    SELECT id FROM public.users WHERE auth_id = auth.uid()
  );
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Activer RLS sur toutes les tables
ALTER TABLE public.users             ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.companies         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comptes           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.articles          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mouvements_stock  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clients           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fournisseurs      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.factures          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.achats            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ecritures         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employes          ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.parametres_paie   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bulletins         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.releves_bancaires ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rapprochements    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.declarations_tva  ENABLE ROW LEVEL SECURITY;

-- Politiques : chaque utilisateur voit et modifie uniquement ses données
CREATE POLICY "users_own" ON public.users USING (auth_id = auth.uid());
CREATE POLICY "subs_own"  ON public.subscriptions USING (user_id = (SELECT id FROM public.users WHERE auth_id = auth.uid()));
CREATE POLICY "co_own"    ON public.companies USING (owner_id = (SELECT id FROM public.users WHERE auth_id = auth.uid()));

-- Macro pour toutes les tables liées à company_id
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'comptes','articles','mouvements_stock','services','clients',
    'fournisseurs','factures','achats','ecritures','employes',
    'parametres_paie','bulletins','releves_bancaires',
    'rapprochements','declarations_tva'
  ] LOOP
    EXECUTE format('CREATE POLICY %I ON public.%I USING (company_id IN (SELECT public.my_company_ids()));', t||'_iso', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR INSERT WITH CHECK (company_id IN (SELECT public.my_company_ids()));', t||'_ins', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR UPDATE USING (company_id IN (SELECT public.my_company_ids()));', t||'_upd', t);
    EXECUTE format('CREATE POLICY %I ON public.%I FOR DELETE USING (company_id IN (SELECT public.my_company_ids()));', t||'_del', t);
  END LOOP;
END;
$$;

-- ═══════════════════════════════════════════════════════════════
--  TRIGGERS : updated_at automatique
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = NOW(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trig_users_upd    BEFORE UPDATE ON public.users    FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER trig_companies_upd BEFORE UPDATE ON public.companies FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ═══════════════════════════════════════════════════════════════
--  TRIGGER : créer user public après inscription Supabase Auth
-- ═══════════════════════════════════════════════════════════════
CREATE OR REPLACE FUNCTION public.handle_new_auth_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (auth_id, email, display_name)
  VALUES (NEW.id, NEW.email, NEW.raw_user_meta_data->>'display_name')
  ON CONFLICT (auth_id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_auth_user();

-- ═══════════════════════════════════════════════════════════════
--  INDEXES pour les performances
-- ═══════════════════════════════════════════════════════════════
CREATE INDEX idx_companies_owner   ON public.companies(owner_id);
CREATE INDEX idx_ecritures_company ON public.ecritures(company_id, date);
CREATE INDEX idx_factures_company  ON public.factures(company_id, date);
CREATE INDEX idx_achats_company    ON public.achats(company_id, date);
CREATE INDEX idx_articles_company  ON public.articles(company_id);
CREATE INDEX idx_employes_company  ON public.employes(company_id);
CREATE INDEX idx_bulletins_mois    ON public.bulletins(company_id, mois);
CREATE INDEX idx_ecritures_journal ON public.ecritures(company_id, journal);
