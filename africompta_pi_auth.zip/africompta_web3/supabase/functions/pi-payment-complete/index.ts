// supabase/functions/pi-payment-complete/index.ts
// ─── Étape 2 du flux Pi Payment : compléter le paiement ──────
// Appelée quand la transaction est confirmée sur la blockchain Pi
// Active l'abonnement et met à jour le statut

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const PI_API_KEY    = Deno.env.get('PI_API_KEY')!;
const SUPABASE_URL  = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_KEY  = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { paymentId, txid, plan, userId, companyId } = await req.json();

    if (!paymentId || !txid || !userId) {
      return new Response(
        JSON.stringify({ error: 'Paramètres manquants: paymentId, txid, userId requis' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

    // 1. Vérifier le paiement final auprès de Pi Platform
    const piResponse = await fetch(`https://api.minepi.com/v2/payments/${paymentId}`, {
      headers: { 'Authorization': `Key ${PI_API_KEY}` },
    });

    if (!piResponse.ok) {
      throw new Error(`Pi API error: ${piResponse.status}`);
    }

    const piPayment = await piResponse.json();

    // 2. Vérifier que la transaction correspond
    if (piPayment.transaction?.txid !== txid) {
      throw new Error('Transaction ID non concordant');
    }

    if (!piPayment.transaction?.verified) {
      throw new Error('Transaction non vérifiée sur la blockchain');
    }

    // 3. Compléter le paiement via Pi Platform API
    const completeResponse = await fetch(
      `https://api.minepi.com/v2/payments/${paymentId}/complete`,
      {
        method:  'POST',
        headers: { 'Authorization': `Key ${PI_API_KEY}` },
      }
    );

    if (!completeResponse.ok) {
      throw new Error(`Échec complétion Pi: ${completeResponse.status}`);
    }

    // 4. Activer l'abonnement en base
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);

    const { error: updateErr } = await supabase
      .from('subscriptions')
      .update({
        status:     'active',
        pi_txid:    txid,
        expires_at: expiresAt.toISOString(),
      })
      .eq('pi_payment_id', paymentId);

    if (updateErr) {
      // Si la ligne n'existe pas encore, la créer
      await supabase.from('subscriptions').insert({
        user_id:        userId,
        plan,
        status:         'active',
        starts_at:      new Date().toISOString(),
        expires_at:     expiresAt.toISOString(),
        pi_payment_id:  paymentId,
        pi_txid:        txid,
        amount_pi:      piPayment.amount,
      });
    }

    // 5. Mettre à jour le plan de l'utilisateur
    await supabase
      .from('users')
      .update({ plan })
      .eq('id', userId);

    // 6. Logger la transaction complète
    console.log(`✅ Abonnement activé: user=${userId} plan=${plan} tx=${txid}`);

    return new Response(
      JSON.stringify({
        ok:         true,
        plan,
        txid,
        expiresAt:  expiresAt.toISOString(),
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('pi-payment-complete error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
