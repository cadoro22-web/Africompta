/**
 * pi-auth-validate — Edge Function
 *
 * Validates a Pi Network access token by calling GET /v2/me.
 * NO Pi API key required — the accessToken itself is the credential.
 *
 * Request body:  { accessToken: string }
 * Response:      { uid: string, username: string }
 */

const PI_ME_URL  = 'https://api.minepi.com/v2/me';
const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });

  try {
    const { accessToken } = await req.json();

    if (!accessToken || typeof accessToken !== 'string') {
      return new Response(
        JSON.stringify({ error: 'accessToken is required' }),
        { status: 400, headers: { ...CORS, 'Content-Type': 'application/json' } }
      );
    }

    // Validate token against Pi Platform API — no server API key needed
    const piRes = await fetch(PI_ME_URL, {
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });

    if (!piRes.ok) {
      const body = await piRes.text();
      console.error('[pi-auth-validate] /v2/me error:', piRes.status, body);
      return new Response(
        JSON.stringify({ error: 'Invalid or expired Pi access token' }),
        { status: 401, headers: { ...CORS, 'Content-Type': 'application/json' } }
      );
    }

    const piUser: { uid: string; username: string } = await piRes.json();

    if (!piUser.uid || !piUser.username) {
      return new Response(
        JSON.stringify({ error: 'Unexpected response from Pi API' }),
        { status: 502, headers: { ...CORS, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`[pi-auth-validate] ✓ uid=${piUser.uid} username=${piUser.username}`);

    return new Response(
      JSON.stringify({ uid: piUser.uid, username: piUser.username }),
      { status: 200, headers: { ...CORS, 'Content-Type': 'application/json' } }
    );

  } catch (err) {
    console.error('[pi-auth-validate] Error:', err);
    return new Response(
      JSON.stringify({ error: err.message ?? 'Internal error' }),
      { status: 500, headers: { ...CORS, 'Content-Type': 'application/json' } }
    );
  }
});
