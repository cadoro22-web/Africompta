// supabase/functions/pi-payment-approve/index.ts
// ─── Étape 1 du flux Pi Payment : approuver le paiement ──────
// Appelée par le frontend quand Pi a créé la transaction
// Doit répondre dans les 15 secondes sinon Pi annule

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const PI_API_KEY    = Deno.env.get('PI_API_KEY')!;
const SUPABASE_URL  = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_KEY  = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const corsHeaders = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Gérer CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { paymentId, plan, userId, companyId } = await req.json();

    if (!paymentId || !plan || !userId) {
      return new Response(
        JSON.stringify({ error: 'Paramètres manquants: paymentId, plan, userId requis' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 1. Vérifier le paiement auprès de l'API Pi Platform
    const piResponse = await fetch(`https://api.minepi.com/v2/payments/${paymentId}`, {
      headers: { 'Authorization': `Key ${PI_API_KEY}` },
    });

    if (!piResponse.ok) {
      throw new Error(`Pi API error: ${piResponse.status}`);
    }

    const piPayment = await piResponse.json();

    // 2. Valider que le montant correspond au plan
    const PLAN_PRICES: Record<string, number> = {
      starter:    5,
      business:   15,
      enterprise: 35,
    };

    const expectedAmount = PLAN_PRICES[plan];
    if (!expectedAmount) {
      throw new Error(`Plan inconnu: ${plan}`);
    }

    if (piPayment.amount !== expectedAmount) {
      throw new Error(
        `Montant incorrect: attendu ${expectedAmount}π, reçu ${piPayment.amount}π`
      );
    }

    // 3. Valider que le paiement n'a pas déjà été utilisé
    const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);
    const { data: existing } = await supabase
      .from('subscriptions')
      .select('id')
      .eq('pi_payment_id', paymentId)
      .maybeSingle();

    if (existing) {
      throw new Error('Paiement déjà utilisé');
    }

    // 4. Approuver le paiement via Pi Platform API
    const approveResponse = await fetch(
      `https://api.minepi.com/v2/payments/${paymentId}/approve`,
      {
        method:  'POST',
        headers: { 'Authorization': `Key ${PI_API_KEY}` },
      }
    );

    if (!approveResponse.ok) {
      throw new Error(`Échec approbation Pi: ${approveResponse.status}`);
    }

    // 5. Logger l'approbation en base (paiement en attente)
    await supabase.from('subscriptions').insert({
      user_id:        userId,
      plan,
      status:         'pending_payment',
      starts_at:      new Date().toISOString(),
      expires_at:     new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
      pi_payment_id:  paymentId,
      amount_pi:      expectedAmount,
    });

    return new Response(
      JSON.stringify({ ok: true, paymentId, plan }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('pi-payment-approve error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
