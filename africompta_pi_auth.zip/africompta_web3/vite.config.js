import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],

  base: '/',

  define: {
    global: 'globalThis',
    'process.env': {},
  },

  build: {
    outDir:    'dist',
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/react'))     return 'react';
          if (id.includes('node_modules/recharts'))  return 'charts';
          if (id.includes('node_modules/jspdf'))     return 'pdf';
          if (id.includes('node_modules/@supabase')) return 'supabase';
        },
      },
    },
  },

  server: {
    port: 5174,
  },
});
