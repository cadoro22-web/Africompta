# Africompta — Guide Pi Network Phase 3

## 1. Créer l'application sur le portail développeur Pi

### Accéder au portail
1. Ouvrir **Pi Browser** sur votre téléphone
2. Aller sur `developer.minepi.com`
3. Se connecter avec votre compte Pi Network

### Créer l'application
1. Cliquer **New App**
2. Remplir le formulaire :
   - **App Name** : `Africompta`
   - **Description** : `Logiciel de comptabilité OHADA/PCG pour l'Afrique de l'Ouest`
   - **App URL** : `https://africompta.vercel.app` (votre URL Vercel)
   - **Category** : Finance / Business Tools
3. Récupérer l'**App ID** et l'**API Key**

### Configurer les variables d'environnement
```bash
# Dans .env.local
VITE_PI_APP_ID=votre_app_id
VITE_PI_API_KEY=votre_api_key_pi

# Dans Supabase Edge Functions (via CLI ou dashboard)
supabase secrets set PI_API_KEY=votre_api_key_pi
```

---

## 2. Déployer les Edge Functions Supabase

```bash
# Installer Supabase CLI
npm install -g supabase

# Se connecter
supabase login

# Lier au projet
supabase link --project-ref VOTRE_PROJECT_ID

# Déployer les fonctions
supabase functions deploy pi-payment-approve
supabase functions deploy pi-payment-complete

# Ajouter la clé Pi API
supabase secrets set PI_API_KEY=votre_api_key_pi
```

---

## 3. Tester en mode Sandbox

Pi Network propose un mode sandbox pour tester sans vrais Pi.

### Activer le Sandbox
Dans `index.html`, décommenter :
```js
window.Pi.init({ version: "2.0", sandbox: true });
```

Dans `src/lib/pi.js`, les paiements iront en sandbox automatiquement.

### Utilisateurs de test Sandbox
Pi fournit des comptes de test sur le portail développeur.

---

## 4. Flux de paiement complet

```
Utilisateur clique "S'abonner"
       │
       ▼
SubscriptionModal.jsx
  → createSubscriptionPayment()
       │
       ▼
Pi Browser ouvre le wallet Pi
  → Utilisateur confirme le paiement
       │
       ▼
onReadyForServerApproval (paymentId)
  → POST /pi-payment-approve
  → Vérification Pi Platform API
  → Approbation
       │
       ▼
Transaction confirmée sur blockchain
  → onReadyForServerCompletion (paymentId, txid)
  → POST /pi-payment-complete
  → Vérification + Activation abonnement
       │
       ▼
Abonnement actif en base Supabase
  → UI mise à jour
  → Accès complet débloqué
```

---

## 5. Vérification d'un paiement Pi (code de référence)

```typescript
// Appel à l'API Pi Platform
const response = await fetch(`https://api.minepi.com/v2/payments/${paymentId}`, {
  headers: { 'Authorization': `Key ${PI_API_KEY}` }
});
const payment = await response.json();

// Structure retournée
{
  identifier: "paymentId",
  user_uid: "uid_du_pionnier",
  amount: 15,                    // en Pi
  memo: "Africompta Business...",
  metadata: { plan: "business", userId: "..." },
  status: {
    developer_approved: true,
    transaction_verified: true,
    developer_completed: false,  // à compléter
    cancelled: false,
    user_cancelled: false
  },
  transaction: {
    txid: "xxx",
    verified: true,
    _link: "https://minepi.com/tx/xxx"
  }
}
```

---

## 6. Gestion des paiements incomplets

Au démarrage, `Pi.authenticate()` peut signaler un paiement incomplet.
La fonction `onIncompletePayment` dans `src/lib/pi.js` le gère automatiquement.

```js
// Annuler le paiement incomplet
Pi.authenticate(scopes, async (incompletePayment) => {
  // Paiement précédent non complété (crash app, fermeture brutale...)
  await cancelIncompletePayment(incompletePayment.identifier);
});
```

---

## 7. Checklist avant soumission Pi App Store

- [ ] App testée en Sandbox Pi sur Pi Browser
- [ ] Paiements tests complétés avec succès
- [ ] index.html avec `<meta name="pi-app-id">` correct
- [ ] sandbox: true retiré de Pi.init() pour la production
- [ ] Edge Functions déployées et testées
- [ ] Politique de confidentialité publiée
- [ ] Captures d'écran Pi Browser (1280x720)
- [ ] Description en anglais ET en français
- [ ] URL de l'app accessible publiquement

---

## 8. Architecture de sécurité

```
Client (Pi Browser)
  ├── Pi SDK authentifie l'utilisateur → token Pi
  ├── Token Pi → Supabase Auth → token JWT
  └── Token JWT sur toutes les requêtes Supabase

Backend (Supabase)
  ├── RLS : isolation totale par company_id
  ├── Edge Function : validation paiements Pi (côté serveur)
  └── Service Role Key : jamais exposée au client
```

**Important** : La `PI_API_KEY` ne doit JAMAIS être dans le code client.
Elle est utilisée uniquement dans les Edge Functions Supabase.
