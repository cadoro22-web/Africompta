# Africompta NEXUS — Logiciel de Comptabilité OHADA Web3

<div align="center">

```
╔══════════════════════════════════════════════════════╗
║  AFRI  ██████╗  ██████╗  ███╗   ███╗ ██████╗████████╗  ║
║  COMPTA██╔══██╗██╔════╝  ████╗ ████║██╔════╝╚══██╔══╝  ║
║        ███████║██║       ██╔████╔██║██║        ██║      ║
║        ██╔══██║██║       ██║╚██╔╝██║██║        ██║      ║
║   π    ██║  ██║╚██████╗  ██║ ╚═╝ ██║╚██████╗   ██║      ║
║        ╚═╝  ╚═╝ ╚═════╝  ╚═╝     ╚═╝ ╚═════╝   ╚═╝      ║
╚══════════════════════════════════════════════════════╝
          NEXUS v4.0 · OHADA/PCG · Pi Network Web3
```

**Logiciel de comptabilité OHADA/PCG pour entreprises africaines**  
Développé pour le marché francophone d'Afrique de l'Ouest  
Intégré à l'écosystème Pi Network — abonnement en Pi

[![Déploiement](https://img.shields.io/badge/Vercel-Déployé-00e5ff?style=flat-square&logo=vercel)](https://africompta.vercel.app)
[![Pi Network](https://img.shields.io/badge/Pi_Network-Web3-39ff14?style=flat-square)](https://minepi.com)
[![Supabase](https://img.shields.io/badge/Supabase-PostgreSQL-3ECF8E?style=flat-square&logo=supabase)](https://supabase.com)
[![React](https://img.shields.io/badge/React-18.3-61DAFB?style=flat-square&logo=react)](https://react.dev)
[![Vite](https://img.shields.io/badge/Vite-5.4-646CFF?style=flat-square&logo=vite)](https://vitejs.dev)

</div>

---

## Présentation

**Africompta** est un logiciel de comptabilité complet en mode **SaaS Web3**, conçu spécifiquement pour les entreprises d'Afrique de l'Ouest opérant sous le plan comptable **OHADA** (Bénin, Sénégal, Côte d'Ivoire, Togo, Cameroun, Burkina Faso) ou le **PCG** français.

L'application est accessible depuis le **Pi Browser** et les paiements d'abonnement s'effectuent en **Pi**, la cryptomonnaie du réseau Pi Network.

### Marchés cibles
Bénin · Sénégal · Côte d'Ivoire · Togo · Cameroun · Burkina Faso · Mali

---

## Fonctionnalités

### 13 modules comptables

| Module | Fonctionnalités clés |
|--------|---------------------|
| **Dashboard** | 6 graphiques Recharts (Bar, Area, Pie), 6 KPI cards, activité récente |
| **Stocks** | Articles, mouvements entrée/sortie, alertes seuil minimum |
| **Services** | Catalogue prestations avec TVA configurable |
| **Clients** | Répertoire, suivi CA par client |
| **Facturation** | Factures, aperçu imprimable, écriture automatique |
| **Achats** | Bons de commande fournisseurs |
| **Comptabilité** | Journal, Grand Livre, Balance générale |
| **Plan Comptable** | OHADA (Bénin) et PCG France — switchable |
| **Liasse Fiscale** | RRN (6 onglets) et RRS (4 onglets), Bilan, Compte de résultat |
| **Rapprochement Bancaire** | Relevés, rapprochement, état officiel, écriture d'écart |
| **Gestion TVA** | Collectée/déductible auto, déclarations, workflow DGI |
| **Paie** | Fiches employés, bulletins CNPS/ITS, aperçu imprimable |
| **Configuration** | Entreprise, RCCM, IFU, devise, TVA, exercice |

### Export PDF — 7 types de documents

- Bilan Actif & Passif (2 pages A4, format OHADA)
- Compte de Résultat avec Soldes Intermédiaires de Gestion
- Balance Générale (A4 paysage)
- Journal Comptable (par journal ou général)
- Factures individuelles
- Bulletins de Paie (CNPS/ITS, zone signature)
- Déclaration TVA (format DGI Bénin)

### Multi-tenant & Web3

- Chaque utilisateur peut gérer jusqu'à 5 entreprises (selon le plan)
- Isolation totale des données par **Row Level Security** Supabase
- Authentification Pi Network ou email
- Paiements d'abonnement en **Pi** via Pi SDK

---

## Plans d'abonnement

| Plan | Prix | Entreprises | Écritures/mois |
|------|------|-------------|----------------|
| **Starter** | 5 π/mois | 1 | 200 |
| **Business** | 15 π/mois | 1 | Illimitées |
| **Enterprise** | 35 π/mois | 5 | Illimitées |

> Les prix en Pi ciblent une valeur de 3 000 à 7 000 FCFA/mois pour le plan Business selon le taux de migration Pi.

---

## Stack technique

```
Frontend          React 18.3 + Vite 5.4
UI Components     Recharts 2.12 (graphiques)
Design System     NEXUS CORP — Cyberpunk Financial OS
Export PDF        jsPDF 2.5 (pur JS, sans DOM capture)
Auth & BDD        Supabase (PostgreSQL + Auth + RLS)
Paiements Web3    Pi Network SDK 2.0
Hébergement       Vercel (frontend) + Supabase (backend)
```

### Design System NEXUS

```css
--void:  #020810   /* fond espace profond  */
--cyan:  #00e5ff   /* accent primaire néon */
--lime:  #39ff14   /* succès néon          */
--pink:  #ff0080   /* magenta cyberpunk    */
--amber: #ffab00   /* alertes              */

fonts: Rajdhani (titres) · Exo 2 (corps) · Share Tech Mono (données)
```

Effets : scanlines, grille de fond, glassmorphism, coins angulaires `clip-path`, lueurs `box-shadow`.

---

## Architecture

```
Pi Browser / Navigateur web
         │
         ▼
┌────────────────────────────┐
│  Africompta React (Vercel) │
│                            │
│  AuthScreen                │  ← Email ou Pi Network
│  CompanySelector           │  ← Multi-tenant
│  AppAccounting (NEXUS)     │  ← 13 modules
│  ExportManager             │  ← PDF
└─────────────┬──────────────┘
              │ Supabase JS SDK
              ▼
┌────────────────────────────┐
│  Supabase (PostgreSQL)     │
│                            │
│  users                     │
│  subscriptions (Pi txid)   │
│  companies (multi-tenant)  │
│  ecritures · factures...   │
│  Row Level Security ✓      │
└────────────────────────────┘
              │ Pi Platform API
              ▼
┌────────────────────────────┐
│  Supabase Edge Functions   │
│                            │
│  pi-payment-approve        │  ← Validation paiement étape 1
│  pi-payment-complete       │  ← Activation abonnement étape 2
└────────────────────────────┘
```

### Flux de paiement Pi (4 étapes)

```
Utilisateur → S'abonner → choisit le plan
     │
     ▼
Pi.createPayment() → wallet Pi s'ouvre
     │
     ▼
onReadyForServerApproval → Edge Function approve
     │  (vérifie via API Pi + approuve)
     ▼
Transaction blockchain confirmée
     │
     ▼
onReadyForServerCompletion → Edge Function complete
     │  (active abonnement en Supabase)
     ▼
Badge "Business · 30j" dans la sidebar ✓
```

---

## Structure du projet

```
africompta_web3/
├── index.html                          # Pi SDK + meta pi-app-id
├── vite.config.js                      # Config build Vercel
├── vercel.json                         # Routage SPA + headers
├── package.json
├── .gitignore
│
├── public/
│   └── privacy.html                    # Politique de confidentialité
│
├── src/
│   ├── main.jsx                        # Point d'entrée
│   ├── App.jsx                         # AppAccounting (NEXUS — 13 modules)
│   ├── AppWeb3.jsx                     # Orchestrateur Phase 2
│   ├── AppWeb3_v2.jsx                  # Orchestrateur Phase 3 + Pi
│   │
│   ├── lib/
│   │   ├── supabase.js                 # Client Supabase + auth helpers
│   │   ├── api.js                      # CRUD complet (remplace localStorage)
│   │   ├── pi.js                       # Pi SDK wrapper + plans
│   │   └── pdfExport.js               # Moteur PDF 7 documents
│   │
│   ├── hooks/
│   │   └── usePiAuth.js               # Hook auth Pi → Supabase
│   │
│   └── components/
│       ├── AuthScreen.jsx              # Écran connexion NEXUS
│       ├── CompanySelector.jsx         # Multi-entreprises
│       ├── SubscriptionModal.jsx       # Paiement Pi 4 étapes
│       ├── PiBadge.jsx                 # Badge abonnement sidebar
│       └── ExportManager.jsx           # Panneau export PDF
│
└── supabase/
    ├── schema.sql                      # 15 tables + RLS + triggers
    └── functions/
        ├── pi-payment-approve/
        │   └── index.ts               # Edge Function étape 1
        └── pi-payment-complete/
            └── index.ts               # Edge Function étape 2
```

---

## Installation et déploiement

### Prérequis

- Node.js 18+
- Compte [Supabase](https://supabase.com) (gratuit)
- Compte [Vercel](https://vercel.com) (gratuit)
- Compte Pi Network (pour les paiements Pi — Phase 3)

### 1. Cloner et installer

```bash
git clone https://github.com/VOTRE_USER/africompta.git
cd africompta_web3
npm install
```

### 2. Configurer Supabase

```bash
# 1. Créer un projet sur app.supabase.com

# 2. Exécuter le schéma dans SQL Editor
# → Copier-coller le contenu de supabase/schema.sql → Run

# 3. Récupérer les clés API
# Settings → API → Project URL + anon public key
```

### 3. Variables d'environnement

Créer `.env.local` à la racine :

```env
VITE_SUPABASE_URL=https://VOTRE_PROJECT_ID.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Pi Network (Phase 3 — après inscription sur developer.minepi.com)
VITE_PI_APP_ID=votre_app_id_pi
```

### 4. Lancer en développement

```bash
npm run dev
# → http://localhost:5174
```

### 5. Déployer sur Vercel

**Méthode rapide — Drag & Drop :**
1. Aller sur [vercel.com](https://vercel.com) → New Project
2. Glisser-déposer le dossier `africompta_web3`
3. Ajouter les variables d'environnement
4. Cliquer Deploy

**Méthode CLI :**
```bash
npm install -g vercel
vercel --prod
```

### 6. Déployer les Edge Functions Pi (Phase 3)

```bash
npm install -g supabase

supabase login
supabase link --project-ref VOTRE_PROJECT_ID

# Déployer les fonctions de paiement
supabase functions deploy pi-payment-approve
supabase functions deploy pi-payment-complete

# Ajouter la clé secrète Pi (ne jamais exposer côté client)
supabase secrets set PI_API_KEY=votre_api_key_pi
```

---

## Intégration Pi Network

### Initialisation

```html
<!-- index.html -->
<meta name="pi-app-id" content="VOTRE_APP_ID" />
<script src="https://sdk.minepi.com/pi-sdk.js"></script>
<script>
  Pi.init({ version: "2.0" }); // sandbox: true pour les tests
</script>
```

### Authentification

```javascript
import { authenticatePi } from './src/lib/pi.js';

const { user, accessToken } = await authenticatePi();
// user.username = identifiant Pi du Pioneer
```

### Paiement d'abonnement

```javascript
import { createSubscriptionPayment } from './src/lib/pi.js';

await createSubscriptionPayment({
  plan: 'business',           // starter | business | enterprise
  userId: currentUser.id,
  companyId: company.id,
  onApproved:  (paymentId) => { /* serveur approuve */ },
  onCompleted: (paymentId, txid) => { /* abonnement activé */ },
  onCancelled: (paymentId) => { /* annulé */ },
  onError:     (error) => { /* erreur */ },
});
```

---

## Sécurité

### Row Level Security (Supabase)

Chaque utilisateur ne peut accéder qu'aux données de ses propres entreprises :

```sql
-- Fonction helper : IDs des entreprises de l'utilisateur connecté
CREATE FUNCTION my_company_ids() RETURNS SETOF UUID AS $$
  SELECT id FROM companies WHERE owner_id = (
    SELECT id FROM users WHERE auth_id = auth.uid()
  );
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Politique : isolation totale
CREATE POLICY "isolation" ON ecritures
  USING (company_id IN (SELECT my_company_ids()));
```

### Clé Pi API

La `PI_API_KEY` n'est **jamais** exposée côté client. Elle est utilisée uniquement dans les Edge Functions Supabase via `Deno.env.get('PI_API_KEY')`.

---

## Roadmap Pi Network

| Étape | Statut | Description |
|-------|--------|-------------|
| Phase 1 | ✅ Terminé | Africompta NEXUS — 13 modules complets |
| Phase 2 | ✅ Terminé | Multi-tenant Supabase + Auth |
| Phase 3 | ✅ Terminé | Pi SDK + paiements abonnement |
| Phase 4 | ✅ Terminé | Export PDF 7 types de documents |
| Déploiement Vercel | ✅ Prêt | `vercel deploy --prod` |
| KYC Pi Pioneer | ⏳ En attente | Vérification en cours (minage depuis 2019) |
| Soumission Pi App Store | 📋 Prêt | Dès validation KYC |

---

## Contributions

Ce projet est développé et maintenu par un **Pioneer Pi Network** basé au Bénin (Abomey-Calavi), mineur depuis 2019.

Il est destiné à la communauté des entrepreneurs et comptables d'Afrique de l'Ouest souhaitant accéder à un outil professionnel en mode Web3.

---

## Licence

Propriétaire — Tous droits réservés.  
Pour toute question : contact@africompta.app

---

## Liens

| Ressource | URL |
|-----------|-----|
| Application | [africompta.vercel.app](https://africompta.vercel.app) |
| Politique de confidentialité | [africompta.vercel.app/privacy](https://africompta.vercel.app/privacy) |
| Pi Network | [minepi.com](https://minepi.com) |
| Portail développeur Pi | [developer.minepi.com](https://developer.minepi.com) |
| Supabase | [supabase.com](https://supabase.com) |
| Vercel | [vercel.com](https://vercel.com) |

---

<div align="center">

```
Africompta NEXUS v4.0
Plan comptable OHADA · PCG France
Pi Network Web3 · Bénin · Afrique de l'Ouest
```

*Construit avec ❤️ pour les entrepreneurs africains*

</div>
