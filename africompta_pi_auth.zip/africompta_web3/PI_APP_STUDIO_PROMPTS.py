# AFRICOMPTA — PROMPTS PI APP STUDIO
# À copier-coller dans Claude depuis Pi App Studio > "Use External AI"
# ================================================================

# ════════════════════════════════════════════════════════
# PROMPT 1 — INTÉGRATION PI SDK
# Coller ce prompt dans Claude après avoir déployé sur Vercel
# ════════════════════════════════════════════════════════

PROMPT_1_PI_SDK = """
I have a React web app called Africompta (OHADA accounting software for West African businesses) deployed at https://africompta.vercel.app. It was built with React 18 + Vite + Supabase.

Please integrate the Pi Network SDK into this app following Pi Network's official developer guidelines. Here is the current project structure:

- index.html : entry point (needs Pi SDK script tag + pi-app-id meta)
- src/lib/pi.js : Pi SDK wrapper (already exists, needs verification)
- src/AppWeb3_v2.jsx : main orchestrator
- src/components/SubscriptionModal.jsx : Pi payment UI

The app already has these Pi-related files from a previous integration attempt:
1. Pi SDK loaded in index.html with Pi.init({ version: "2.0" })
2. src/lib/pi.js with authenticatePi() and createSubscriptionPayment() functions
3. Subscription plans: Starter 5π, Business 15π, Enterprise 35π/month
4. Supabase Edge Functions for payment approval and completion

Please:
1. Verify the Pi SDK is correctly loaded in index.html
2. Confirm Pi.authenticate() is called with scopes ['username', 'payments']
3. Ensure the onIncompletePaymentCallback is properly handled
4. Verify Pi.createPayment() follows the official 4-callback pattern
5. Check that the pi-app-id meta tag is in place
6. Make sure sandbox mode is OFF for production

My Pi App ID is: [VOTRE_APP_ID_ICI]
My app URL is: https://africompta.vercel.app

Please show me the corrected files if any changes are needed.
"""

# ════════════════════════════════════════════════════════
# PROMPT 2 — VÉRIFICATION CONFIGURATION
# Coller après le Prompt 1
# ════════════════════════════════════════════════════════

PROMPT_2_VERIFICATION = """
Now please verify that my Africompta Pi Network integration is complete and correct by checking these requirements from Pi Network's developer guidelines:

CHECKLIST TO VERIFY:
□ 1. Pi SDK script loaded: <script src="https://sdk.minepi.com/pi-sdk.js"></script>
□ 2. Pi App ID meta tag: <meta name="pi-app-id" content="[APP_ID]">
□ 3. Pi.init({ version: "2.0" }) called WITHOUT sandbox: true in production
□ 4. Pi.authenticate() called with correct scopes: ['username', 'payments']
□ 5. onIncompletePaymentCallback implemented
□ 6. Pi.createPayment() uses all 4 callbacks: onReadyForServerApproval, onReadyForServerCompletion, onCancel, onError
□ 7. Server-side payment approval via backend (Supabase Edge Function)
□ 8. Server-side payment completion via backend
□ 9. Pi API Key stored server-side only (never in frontend code)
□ 10. App works correctly inside Pi Browser

Please review each item and confirm if it's correctly implemented in the current codebase. For any item that's missing or incorrect, provide the exact code fix.

Current files to review:
- index.html
- src/lib/pi.js
- src/AppWeb3_v2.jsx
- src/components/SubscriptionModal.jsx
- supabase/functions/pi-payment-approve/index.ts
- supabase/functions/pi-payment-complete/index.ts
"""

# ════════════════════════════════════════════════════════
# PROMPT 3 — AJOUT PAIEMENTS PI
# Si les paiements ne sont pas encore configurés
# ════════════════════════════════════════════════════════

PROMPT_3_PAYMENTS = """
My Africompta app needs Pi payment integration for subscription plans. Please implement the complete Pi payment flow following Pi Network's official guidelines.

APP CONTEXT:
- App: Africompta (accounting SaaS for African businesses)
- Framework: React 18 + Vite
- Backend: Supabase (PostgreSQL + Edge Functions)
- Deployed at: https://africompta.vercel.app

SUBSCRIPTION PLANS (already defined):
- Starter: 5 Pi/month → 1 company, 200 entries/month
- Business: 15 Pi/month → 1 company, unlimited entries  
- Enterprise: 35 Pi/month → 5 companies, unlimited entries

REQUIRED IMPLEMENTATION:
1. Pi.createPayment() call with correct paymentData:
   {
     amount: [5 | 15 | 35],
     memo: "Africompta [Plan] - 1 month subscription",
     metadata: { plan: "business", userId: "...", type: "subscription" }
   }

2. Server-side approval endpoint (Supabase Edge Function):
   - Receive paymentId from client
   - Call Pi Platform API: GET https://api.minepi.com/v2/payments/{paymentId}
   - Verify amount matches the plan
   - Call Pi Platform API: POST https://api.minepi.com/v2/payments/{paymentId}/approve
   - Return 200 OK

3. Server-side completion endpoint (Supabase Edge Function):
   - Receive paymentId + txid
   - Verify transaction on Pi blockchain
   - Call Pi Platform API: POST https://api.minepi.com/v2/payments/{paymentId}/complete
   - Activate subscription in Supabase database
   - Return 200 OK

4. Frontend payment flow UI:
   - Show plan selection modal
   - Display payment progress (4 steps)
   - Show success confirmation with txid
   - Update subscription badge in sidebar

Please provide complete code for all files needed. The Pi API Key should only be used in the Supabase Edge Functions as an environment variable PI_API_KEY.
"""

# ════════════════════════════════════════════════════════
# PROMPT 4 — DÉPLOIEMENT FINAL ET SOUMISSION
# Après avoir tout vérifié
# ════════════════════════════════════════════════════════

PROMPT_4_FINAL_DEPLOY = """
My Africompta Pi Network app is ready for final deployment. Please help me complete the final steps:

APP SUMMARY:
- Name: Africompta
- Description: OHADA/PCG accounting software for West African businesses
- URL: https://africompta.vercel.app
- Privacy Policy: https://africompta.vercel.app/privacy.html
- Pi App ID: [VOTRE_APP_ID_ICI]
- Categories: Finance, Business Tools
- Target: Francophone West Africa (Benin, Senegal, Ivory Coast, Togo...)

FEATURES:
- Pi Network authentication (Pi.authenticate)
- Subscription payments in Pi (Starter 5π, Business 15π, Enterprise 35π)
- Multi-tenant accounting (13 modules: invoicing, payroll, VAT, balance sheets)
- PDF export of financial statements (balance sheet, income statement, tax returns)
- OHADA/PCG accounting standards
- Supabase backend with Row Level Security

FINAL CHECKLIST:
1. Remove sandbox: true from Pi.init() for production ✓
2. Verify pi-app-id meta tag matches the registered App ID ✓
3. Confirm backend Edge Functions are deployed on Supabase ✓
4. Test Pi.authenticate() works in Pi Browser ✓
5. Test a complete payment flow in Pi Sandbox mode ✓

Please:
1. Generate the final production-ready index.html with correct Pi SDK setup
2. Confirm the vercel.json configuration is complete
3. Provide the final deployment command sequence
4. List any remaining items I need to complete on developer.minepi.com

After deployment, the app should be submitted to Pi App Store for Mainnet review.
"""

# ════════════════════════════════════════════════════════
# PROMPT BONUS — DESCRIPTION PI APP STORE (EN + FR)
# Pour remplir le profil sur developer.minepi.com
# ════════════════════════════════════════════════════════

APP_STORE_DESCRIPTION_EN = """
SHORT DESCRIPTION (100 chars):
OHADA accounting software for West African businesses. Invoicing, payroll, VAT in Pi.

LONG DESCRIPTION (500 chars):
Africompta is a complete accounting SaaS built for West African businesses using OHADA or PCG accounting standards. Features 13 modules: invoicing, purchasing, payroll (CNPS/ITS), VAT management, bank reconciliation, and fiscal returns. Subscribe with Pi cryptocurrency for monthly access. Multi-tenant architecture lets you manage multiple companies. Download PDF balance sheets, income statements, and payslips anytime. Built for Benin, Senegal, Ivory Coast, Togo, Cameroon, and Burkina Faso.

TAGS: accounting, OHADA, finance, invoicing, payroll, VAT, business, Africa
"""

APP_STORE_DESCRIPTION_FR = """
DESCRIPTION COURTE (100 caractères):
Logiciel comptable OHADA pour entreprises africaines. Facturation, paie, TVA en Pi.

DESCRIPTION LONGUE (500 caractères):
Africompta est un logiciel comptable complet en SaaS pour les entreprises d'Afrique de l'Ouest utilisant les normes OHADA ou PCG. 13 modules : facturation, achats, paie (CNPS/ITS), gestion TVA, rapprochement bancaire et liasse fiscale. Abonnez-vous en Pi pour un accès mensuel. Architecture multi-entreprises. Téléchargez bilans, comptes de résultat et bulletins de paie en PDF. Conçu pour le Bénin, Sénégal, Côte d'Ivoire, Togo, Cameroun et Burkina Faso.

TAGS: comptabilité, OHADA, finance, facturation, paie, TVA, entreprise, Afrique
"""
