// ═══════════════════════════════════════════════════════════════
//  INTÉGRATION DANS AppAccounting.jsx (RemixNexus.jsx)
//  Ajouter ces blocs aux endroits indiqués
// ═══════════════════════════════════════════════════════════════

// ── ÉTAPE 1 : Imports à ajouter en haut de App.jsx ─────────────
import ExportManager from './components/ExportManager.jsx';
// (ou ajuster le chemin selon votre structure)


// ── ÉTAPE 2 : État à ajouter dans le composant App() ───────────
const [showExport, setShowExport] = useState(false);


// ── ÉTAPE 3 : Bouton dans la sidebar (avant les boutons Export/Import) ──
// Remplacer ou ajouter avant .sidebar-actions dans le JSX :
/*
<button
  className="sidebar-btn"
  onClick={() => setShowExport(true)}
  title="Télécharger les états financiers"
  style={{ gridColumn: '1/-1', color: 'var(--lime)', borderColor: 'rgba(57,255,20,.3)', marginBottom: 6 }}
>
  📥 États Financiers PDF
</button>
*/


// ── ÉTAPE 4 : Panneau Export juste avant la fermeture du return ──
// Ajouter après </nav> et avant la fermeture de <div className="app"> :
/*
{showExport && (
  <ExportManager
    state={state}
    onClose={() => setShowExport(false)}
  />
)}
*/


// ── ÉTAPE 5 : Boutons individuels dans chaque module ─────────────
// Exemple dans RapportsModule (bouton Imprimer → maintenant bouton PDF) :
/*
import { exportBilan, exportCompteResultat } from '../lib/pdfExport.js';

// Dans la section-header de RapportsModule :
<button className="btn btn-primary btn-sm" onClick={() => exportBilan(state)}>
  ↓ Bilan PDF
</button>
<button className="btn btn-outline btn-sm" onClick={() => exportCompteResultat(state)}>
  ↓ Résultat PDF
</button>
*/


// ── ÉTAPE 6 : Bouton dans FacturesModule pour chaque facture ──
/*
import { exportFacture } from '../lib/pdfExport.js';

// Dans la colonne actions du tableau factures :
<button className="btn btn-outline btn-xs" onClick={() => exportFacture(f, state)}>
  ↓ PDF
</button>
*/


// ── ÉTAPE 7 : Bouton dans PaieModule pour chaque bulletin ──
/*
import { exportBulletin } from '../lib/pdfExport.js';

// Dans la liste des bulletins :
<button className="btn btn-outline btn-xs" onClick={() => exportBulletin(b, state)}>
  ↓ Bulletin PDF
</button>
*/
