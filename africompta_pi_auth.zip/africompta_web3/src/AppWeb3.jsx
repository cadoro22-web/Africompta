import { useState, useEffect, useCallback } from 'react';
import { auth, userApi }            from './lib/supabase.js';
import { companiesApi, subscriptionsApi, loadCompanyState } from './lib/api.js';
import AuthScreen     from './components/AuthScreen.jsx';
import CompanySelector from './components/CompanySelector.jsx';

// Import de l'application comptable existante
// Le composant AppAccounting reçoit (state, dispatch, companyId, user, onLogout, onSwitchCompany)
import AppAccounting from './AppAccounting.jsx';

// ─── ÉTATS GLOBAUX DE L'APPLICATION WEB3 ─────────────────────
const STAGE = {
  LOADING:   'loading',
  AUTH:      'auth',
  COMPANY:   'company',
  APP:       'app',
};

export default function AppWeb3() {
  const [stage,        setStage]        = useState(STAGE.LOADING);
  const [authUser,     setAuthUser]     = useState(null);     // Supabase auth user
  const [profile,      setProfile]      = useState(null);     // public.users row
  const [subscription, setSubscription] = useState(null);     // abonnement actif
  const [companies,    setCompanies]    = useState([]);        // liste entreprises
  const [company,      setCompany]      = useState(null);     // entreprise sélectionnée
  const [appState,     setAppState]     = useState(null);     // état comptable complet
  const [loadingMsg,   setLoadingMsg]   = useState('Initialisation...');

  // ─── 1. VÉRIFIER SESSION AU DÉMARRAGE ────────────────────────
  useEffect(() => {
    const boot = async () => {
      const session = await auth.getSession();
      if (session?.user) {
        await loadUserData(session.user);
      } else {
        setStage(STAGE.AUTH);
      }
    };
    boot();

    // Écouter les changements d'auth
    const sub = auth.onAuthChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user) {
        await loadUserData(session.user);
      } else if (event === 'SIGNED_OUT') {
        resetState();
      }
    });
    return () => sub.unsubscribe();
  }, []);

  // ─── 2. CHARGER DONNÉES UTILISATEUR ──────────────────────────
  const loadUserData = async (user) => {
    setStage(STAGE.LOADING);
    setLoadingMsg('Chargement du profil...');
    setAuthUser(user);

    try {
      // Profil utilisateur
      const { data: prof } = await userApi.getProfile();
      setProfile(prof);

      // Abonnement actif
      setLoadingMsg('Vérification de l\'abonnement...');
      const { data: sub } = await subscriptionsApi.getActive();
      setSubscription(sub);

      // Liste des entreprises
      setLoadingMsg('Chargement des entreprises...');
      const { data: cos } = await companiesApi.list();
      setCompanies(cos || []);

      if (cos && cos.length === 1) {
        // Une seule entreprise → charger directement
        await openCompany(cos[0]);
      } else {
        setStage(STAGE.COMPANY);
      }
    } catch (err) {
      console.error('Erreur chargement:', err);
      setStage(STAGE.AUTH);
    }
  };

  // ─── 3. OUVRIR UNE ENTREPRISE ────────────────────────────────
  const openCompany = useCallback(async (co) => {
    setStage(STAGE.LOADING);
    setLoadingMsg(`Ouverture de ${co.nomEntreprise}...`);
    try {
      const state = await loadCompanyState(co.id);
      setCompany(co);
      setAppState(state);
      setStage(STAGE.APP);
    } catch (err) {
      console.error('Erreur ouverture entreprise:', err);
      setStage(STAGE.COMPANY);
    }
  }, []);

  // ─── 4. DÉCONNEXION ──────────────────────────────────────────
  const handleLogout = useCallback(async () => {
    await auth.signOut();
    resetState();
  }, []);

  // ─── 5. CHANGER D'ENTREPRISE ─────────────────────────────────
  const handleSwitchCompany = useCallback(async () => {
    const { data: cos } = await companiesApi.list();
    setCompanies(cos || []);
    setStage(STAGE.COMPANY);
    setCompany(null);
    setAppState(null);
  }, []);

  // ─── 6. RESET COMPLET ────────────────────────────────────────
  const resetState = () => {
    setAuthUser(null); setProfile(null); setSubscription(null);
    setCompanies([]); setCompany(null); setAppState(null);
    setStage(STAGE.AUTH);
  };

  // ─── RENDU ───────────────────────────────────────────────────

  // Écran de chargement
  if (stage === STAGE.LOADING) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',background:'var(--void)',gap:16,position:'relative',zIndex:1}}>
      <div style={{
        width:52,height:52,
        background:'rgba(0,229,255,.1)',border:'1px solid var(--cyan2)',
        clipPath:'polygon(8px 0%,100% 0%,100% calc(100% - 8px),calc(100% - 8px) 100%,0% 100%,0% 8px)',
        display:'flex',alignItems:'center',justifyContent:'center',
        fontFamily:'var(--fh)',fontWeight:700,fontSize:20,color:'var(--cyan)',
        boxShadow:'0 0 20px rgba(0,229,255,.3)',
        animation:'pulse-logo 2s ease-in-out infinite',
      }}>NX</div>
      <div style={{fontFamily:'var(--fm)',fontSize:11,color:'var(--tx3)',letterSpacing:'2px',textTransform:'uppercase'}}>
        {loadingMsg}
      </div>
      <style>{`@keyframes pulse-logo{0%,100%{box-shadow:0 0 20px rgba(0,229,255,.3)}50%{box-shadow:0 0 40px rgba(0,229,255,.6)}}`}</style>
    </div>
  );

  // Authentification
  if (stage === STAGE.AUTH) return (
    <AuthScreen onAuth={loadUserData}/>
  );

  // Sélection entreprise
  if (stage === STAGE.COMPANY) return (
    <CompanySelector
      companies={companies}
      subscription={subscription}
      user={profile}
      onSelect={openCompany}
      onCreated={async (co) => {
        const { data: cos } = await companiesApi.list();
        setCompanies(cos || []);
        await openCompany(co);
      }}
    />
  );

  // Application comptable principale
  if (stage === STAGE.APP && appState) return (
    <AppAccounting
      initialState={appState}
      companyId={company.id}
      user={profile}
      subscription={subscription}
      onLogout={handleLogout}
      onSwitchCompany={handleSwitchCompany}
    />
  );

  return null;
}
