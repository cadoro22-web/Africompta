import { useState, useReducer, useMemo, useEffect, useCallback, useRef } from "react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";


// ─── NEXUS CORP — FUTURISTIC DESIGN SYSTEM ───────────────────────────────────
const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@300;400;500;600;700&family=Exo+2:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,400&family=Share+Tech+Mono&display=swap');

  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}

  :root{
    --void:#020810;
    --space:#05101f;
    --cosmos:#081428;
    --nebula:#0b1a35;
    --aurora:#0f2248;
    --dim:#162c5a;
    --b1:#0e2040;
    --b2:#1a3060;
    --b3:#2050a0;
    --b4:#3070c0;

    --cyan:#00e5ff;
    --cyan2:#00b8d4;
    --cyan3:#80deea;
    --cyan-g:rgba(0,229,255,.1);
    --cyan-g2:rgba(0,229,255,.05);
    --cyan-g3:rgba(0,229,255,.03);

    --pink:#ff0080;
    --pink2:#ff4db2;
    --pink-g:rgba(255,0,128,.1);

    --lime:#39ff14;
    --lime2:#76ff03;
    --lime-g:rgba(57,255,20,.1);
    --lime-g2:rgba(57,255,20,.06);

    --amber:#ffab00;
    --amber2:#ffd740;
    --amber-g:rgba(255,171,0,.1);

    --red:#ff1744;
    --red2:#ff5252;
    --red-g:rgba(255,23,68,.1);

    --purple:#d500f9;
    --purple2:#ea80fc;

    --tx:#cce8f0;
    --tx2:#5ea8bc;
    --tx3:#2e6a7e;
    --tx4:#1a3d4d;

    --fh:'Rajdhani',sans-serif;
    --fb:'Exo 2',sans-serif;
    --fm:'Share Tech Mono',monospace;

    --glow-c:0 0 10px rgba(0,229,255,.35),0 0 30px rgba(0,229,255,.1);
    --glow-p:0 0 10px rgba(255,0,128,.35),0 0 30px rgba(255,0,128,.1);
    --glow-l:0 0 10px rgba(57,255,20,.35),0 0 30px rgba(57,255,20,.1);
    --glow-a:0 0 10px rgba(255,171,0,.35),0 0 30px rgba(255,171,0,.1);

    /* ── Aliases compatibilité — anciens tokens ERP remappés vers NEXUS ── */
    /* Gris fonctionnels */
    --g0:var(--void);
    --g1:var(--b1);
    --g2:var(--b2);
    --g3:var(--b3);
    --g4:var(--tx3);
    --g5:var(--tx2);
    --g6:var(--tx2);
    --g7:var(--tx);
    --g8:var(--tx);
    /* Navy → Cyan NEXUS */
    --navy:#00e5ff;
    --navy2:#00b8d4;
    --navy3:#00b8d4;
    --navy4:#00e5ff;
    --navy-light:rgba(0,229,255,.12);
    --navy-pale:rgba(0,229,255,.08);
    --navy-mid:rgba(0,229,255,.25);
    /* Blanc / Surfaces → Void NEXUS */
    --white:#020810;
    --off:var(--space);
    --bg:var(--cosmos);
    --panel:var(--nebula);
    /* Vert → Lime NEXUS */
    --green:#39ff14;
    --green2:#76ff03;
    --green-bg:rgba(57,255,20,.1);
    --green-bd:rgba(57,255,20,.3);
    /* Rouge */
    --red-bg:rgba(255,23,68,.1);
    --red-bd:rgba(255,23,68,.3);
    /* Orange → Amber NEXUS */
    --orange:#ffab00;
    --orange2:#ffd740;
    --orange-bg:rgba(255,171,0,.1);
    --orange-bd:rgba(255,171,0,.3);
    /* Purple */
    --purple-bg:rgba(213,0,249,.08);
    /* Rayons angulaires */
    --r1:2px;
    --r2:4px;
    --r3:6px;
    --r4:10px;
    --r5:14px;
    /* Ombres */
    --sh1:0 1px 3px rgba(0,0,0,.4);
    --sh2:0 4px 12px rgba(0,0,0,.5);
    --sh3:0 8px 24px rgba(0,0,0,.6);
  }

  html,body{height:100%;overflow:hidden}
  body{
    background:var(--void);color:var(--tx);
    font-family:var(--fb);font-size:13px;
    -webkit-font-smoothing:antialiased;
  }
  /* ── scanlines ── */
  body::before{
    content:'';position:fixed;inset:0;
    background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,229,255,.012) 2px,rgba(0,229,255,.012) 4px);
    pointer-events:none;z-index:9999;
  }
  /* ── grid background ── */
  body::after{
    content:'';position:fixed;inset:0;
    background-image:linear-gradient(var(--b1) 1px,transparent 1px),linear-gradient(90deg,var(--b1) 1px,transparent 1px);
    background-size:40px 40px;pointer-events:none;z-index:0;opacity:.35;
  }

  *::-webkit-scrollbar{width:4px;height:4px}
  *::-webkit-scrollbar-track{background:var(--space)}
  *::-webkit-scrollbar-thumb{background:var(--b3);border-radius:2px}
  *::-webkit-scrollbar-thumb:hover{background:var(--cyan2)}

  /* ══════════════════════════
     APP SHELL
  ══════════════════════════ */
  .app{
    display:flex;flex-direction:column;height:100vh;
    position:relative;z-index:1;
    overflow:hidden;
  }

  /* ── TITLE BAR ── */
  .title-bar{
    height:32px;background:rgba(2,8,16,.95);
    border-bottom:1px solid var(--b2);
    display:flex;align-items:center;padding:0 12px;gap:10px;
    flex-shrink:0;backdrop-filter:blur(20px);
    position:relative;z-index:20;
  }
  .title-bar::after{
    content:'';position:absolute;bottom:0;left:0;right:0;height:1px;
    background:linear-gradient(90deg,transparent,var(--cyan2),transparent);
    opacity:.6;
  }
  .title-bar-logo{
    width:20px;height:20px;
    background:linear-gradient(135deg,var(--cyan-g),var(--pink-g));
    border:1px solid var(--cyan2);
    clip-path:polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px);
    display:flex;align-items:center;justify-content:center;
    font-family:var(--fh);font-weight:700;font-size:10px;
    color:var(--cyan);box-shadow:var(--glow-c);
    text-shadow:0 0 6px var(--cyan);flex-shrink:0;
  }
  .title-bar-text{
    font-family:var(--fh);font-size:12px;font-weight:600;
    color:var(--tx2);letter-spacing:2px;text-transform:uppercase;
  }
  .title-bar-sep{flex:1}
  .title-bar-info{
    font-family:var(--fm);font-size:10px;color:var(--tx3);
    letter-spacing:1.5px;text-transform:uppercase;
  }
  .title-bar-btns{display:flex;align-items:center;gap:5px;margin-left:10px}
  .title-bar-btn{
    width:11px;height:11px;border-radius:50%;cursor:pointer;
    transition:filter .15s;
  }
  .title-bar-btn:hover{filter:brightness(1.4)}

  /* ── MENU BAR ── */
  .menu-bar{
    height:28px;background:rgba(5,16,31,.92);
    border-bottom:1px solid var(--b1);
    display:flex;align-items:center;padding:0 8px;gap:0;
    flex-shrink:0;position:relative;z-index:15;
    backdrop-filter:blur(16px);
    user-select:none;
  }
  .menu-item{
    position:relative;
    padding:4px 11px;font-family:var(--fm);font-size:10px;
    color:var(--tx3);cursor:pointer;
    text-transform:uppercase;letter-spacing:1.5px;
    border:1px solid transparent;
    clip-path:polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px);
    transition:all .15s;
  }
  .menu-item:hover,.menu-item.open{
    color:var(--cyan);background:var(--cyan-g);
    border-color:rgba(0,229,255,.2);
  }
  .menu-dropdown{
    position:absolute;top:calc(100% + 2px);left:0;
    background:rgba(8,20,40,.98);border:1px solid var(--b3);
    min-width:200px;z-index:1000;
    backdrop-filter:blur(24px);
    clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px));
    box-shadow:0 12px 40px rgba(0,0,0,.8),0 0 20px rgba(0,229,255,.06);
    padding:4px;
    animation:dropIn .12s cubic-bezier(.4,0,.2,1);
  }
  @keyframes dropIn{from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}
  .md-item{
    display:flex;align-items:center;gap:10px;
    padding:7px 12px;font-family:var(--fm);font-size:10px;
    color:var(--tx2);cursor:pointer;
    letter-spacing:1px;border:1px solid transparent;
    transition:all .12s;
    clip-path:polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px);
  }
  .md-item:hover{color:var(--cyan);background:var(--cyan-g);border-color:rgba(0,229,255,.15)}
  .md-item.disabled{color:var(--tx4);cursor:default;opacity:.5}
  .md-item.disabled:hover{background:transparent;border-color:transparent;color:var(--tx4)}
  .md-icon{font-size:12px;width:16px;text-align:center;color:var(--cyan);flex-shrink:0}
  .md-sep{height:1px;background:var(--b2);margin:3px 4px}
  .md-shortcut{margin-left:auto;font-size:9px;color:var(--tx4);letter-spacing:1px;padding:1px 5px;border:1px solid var(--b2);border-radius:2px}

  /* ── RIBBON ── */
  .ribbon{
    height:52px;background:rgba(8,20,40,.85);
    border-bottom:1px solid var(--b2);
    display:flex;align-items:center;padding:0 10px;gap:2px;
    flex-shrink:0;backdrop-filter:blur(12px);
    position:relative;z-index:10;
  }
  .ribbon::after{
    content:'';position:absolute;bottom:0;left:0;right:0;height:1px;
    background:linear-gradient(90deg,transparent,var(--pink),var(--cyan),transparent);
    opacity:.3;
  }
  .rbtn{
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:3px;padding:5px 10px;cursor:pointer;
    border:1px solid transparent;background:transparent;
    color:var(--tx3);transition:all .15s;min-width:48px;
    clip-path:polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px);
    font-family:var(--fh);
  }
  .rbtn:hover{color:var(--cyan);background:var(--cyan-g);border-color:rgba(0,229,255,.25);box-shadow:var(--glow-c)}
  .rbtn.primary{color:var(--cyan);background:var(--cyan-g);border-color:rgba(0,229,255,.3)}
  .rbtn-icon{font-size:14px;line-height:1}
  .rbtn-txt{font-size:9px;font-family:var(--fm);letter-spacing:1px;text-transform:uppercase;white-space:nowrap}
  .ribbon-sep{width:1px;height:32px;background:var(--b2);margin:0 4px;flex-shrink:0}

  /* ── BODY ── */
  .body{
    flex:1;display:flex;overflow:hidden;position:relative;
  }

  /* ── NAVPANEL ── */
  .navpanel{
    width:220px;background:rgba(5,16,31,.9);
    border-right:1px solid var(--b2);
    display:flex;flex-direction:column;flex-shrink:0;overflow-y:auto;
    backdrop-filter:blur(16px);position:relative;
  }
  .navpanel::before{
    content:'';position:absolute;top:0;left:0;right:0;height:2px;
    background:linear-gradient(90deg,transparent,var(--cyan),transparent);
    animation:nb 3s ease-in-out infinite;
  }
  @keyframes nb{0%,100%{opacity:.5}50%{opacity:1}}

  .navpanel-header{
    padding:14px 14px 12px;border-bottom:1px solid var(--b1);
    display:flex;align-items:center;gap:10px;
  }
  .navpanel-logo{
    width:34px;height:34px;flex-shrink:0;
    background:var(--cyan-g);border:1px solid var(--cyan2);
    clip-path:polygon(5px 0%,100% 0%,100% calc(100% - 5px),calc(100% - 5px) 100%,0% 100%,0% 5px);
    display:flex;align-items:center;justify-content:center;
    font-family:var(--fh);font-weight:700;font-size:14px;
    color:var(--cyan);box-shadow:var(--glow-c);
    text-shadow:0 0 8px var(--cyan);
  }
  .navpanel-name{
    font-family:var(--fh);font-size:1rem;font-weight:700;
    color:var(--tx);letter-spacing:1.5px;text-transform:uppercase;
  }
  .navpanel-name em{color:var(--cyan);font-style:normal;text-shadow:0 0 6px var(--cyan)}
  .navpanel-sub{font-size:9px;color:var(--tx4);font-family:var(--fm);letter-spacing:1.5px;margin-top:2px}

  .nav-section{
    padding:12px 14px 4px;font-family:var(--fm);
    font-size:8px;color:var(--tx4);letter-spacing:3px;text-transform:uppercase;
  }
  .nav-item{
    display:flex;align-items:center;gap:8px;
    padding:7px 12px;margin:1px 6px;
    cursor:pointer;border:1px solid transparent;
    color:var(--tx3);font-size:12.5px;font-weight:500;
    font-family:var(--fb);letter-spacing:.5px;
    transition:all .15s;
    clip-path:polygon(0 0,calc(100% - 5px) 0,100% 5px,100% 100%,0 100%);
  }
  .nav-item:hover{color:var(--tx);background:var(--cyan-g2);border-left:2px solid var(--cyan2)}
  .nav-item.active{
    color:var(--cyan);background:var(--cyan-g);
    border-left:2px solid var(--cyan);
    text-shadow:0 0 8px rgba(0,229,255,.4);
    box-shadow:inset 0 0 15px rgba(0,229,255,.04);
  }
  .nav-icon{
    width:24px;height:24px;border:1px solid var(--b2);
    display:flex;align-items:center;justify-content:center;
    font-size:11px;flex-shrink:0;background:var(--cosmos);
    clip-path:polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px);
    transition:all .15s;
  }
  .nav-item.active .nav-icon{background:var(--cyan-g);border-color:var(--cyan2);box-shadow:0 0 5px rgba(0,229,255,.25)}
  .nav-badge{
    margin-left:auto;padding:1px 6px;font-size:9px;font-weight:700;
    font-family:var(--fm);letter-spacing:1px;
    clip-path:polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px);
  }
  .nav-badge.warn{background:var(--amber);color:var(--void);box-shadow:var(--glow-a)}

  .navpanel-bottom{
    margin-top:auto;padding:10px 12px 14px;border-top:1px solid var(--b1);
  }
  .status-pill{
    display:flex;align-items:center;gap:7px;
    padding:5px 9px;border:1px solid var(--b1);
    background:var(--cosmos);margin-bottom:7px;
    clip-path:polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px);
  }
  .status-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
  .status-dot.ok{background:var(--lime);box-shadow:var(--glow-l)}
  .status-dot.busy{background:var(--amber);animation:pulse-d .8s infinite}
  @keyframes pulse-d{0%,100%{opacity:1}50%{opacity:.2}}
  .status-text{font-family:var(--fm);font-size:9px;color:var(--tx3);letter-spacing:1px;text-transform:uppercase}
  .nav-actions{display:grid;grid-template-columns:1fr 1fr 1fr;gap:3px;margin-bottom:8px}
  .nav-act{
    padding:4px 4px;font-family:var(--fm);font-size:9px;
    border:1px solid var(--b2);background:var(--cosmos);
    color:var(--tx3);cursor:pointer;letter-spacing:1px;
    text-transform:uppercase;transition:all .15s;
    clip-path:polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px);
  }
  .nav-act:hover{border-color:var(--cyan2);color:var(--cyan);background:var(--cyan-g)}
  .nav-company{font-size:9px;color:var(--tx4);font-family:var(--fm);letter-spacing:1.5px;text-transform:uppercase}

  /* ── WORKSPACE ── */
  .workspace{flex:1;display:flex;flex-direction:column;overflow:hidden}

  /* ── ADDRESS BAR ── */
  .addressbar{
    height:30px;background:rgba(8,20,40,.8);
    border-bottom:1px solid var(--b1);
    display:flex;align-items:center;padding:0 14px;gap:8px;
    flex-shrink:0;font-family:var(--fm);font-size:10px;
    backdrop-filter:blur(10px);
  }
  .addr-module{color:var(--tx3);text-transform:uppercase;letter-spacing:2px}
  .addr-sep{color:var(--b3);font-size:12px}
  .addr-page{color:var(--cyan);letter-spacing:2px;text-transform:uppercase;text-shadow:0 0 8px rgba(0,229,255,.4)}
  .addr-right{margin-left:auto;display:flex;align-items:center;gap:8px}
  .addr-tag{
    padding:2px 8px;font-size:9px;font-weight:600;letter-spacing:2px;
    clip-path:polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px);
  }
  .addr-tag.blue{background:var(--cyan-g);color:var(--cyan);border:1px solid rgba(0,229,255,.25)}
  .addr-tag.green{background:var(--lime-g);color:var(--lime);border:1px solid rgba(57,255,20,.25)}
  .addr-date{color:var(--tx4);font-size:9px;letter-spacing:1px}

  /* ── CONTENT ── */
  .content{flex:1;overflow-y:auto;padding:18px 20px}

  /* ── STATUS BAR ── */
  .statusbar{
    height:22px;background:rgba(2,8,16,.95);
    border-top:1px solid var(--b1);
    display:flex;align-items:center;padding:0 10px;gap:0;
    flex-shrink:0;font-family:var(--fm);font-size:9px;
    backdrop-filter:blur(20px);
  }
  .sb-item{color:var(--tx3);padding:0 8px;letter-spacing:1px;text-transform:uppercase}
  .sb-item span{color:var(--cyan2)}
  .sb-sep{width:1px;height:12px;background:var(--b2)}
  .sb-right{margin-left:auto}
  .sb-ok{color:var(--lime) !important;text-shadow:0 0 5px rgba(57,255,20,.3)}

  /* ══════════════════════════
     COMPONENTS
  ══════════════════════════ */

  /* ── KPI GRID ── */
  .kpi-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px;margin-bottom:20px}
  .kpi-card,.stat-card{
    background:rgba(11,26,53,.8);border:1px solid var(--b2);
    padding:14px 16px;position:relative;overflow:hidden;
    clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px));
    backdrop-filter:blur(10px);transition:border-color .2s;cursor:default;
  }
  .kpi-card:hover,.stat-card:hover{border-color:var(--b4)}
  .kpi-card::before,.stat-card::before{
    content:'';position:absolute;top:0;right:12px;left:0;height:1px;
    background:linear-gradient(90deg,transparent,var(--accent-color,var(--cyan)));
    opacity:.6;
  }
  .kpi-top,.stat-card-top{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:10px}
  .kpi-icon,.stat-card-icon{
    width:34px;height:34px;border:1px solid var(--b2);
    display:flex;align-items:center;justify-content:center;
    font-size:15px;flex-shrink:0;background:var(--cosmos);
    clip-path:polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px);
  }
  .kpi-lbl,.stat-lbl{
    font-size:8.5px;color:var(--tx3);text-transform:uppercase;
    letter-spacing:2.5px;font-family:var(--fm);margin-bottom:4px;
  }
  .kpi-val,.stat-val{
    font-family:var(--fh);font-size:1.3rem;font-weight:700;
    color:var(--tx);letter-spacing:1px;line-height:1.1;
    text-shadow:0 0 15px rgba(0,229,255,.12);
  }
  .kpi-sub,.stat-sub{font-size:9.5px;color:var(--tx4);font-family:var(--fm);margin-top:4px}
  .stat-trend{
    display:flex;align-items:center;gap:3px;
    padding:2px 7px;font-size:9px;font-weight:600;
    font-family:var(--fm);letter-spacing:1px;
  }
  .stat-trend.up{background:var(--lime-g);color:var(--lime);border:1px solid rgba(57,255,20,.2)}
  .stat-trend.down{background:var(--red-g);color:var(--red2);border:1px solid rgba(255,23,68,.2)}
  .stat-trend.neutral{background:var(--cyan-g);color:var(--cyan);border:1px solid rgba(0,229,255,.2)}
  .stat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px;margin-bottom:20px}

  /* ── PANELS ── */
  .panel{
    background:rgba(11,26,53,.7);border:1px solid var(--b2);
    clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px));
    backdrop-filter:blur(12px);overflow:hidden;
  }
  .panel-hdr{
    display:flex;align-items:center;justify-content:space-between;
    padding:10px 14px;background:rgba(15,34,72,.7);border-bottom:1px solid var(--b2);
  }
  .panel-title{
    font-family:var(--fh);font-size:.9rem;font-weight:600;
    color:var(--tx);text-transform:uppercase;letter-spacing:2px;
    display:flex;align-items:center;gap:8px;
  }
  .panel-title-dot{
    width:7px;height:7px;border-radius:50%;background:var(--cyan);
    box-shadow:var(--glow-c);animation:pulse-d 2s infinite;
  }
  .panel-body{padding:14px}

  /* ── CARD (alias) ── */
  .card{
    background:rgba(11,26,53,.7);border:1px solid var(--b2);
    padding:16px 18px;
    clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px));
    backdrop-filter:blur(12px);position:relative;
  }
  .card::before{
    content:'';position:absolute;top:0;right:14px;left:0;height:1px;
    background:linear-gradient(90deg,transparent,var(--b4));
  }
  .card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
  .card-title{font-family:var(--fh);font-size:.9rem;font-weight:600;color:var(--tx);text-transform:uppercase;letter-spacing:2px}
  .card-sub{font-size:9.5px;color:var(--tx4);font-family:var(--fm);margin-top:2px;letter-spacing:1px}

  /* ── CHART CARDS ── */
  .chart-card{
    background:rgba(11,26,53,.7);border:1px solid var(--b2);padding:16px 18px;
    clip-path:polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px));
    backdrop-filter:blur(12px);position:relative;
  }
  .chart-card::before{
    content:'';position:absolute;top:0;right:14px;left:0;height:1px;
    background:linear-gradient(90deg,transparent,var(--cyan2));opacity:.5;
  }
  .chart-title{font-family:var(--fh);font-size:.85rem;font-weight:600;color:var(--tx);text-transform:uppercase;letter-spacing:2px;margin-bottom:3px}
  .chart-sub{font-size:9px;color:var(--tx4);font-family:var(--fm);margin-bottom:12px;letter-spacing:1.5px}
  .rc-tooltip{
    background:rgba(11,26,53,.95) !important;border:1px solid var(--b3) !important;
    box-shadow:var(--glow-c) !important;font-family:var(--fm) !important;font-size:10px !important;
    padding:8px 12px !important;
  }

  /* ── SECTION HEADER ── */
  .section-header{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:18px}
  .section-title{
    font-family:var(--fh);font-size:1.5rem;font-weight:700;
    color:var(--tx);text-transform:uppercase;letter-spacing:3px;
    text-shadow:0 0 25px rgba(0,229,255,.18);
  }
  .section-sub{font-size:9.5px;color:var(--tx3);font-family:var(--fm);margin-top:4px;letter-spacing:1.5px}

  /* ── TABLE ── */
  .table-wrap{
    overflow-x:auto;border:1px solid var(--b2);
    background:rgba(8,20,40,.75);
    clip-path:polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px));
    backdrop-filter:blur(10px);position:relative;
  }
  .table-wrap::before{
    content:'';position:absolute;top:0;right:10px;left:0;height:1px;
    background:linear-gradient(90deg,transparent,var(--cyan2),transparent);opacity:.4;
  }
  table{width:100%;border-collapse:collapse}
  thead{background:rgba(15,34,72,.9)}
  th{
    padding:9px 14px;text-align:left;font-family:var(--fm);
    font-size:9px;color:var(--cyan2);text-transform:uppercase;
    letter-spacing:3px;white-space:nowrap;border-bottom:1px solid var(--b2);
    border-right:1px solid rgba(0,229,255,.04);
  }
  td{
    padding:8px 14px;border-bottom:1px solid var(--b1);
    color:var(--tx2);font-size:12.5px;vertical-align:middle;
    font-family:var(--fb);
    border-right:1px solid rgba(0,229,255,.03);
  }
  tr:last-child td{border-bottom:none}
  tbody tr{transition:background .1s}
  tbody tr:hover td{background:var(--cyan-g3);color:var(--tx)}
  tfoot tr td{border-top:1px solid var(--b3) !important;background:rgba(15,34,72,.8)}
  .mono{font-family:var(--fm);font-size:11.5px;letter-spacing:.5px}

  /* ── BUTTONS ── */
  .btn{
    display:inline-flex;align-items:center;gap:6px;
    padding:7px 16px;cursor:pointer;border:1px solid;
    font-family:var(--fh);font-size:11px;font-weight:600;
    transition:all .15s;white-space:nowrap;
    text-transform:uppercase;letter-spacing:2px;
    clip-path:polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px);
  }
  .btn:active{transform:scale(.97)}
  .btn-primary{
    background:var(--cyan-g);border-color:var(--cyan2);color:var(--cyan);
    box-shadow:0 0 12px rgba(0,229,255,.15),inset 0 0 15px rgba(0,229,255,.04);
  }
  .btn-primary:hover{background:var(--cyan);color:var(--void);box-shadow:var(--glow-c)}
  .btn-green{background:var(--lime-g);border-color:rgba(57,255,20,.35);color:var(--lime)}
  .btn-green:hover{background:var(--lime);color:var(--void);box-shadow:var(--glow-l)}
  .btn-outline{background:transparent;border-color:var(--b3);color:var(--tx2)}
  .btn-outline:hover{border-color:var(--cyan2);color:var(--cyan);background:var(--cyan-g)}
  .btn-ghost{background:transparent;border-color:transparent;color:var(--tx3)}
  .btn-ghost:hover{color:var(--tx);background:var(--nebula);border-color:var(--b2)}
  .btn-danger{background:var(--red-g);border-color:rgba(255,23,68,.3);color:var(--red2)}
  .btn-danger:hover{background:var(--red);color:var(--void);box-shadow:var(--glow-p);border-color:var(--red)}
  .btn-sm{padding:5px 12px;font-size:9.5px}
  .btn-xs{padding:3px 9px;font-size:9px}

  /* ── BADGES ── */
  .badge{
    display:inline-flex;align-items:center;
    padding:2px 8px;font-size:8.5px;font-weight:600;
    font-family:var(--fm);white-space:nowrap;
    text-transform:uppercase;letter-spacing:1.5px;
    clip-path:polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px);
  }
  .badge-green,.badge-jade{background:var(--lime-g);color:var(--lime);border:1px solid rgba(57,255,20,.25)}
  .badge-red{background:var(--red-g);color:var(--red2);border:1px solid rgba(255,23,68,.25)}
  .badge-orange,.badge-amber,.badge-gold,.badge-warn{background:var(--amber-g);color:var(--amber2);border:1px solid rgba(255,171,0,.25)}
  .badge-blue{background:var(--cyan-g);color:var(--cyan);border:1px solid rgba(0,229,255,.25)}
  .badge-rose,.badge-pink{background:var(--pink-g);color:var(--pink2);border:1px solid rgba(255,0,128,.25)}
  .badge-purple{background:rgba(213,0,249,.08);color:var(--purple2);border:1px solid rgba(213,0,249,.25)}
  .badge-gray{background:var(--nebula);color:var(--tx3);border:1px solid var(--b2)}

  /* ── TABS ── */
  .tabs{
    display:flex;gap:2px;background:rgba(8,20,40,.8);border:1px solid var(--b2);
    padding:3px;margin-bottom:18px;
    clip-path:polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px));
  }
  .tab{
    flex:1;padding:6px 12px;cursor:pointer;border:1px solid transparent;
    background:transparent;color:var(--tx3);
    font-family:var(--fm);font-size:9.5px;
    transition:all .15s;text-align:center;
    text-transform:uppercase;letter-spacing:2px;
  }
  .tab:hover{color:var(--tx);background:var(--cyan-g3)}
  .tab.active{
    background:var(--cyan-g);color:var(--cyan);
    border-color:rgba(0,229,255,.2);
    box-shadow:0 0 8px rgba(0,229,255,.08);
    text-shadow:0 0 6px rgba(0,229,255,.4);
  }

  /* ── FORMS ── */
  .form-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:12px}
  .form-group{display:flex;flex-direction:column;gap:5px}
  .form-group.full{grid-column:1/-1}
  label{font-size:8.5px;font-weight:600;color:var(--tx3);text-transform:uppercase;letter-spacing:2px;font-family:var(--fm)}
  input,select,textarea{
    background:var(--cosmos);border:1px solid var(--b2);
    padding:8px 11px;color:var(--tx);
    font-family:var(--fm);font-size:12px;outline:none;
    transition:border-color .15s,box-shadow .15s;width:100%;
    clip-path:polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px);
    letter-spacing:.5px;
  }
  input:focus,select:focus,textarea:focus{
    border-color:var(--cyan2);
    box-shadow:0 0 0 2px rgba(0,229,255,.08),var(--glow-c);
  }
  input::placeholder{color:var(--tx4)}
  select option{background:var(--nebula);color:var(--tx)}

  /* ── MODAL ── */
  .modal-overlay{
    position:fixed;inset:0;background:rgba(2,8,16,.82);
    backdrop-filter:blur(8px);z-index:200;
    display:flex;align-items:center;justify-content:center;padding:20px;
    animation:fadeIn .15s ease;
  }
  @keyframes fadeIn{from{opacity:0}to{opacity:1}}
  .modal{
    background:rgba(11,26,53,.95);border:1px solid var(--b3);
    padding:24px 26px;width:100%;max-width:680px;max-height:90vh;overflow-y:auto;
    clip-path:polygon(0 0,calc(100% - 18px) 0,100% 18px,100% 100%,18px 100%,0 calc(100% - 18px));
    backdrop-filter:blur(24px);
    box-shadow:0 0 50px rgba(0,229,255,.06),0 20px 60px rgba(0,0,0,.8);
    animation:slideUp .18s cubic-bezier(.4,0,.2,1);position:relative;
  }
  .modal::before{
    content:'';position:absolute;top:0;right:18px;left:0;height:1px;
    background:linear-gradient(90deg,transparent,var(--cyan),transparent);
  }
  @keyframes slideUp{from{transform:translateY(14px);opacity:0}to{transform:translateY(0);opacity:1}}
  .modal-titlebar{
    display:flex;align-items:center;gap:10px;
    margin-bottom:18px;padding-bottom:14px;border-bottom:1px solid var(--b1);
  }
  .modal-title-icon{font-size:16px;flex-shrink:0}
  .modal-title{
    font-family:var(--fh);font-size:1.1rem;font-weight:700;
    color:var(--cyan);text-transform:uppercase;letter-spacing:2.5px;
    text-shadow:0 0 10px rgba(0,229,255,.35);
  }
  .modal-subtitle{font-size:9.5px;color:var(--tx4);font-family:var(--fm);margin-top:2px;letter-spacing:1.5px}
  .modal-close{
    margin-left:auto;background:var(--cosmos);border:1px solid var(--b2);
    color:var(--tx3);cursor:pointer;font-size:12px;width:26px;height:26px;
    display:flex;align-items:center;justify-content:center;transition:all .15s;
    clip-path:polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px);
    flex-shrink:0;
  }
  .modal-close:hover{border-color:var(--pink);color:var(--pink);box-shadow:var(--glow-p)}
  .modal-body{margin-bottom:6px}
  .modal-footer{
    display:flex;align-items:center;justify-content:flex-end;gap:8px;
    margin-top:18px;padding-top:14px;border-top:1px solid var(--b1);
  }

  /* ── DIVIDER ── */
  .divider{height:1px;margin:12px 0;background:linear-gradient(90deg,transparent,var(--b3),transparent)}

  /* ── COLOR UTILS ── */
  .text-rose,.text-pink{color:var(--pink2)}
  .text-vert,.text-green,.text-jade,.text-lime{color:var(--lime)}
  .text-red{color:var(--red2)}
  .text-orange,.text-amber,.text-gold{color:var(--amber2)}
  .text-blue,.text-cyan{color:var(--cyan)}
  .text-muted{color:var(--tx3)}

  /* ── LAYOUT UTILS ── */
  .flex{display:flex}.items-center{align-items:center}.justify-between{justify-content:space-between}
  .gap-6{gap:6px}.gap-8{gap:8px}.gap-10{gap:10px}.gap-12{gap:12px}.gap-16{gap:16px}.gap-20{gap:20px}
  .mb-10{margin-bottom:10px}.mb-12{margin-bottom:12px}.mb-16{margin-bottom:16px}.mb-20{margin-bottom:20px}
  .grid-2{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  .grid-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}
  .w-full{width:100%}.text-right{text-align:right}

  /* ── LIST ITEMS ── */
  .list-item{
    display:flex;align-items:center;justify-content:space-between;
    padding:8px 0;border-bottom:1px solid var(--b1);transition:padding-left .1s;
  }
  .list-item:last-child{border-bottom:none;padding-bottom:0}
  .list-item:first-child{padding-top:0}
  .list-item:hover{padding-left:4px;border-left:2px solid var(--cyan2)}

  /* ── GL CARD ── */
  .gl-card{
    background:rgba(8,20,40,.8);border:1px solid var(--b2);margin-bottom:10px;overflow:hidden;
    clip-path:polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px));
  }
  .gl-card-header{
    display:flex;align-items:center;justify-content:space-between;
    padding:10px 14px;background:rgba(15,34,72,.8);border-bottom:1px solid var(--b2);
  }

  /* ── EMPTY STATE ── */
  .empty{display:flex;flex-direction:column;align-items:center;padding:40px 20px;color:var(--tx4);gap:10px}
  .empty-icon{font-size:2.2rem;opacity:.25}
  .empty-text{font-size:10px;font-family:var(--fm);letter-spacing:2.5px;text-transform:uppercase}

  /* ── BILAN ── */
  .bilan-section-title{
    padding:6px 12px;background:var(--cyan-g);font-size:8.5px;
    font-weight:600;color:var(--cyan);text-transform:uppercase;
    letter-spacing:3px;margin-bottom:3px;font-family:var(--fm);
    border-left:2px solid var(--cyan);
  }
  .bilan-row{display:flex;justify-content:space-between;align-items:center;padding:6px 12px;border-bottom:1px solid var(--b1);font-size:12.5px}
  .bilan-row:last-child{border-bottom:none}
  .bilan-total{display:flex;justify-content:space-between;align-items:center;padding:10px 12px;margin-top:6px;font-weight:700;font-size:14px;border-top:1px solid var(--b3)}
  .resultat-box{
    padding:18px 22px;display:flex;align-items:center;justify-content:space-between;
    margin-top:18px;
    clip-path:polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px));
  }

  /* ── RECHARTS ── */
  .recharts-cartesian-grid-horizontal line,.recharts-cartesian-grid-vertical line{stroke:var(--b2) !important}
  .recharts-text{fill:var(--tx3) !important;font-family:var(--fm) !important;font-size:9px !important}
  .recharts-legend-item-text{color:var(--tx2) !important;font-family:var(--fm) !important;font-size:9px !important}

  /* ── PROGRESS BAR ── */
  .progress-bar{height:4px;background:var(--b1);overflow:hidden}
  .progress-fill{height:100%;background:linear-gradient(90deg,var(--cyan2),var(--cyan));transition:width .4s;box-shadow:var(--glow-c)}

  @media print{
    .navpanel,.title-bar,.menu-bar,.ribbon,.addressbar,.statusbar{display:none}
    .workspace,.body,.content{display:block;overflow:visible}
    body{background:white;color:black}
    body::before,body::after{display:none}
    .modal-overlay{position:static;background:none;backdrop-filter:none}
    .modal{box-shadow:none;border:none;max-height:none;clip-path:none}
  }
`;
// ─── HELPERS ─────────────────────────────────────────────────────────────────
const fmt=(n,d="FCFA")=>{if(n===undefined||n===null)return"0 "+(d||"");return new Intl.NumberFormat("fr-FR",{minimumFractionDigits:0,maximumFractionDigits:0}).format(n)+(d?" "+d:"");};
const fmtDate=d=>d?new Date(d).toLocaleDateString("fr-FR"):"—";
const calcLignes=(lignes,tauxTVA=18)=>{const ht=lignes.reduce((s,l)=>s+(l.qte||0)*(l.pu||0),0);const tva=lignes.reduce((s,l)=>s+((l.tva?l.tva:tauxTVA)/100)*(l.qte||0)*(l.pu||0),0);return{ht,tva,ttc:ht+tva};};
const genId=()=>Date.now()+Math.floor(Math.random()*1000);

// ─── MODAL ───────────────────────────────────────────────────────────────────
function Modal({title,sub,icon="📋",onClose,children,width=680}){
  return <div className="modal-overlay" onClick={onClose}>
    <div className="modal" style={{maxWidth:width}} onClick={e=>e.stopPropagation()}>
      <div className="modal-titlebar">
        <div className="modal-title-icon">{icon}</div>
        <div className="modal-title">{title}</div>
        {sub&&<div className="modal-subtitle">{sub}</div>}
        <button className="modal-close" onClick={onClose}>✕</button>
      </div>
      <div className="modal-body">{children}</div>
    </div>
  </div>;
}

// ─── CUSTOM TOOLTIP ───────────────────────────────────────────────────────────
const CustomTooltip=({active,payload,label,devise})=>{
  if(!active||!payload||!payload.length)return null;
  return <div className="rc-tooltip">
    <div style={{fontWeight:700,color:"var(--g7)",marginBottom:5,fontSize:11,textTransform:"uppercase",letterSpacing:"1px"}}>{label}</div>
    {payload.map((p,i)=><div key={i} style={{display:"flex",justifyContent:"space-between",gap:14,color:p.color,fontSize:11}}>
      <span>{p.name}</span>
      <span style={{fontFamily:"var(--fm)",fontWeight:600}}>{fmt(p.value,devise)}</span>
    </div>)}
  </div>;
};

// ─── DATA ────────────────────────────────────────────────────────────────────
const OHADA_COMPTES = [
  {code:"101000",libelle:"Capital social",classe:"1",type:"passif"},
  {code:"106000",libelle:"Réserves",classe:"1",type:"passif"},
  {code:"120000",libelle:"Résultat de l'exercice",classe:"1",type:"passif"},
  {code:"161000",libelle:"Emprunts bancaires",classe:"1",type:"passif"},
  {code:"211000",libelle:"Terrains",classe:"2",type:"actif"},
  {code:"221000",libelle:"Bâtiments",classe:"2",type:"actif"},
  {code:"241000",libelle:"Matériel et mobilier",classe:"2",type:"actif"},
  {code:"244000",libelle:"Matériel informatique",classe:"2",type:"actif"},
  {code:"281000",libelle:"Amort. bâtiments",classe:"2",type:"actif"},
  {code:"284000",libelle:"Amort. matériel",classe:"2",type:"actif"},
  {code:"311000",libelle:"Marchandises",classe:"3",type:"actif"},
  {code:"321000",libelle:"Matières premières",classe:"3",type:"actif"},
  {code:"351000",libelle:"Produits finis",classe:"3",type:"actif"},
  {code:"401000",libelle:"Fournisseurs",classe:"4",type:"passif"},
  {code:"411000",libelle:"Clients",classe:"4",type:"actif"},
  {code:"421000",libelle:"Personnel - Rémunérations dues",classe:"4",type:"passif"},
  {code:"431000",libelle:"CNPS",classe:"4",type:"passif"},
  {code:"441000",libelle:"État - Impôts sur bénéfices",classe:"4",type:"passif"},
  {code:"445000",libelle:"TVA collectée",classe:"4",type:"passif"},
  {code:"445100",libelle:"TVA déductible",classe:"4",type:"actif"},
  {code:"471000",libelle:"Débiteurs divers",classe:"4",type:"actif"},
  {code:"472000",libelle:"Créditeurs divers",classe:"4",type:"passif"},
  {code:"521000",libelle:"Banque locale",classe:"5",type:"actif"},
  {code:"522000",libelle:"Banque étrangère",classe:"5",type:"actif"},
  {code:"571000",libelle:"Caisse principale",classe:"5",type:"actif"},
  {code:"601000",libelle:"Achats de marchandises",classe:"6",type:"charge"},
  {code:"602000",libelle:"Achats matières premières",classe:"6",type:"charge"},
  {code:"604000",libelle:"Achats fournitures",classe:"6",type:"charge"},
  {code:"611000",libelle:"Transports sur achats",classe:"6",type:"charge"},
  {code:"621000",libelle:"Loyers et charges locatives",classe:"6",type:"charge"},
  {code:"625000",libelle:"Publicité et communication",classe:"6",type:"charge"},
  {code:"627000",libelle:"Services bancaires",classe:"6",type:"charge"},
  {code:"631000",libelle:"Rémunérations du personnel",classe:"6",type:"charge"},
  {code:"641000",libelle:"Impôts et taxes",classe:"6",type:"charge"},
  {code:"661000",libelle:"Intérêts des emprunts",classe:"6",type:"charge"},
  {code:"681000",libelle:"Dotations aux amortissements",classe:"6",type:"charge"},
  {code:"701000",libelle:"Ventes de marchandises",classe:"7",type:"produit"},
  {code:"702000",libelle:"Ventes de produits finis",classe:"7",type:"produit"},
  {code:"706000",libelle:"Prestations de services",classe:"7",type:"produit"},
  {code:"721000",libelle:"Production immobilisée",classe:"7",type:"produit"},
  {code:"751000",libelle:"Produits divers",classe:"7",type:"produit"},
  {code:"761000",libelle:"Revenus financiers",classe:"7",type:"produit"},
];

const PCG_COMPTES = [
  {code:"101000",libelle:"Capital",classe:"1",type:"passif"},
  {code:"106000",libelle:"Réserves",classe:"1",type:"passif"},
  {code:"120000",libelle:"Résultat de l'exercice",classe:"1",type:"passif"},
  {code:"164000",libelle:"Emprunts établissements de crédit",classe:"1",type:"passif"},
  {code:"211000",libelle:"Terrains",classe:"2",type:"actif"},
  {code:"213000",libelle:"Constructions",classe:"2",type:"actif"},
  {code:"215000",libelle:"Installations techniques",classe:"2",type:"actif"},
  {code:"218000",libelle:"Autres immobilisations corporelles",classe:"2",type:"actif"},
  {code:"280000",libelle:"Amortissements immobilisations",classe:"2",type:"actif"},
  {code:"310000",libelle:"Stocks de matières premières",classe:"3",type:"actif"},
  {code:"370000",libelle:"Stocks de marchandises",classe:"3",type:"actif"},
  {code:"401000",libelle:"Fournisseurs",classe:"4",type:"passif"},
  {code:"411000",libelle:"Clients",classe:"4",type:"actif"},
  {code:"421000",libelle:"Personnel - Rémunérations dues",classe:"4",type:"passif"},
  {code:"431000",libelle:"Sécurité sociale",classe:"4",type:"passif"},
  {code:"441000",libelle:"État - Impôts sur bénéfices",classe:"4",type:"passif"},
  {code:"445710",libelle:"TVA collectée",classe:"4",type:"passif"},
  {code:"445660",libelle:"TVA déductible",classe:"4",type:"actif"},
  {code:"512000",libelle:"Banques comptes courants",classe:"5",type:"actif"},
  {code:"530000",libelle:"Caisse",classe:"5",type:"actif"},
  {code:"601000",libelle:"Achats de matières premières",classe:"6",type:"charge"},
  {code:"607000",libelle:"Achats de marchandises",classe:"6",type:"charge"},
  {code:"613000",libelle:"Locations",classe:"6",type:"charge"},
  {code:"622000",libelle:"Honoraires",classe:"6",type:"charge"},
  {code:"623000",libelle:"Publicité",classe:"6",type:"charge"},
  {code:"627000",libelle:"Services bancaires",classe:"6",type:"charge"},
  {code:"641000",libelle:"Rémunérations du personnel",classe:"6",type:"charge"},
  {code:"661000",libelle:"Charges d'intérêts",classe:"6",type:"charge"},
  {code:"681000",libelle:"Dotations aux amortissements",classe:"6",type:"charge"},
  {code:"701000",libelle:"Ventes de produits finis",classe:"7",type:"produit"},
  {code:"706000",libelle:"Prestations de services",classe:"7",type:"produit"},
  {code:"707000",libelle:"Ventes de marchandises",classe:"7",type:"produit"},
  {code:"762000",libelle:"Produits des participations",classe:"7",type:"produit"},
];

const initialState = {
  config:{nomEntreprise:"Mon Entreprise",adresse:"Cotonou, Bénin",telephone:"",email:"",sigle:"",rccm:"",ifu:"",planComptable:"OHADA",devise:"FCFA",tauxTVA:18,exercice:{debut:"2025-01-01",fin:"2025-12-31"}},
  comptes: OHADA_COMPTES,
  articles:[
    {id:1,code:"ART001",designation:"Stylos BIC (boîte)",categorie:"Fournitures",unite:"boite",prixAchat:1500,prixVente:2500,stock:50,stockMin:10},
    {id:2,code:"ART002",designation:"Rames de papier A4",categorie:"Fournitures",unite:"rame",prixAchat:2800,prixVente:4000,stock:30,stockMin:5},
    {id:3,code:"ART003",designation:"Ordinateur portable",categorie:"Informatique",unite:"pièce",prixAchat:180000,prixVente:250000,stock:5,stockMin:2},
    {id:4,code:"ART004",designation:"Imprimante laser",categorie:"Informatique",unite:"pièce",prixAchat:95000,prixVente:130000,stock:3,stockMin:1},
  ],
  services:[
    {id:1,code:"SRV001",designation:"Consultation informatique",unite:"heure",prixUnitaire:15000,tva:true},
    {id:2,code:"SRV002",designation:"Maintenance réseau",unite:"forfait",prixUnitaire:50000,tva:true},
    {id:3,code:"SRV003",designation:"Formation bureautique",unite:"jour",prixUnitaire:25000,tva:true},
  ],
  clients:[
    {id:1,code:"CLI001",nom:"SONEB",adresse:"Cotonou",telephone:"21 30 00 00",email:"",solde:0},
    {id:2,code:"CLI002",nom:"Ministère des Finances",adresse:"Porto-Novo",telephone:"20 21 00 00",email:"",solde:0},
    {id:3,code:"CLI003",nom:"Pharmacie Centrale",adresse:"Abomey-Calavi",telephone:"21 14 00 00",email:"",solde:0},
  ],
  fournisseurs:[
    {id:1,code:"FRN001",nom:"CFAO Bénin",adresse:"Cotonou",telephone:"21 31 00 00",email:"",solde:0},
    {id:2,code:"FRN002",nom:"Nestlé West Africa",adresse:"Cotonou",telephone:"21 30 50 00",email:"",solde:0},
  ],
  factures:[
    {id:1,numero:"FC-2025-001",date:"2025-01-15",clientId:1,lignes:[{type:"article",refId:1,designation:"Stylos BIC (boîte)",qte:10,pu:2500,tva:18},{type:"service",refId:1,designation:"Consultation informatique",qte:3,pu:15000,tva:18}],statut:"payée",modePaiement:"virement",notes:""},
    {id:2,numero:"FC-2025-002",date:"2025-02-03",clientId:2,lignes:[{type:"article",refId:3,designation:"Ordinateur portable",qte:2,pu:250000,tva:18}],statut:"en attente",modePaiement:"",notes:""},
    {id:3,numero:"FC-2025-003",date:"2025-03-12",clientId:3,lignes:[{type:"service",refId:2,designation:"Maintenance réseau",qte:1,pu:50000,tva:18}],statut:"payée",modePaiement:"espèces",notes:""},
  ],
  achats:[
    {id:1,numero:"AC-2025-001",date:"2025-01-10",fournisseurId:1,lignes:[{refId:3,designation:"Ordinateur portable",qte:2,pu:180000,tva:18}],statut:"reçue",modePaiement:"virement",notes:""},
    {id:2,numero:"AC-2025-002",date:"2025-02-20",fournisseurId:2,lignes:[{refId:1,designation:"Stylos BIC (boîte)",qte:100,pu:1500,tva:18}],statut:"reçue",modePaiement:"espèces",notes:""},
  ],
  ecritures:[
    {id:1,date:"2025-01-01",journal:"AN",libelle:"A-Nouveau — Capital social",lignes:[{compteCode:"521000",libelle:"Banque",debit:5000000,credit:0},{compteCode:"101000",libelle:"Capital social",debit:0,credit:5000000}],reference:"AN2025-001",valide:true},
    {id:2,date:"2025-01-15",journal:"VT",libelle:"Facture FC-2025-001 — SONEB",lignes:[{compteCode:"411000",libelle:"Clients",debit:97100,credit:0},{compteCode:"701000",libelle:"Ventes de marchandises",debit:0,credit:25000},{compteCode:"706000",libelle:"Prestations de services",debit:0,credit:45000},{compteCode:"445000",libelle:"TVA collectée",debit:0,credit:12600}],reference:"FC-2025-001",valide:true},
  ],
  mouvementsStock:[
    {id:1,date:"2025-01-10",articleId:3,type:"entree",qte:2,motif:"Achat AC-2025-001",ref:"AC-2025-001"},
    {id:2,date:"2025-01-15",articleId:1,type:"sortie",qte:10,motif:"Vente FC-2025-001",ref:"FC-2025-001"},
    {id:3,date:"2025-02-20",articleId:1,type:"entree",qte:100,motif:"Achat AC-2025-002",ref:"AC-2025-002"},
  ],
  parametresPaie:{tauxCNPS_sal:3.6,tauxCNPS_pat:16.4,tauxITS:15,smig:52000,plafondCNPS:600000},
  employes:[
    {id:1,matricule:"EMP001",nom:"Kokou Adéyémi",poste:"Directeur Administratif",departement:"Direction",dateEmbauche:"2020-03-01",salBase:350000,primes:[{libelle:"Prime de responsabilité",montant:50000}],statut:"actif"},
    {id:2,matricule:"EMP002",nom:"Aïssatou Diallo",poste:"Comptable",departement:"Finance",dateEmbauche:"2021-07-15",salBase:200000,primes:[{libelle:"Prime de rendement",montant:20000}],statut:"actif"},
    {id:3,matricule:"EMP003",nom:"Rodrigue Houessou",poste:"Commercial",departement:"Ventes",dateEmbauche:"2022-01-10",salBase:150000,primes:[{libelle:"Commission ventes",montant:35000}],statut:"actif"},
  ],
  bulletins:[
    {id:1,mois:"2025-01",employeId:1,salBase:350000,primes:[{libelle:"Prime de responsabilité",montant:50000}],cotisations:{cnps_sal:14400,its:60000,cnps_pat:65600},salaireNet:325600,statut:"payé",date:"2025-01-31"},
    {id:2,mois:"2025-01",employeId:2,salBase:200000,primes:[{libelle:"Prime de rendement",montant:20000}],cotisations:{cnps_sal:7920,its:33000,cnps_pat:35920},salaireNet:179080,statut:"payé",date:"2025-01-31"},
  ],
  relevésBancaires:[
    {id:1,date:"2025-01-05",libelle:"Virement client SONEB",montant:97100,type:"credit",ref:"VIR-001",rapproché:false},
    {id:2,date:"2025-01-10",libelle:"Paiement fournisseur CFAO",montant:-212400,type:"debit",ref:"CHQ-001",rapproché:false},
    {id:3,date:"2025-01-31",libelle:"Salaires janvier",montant:-655234,type:"debit",ref:"VIR-PAI",rapproché:false},
    {id:4,date:"2025-02-03",libelle:"Virement client Ministère",montant:590000,type:"credit",ref:"VIR-002",rapproché:false},
  ],
  rapprochements:[],
  declarationsTVA:[
    {id:1,periode:"2025-01",tvaCollectee:22600,tvaDeductible:38232,tvaNette:-15632,statut:"déposée",dateDepot:"2025-02-15",ref:"TVA-2025-01"},
  ],
};

function reducer(state, action) {
  switch(action.type) {
    case "SET_CONFIG": return {...state, config:{...state.config,...action.payload}};
    case "SET_PLAN": return {...state, comptes:action.payload==="OHADA"?OHADA_COMPTES:PCG_COMPTES, config:{...state.config,planComptable:action.payload}};
    case "ADD_COMPTE": return {...state,comptes:[...state.comptes,action.payload]};
    case "DEL_COMPTE": return {...state,comptes:state.comptes.filter(c=>c.code!==action.payload)};
    case "ADD_ARTICLE": return {...state,articles:[...state.articles,action.payload]};
    case "UPD_ARTICLE": return {...state,articles:state.articles.map(a=>a.id===action.payload.id?action.payload:a)};
    case "DEL_ARTICLE": return {...state,articles:state.articles.filter(a=>a.id!==action.payload)};
    case "ADD_SERVICE": return {...state,services:[...state.services,action.payload]};
    case "DEL_SERVICE": return {...state,services:state.services.filter(s=>s.id!==action.payload)};
    case "ADD_CLIENT": return {...state,clients:[...state.clients,action.payload]};
    case "DEL_CLIENT": return {...state,clients:state.clients.filter(c=>c.id!==action.payload)};
    case "ADD_FOURNISSEUR": return {...state,fournisseurs:[...state.fournisseurs,action.payload]};
    case "DEL_FOURNISSEUR": return {...state,fournisseurs:state.fournisseurs.filter(f=>f.id!==action.payload)};
    case "ADD_FACTURE": return {...state,factures:[...state.factures,action.payload]};
    case "UPD_FACTURE": return {...state,factures:state.factures.map(f=>f.id===action.payload.id?action.payload:f)};
    case "DEL_FACTURE": return {...state,factures:state.factures.filter(f=>f.id!==action.payload)};
    case "ADD_ACHAT": return {...state,achats:[...state.achats,action.payload]};
    case "UPD_ACHAT": return {...state,achats:state.achats.map(a=>a.id===action.payload.id?action.payload:a)};
    case "DEL_ACHAT": return {...state,achats:state.achats.filter(a=>a.id!==action.payload)};
    case "ADD_ECRITURE": return {...state,ecritures:[...state.ecritures,action.payload]};
    case "DEL_ECRITURE": return {...state,ecritures:state.ecritures.filter(e=>e.id!==action.payload)};
    case "ADD_MVT": return {...state,mouvementsStock:[...state.mouvementsStock,action.payload]};
    case "SET_PARAMS_PAIE": return {...state,parametresPaie:{...state.parametresPaie,...action.payload}};
    case "ADD_EMPLOYE": return {...state,employes:[...state.employes,action.payload]};
    case "UPD_EMPLOYE": return {...state,employes:state.employes.map(e=>e.id===action.payload.id?action.payload:e)};
    case "DEL_EMPLOYE": return {...state,employes:state.employes.filter(e=>e.id!==action.payload)};
    case "ADD_BULLETIN": return {...state,bulletins:[...state.bulletins,action.payload]};
    case "DEL_BULLETIN": return {...state,bulletins:state.bulletins.filter(b=>b.id!==action.payload)};
    case "ADD_RELEVE": return {...state,relevésBancaires:[...state.relevésBancaires,action.payload]};
    case "DEL_RELEVE": return {...state,relevésBancaires:state.relevésBancaires.filter(r=>r.id!==action.payload)};
    case "TOGGLE_RAPPROCHE": return {...state,relevésBancaires:state.relevésBancaires.map(r=>r.id===action.payload?{...r,rapproché:!r.rapproché}:r)};
    case "SAVE_RAPPROCHEMENT": return {...state,rapprochements:[...state.rapprochements,action.payload]};
    case "ADD_DECLARATION_TVA": return {...state,declarationsTVA:[...state.declarationsTVA,action.payload]};
    case "UPD_DECLARATION_TVA": return {...state,declarationsTVA:state.declarationsTVA.map(d=>d.id===action.payload.id?action.payload:d)};
    case "DEL_DECLARATION_TVA": return {...state,declarationsTVA:state.declarationsTVA.filter(d=>d.id!==action.payload)};
    case "__IMPORT_ALL": return {...initialState,...action.payload};
    default: return state;
  }
}

// ─── DASHBOARD ───────────────────────────────────────────────────────────────
function Dashboard({state}){
  const {factures,achats,articles,ecritures,config,clients,employes=[],bulletins=[]}=state;
  const D=config.devise;

  const totalVentes=factures.reduce((s,f)=>s+calcLignes(f.lignes,config.tauxTVA).ttc,0);
  const totalAchats=achats.reduce((s,a)=>s+calcLignes(a.lignes,config.tauxTVA).ttc,0);
  const artAlertes=articles.filter(a=>a.stock<=a.stockMin);
  const factEnAttente=factures.filter(f=>f.statut==="en attente");
  const masseSalariale=employes.filter(e=>e.statut==="actif").reduce((s,e)=>s+e.salBase,0);

  const MOIS=["Jan","Fév","Mar","Avr","Mai","Jun","Jul","Aoû","Sep","Oct","Nov","Déc"];
  const ventesParMois=MOIS.map((m,i)=>{
    const mois=String(i+1).padStart(2,"0");
    const v=factures.filter(f=>f.date&&f.date.slice(5,7)===mois).reduce((s,f)=>s+calcLignes(f.lignes,config.tauxTVA).ttc,0);
    const a=achats.filter(f=>f.date&&f.date.slice(5,7)===mois).reduce((s,f)=>s+calcLignes(f.lignes,config.tauxTVA).ttc,0);
    return{mois:m,Ventes:Math.round(v/1000),Achats:Math.round(a/1000),Marge:Math.round((v-a)/1000)};
  }).filter(d=>d.Ventes>0||d.Achats>0);

  const ventesData=ventesParMois.length>0?ventesParMois:MOIS.slice(0,6).map((m,i)=>({mois:m,Ventes:300+i*80,Achats:180+i*50,Marge:120+i*30}));

  const statsFactures=[
    {name:"Payées",value:factures.filter(f=>f.statut==="payée").length,color:"#10b981"},
    {name:"En attente",value:factEnAttente.length,color:"#ed8936"},
    {name:"Annulées",value:factures.filter(f=>f.statut==="annulée").length,color:"#e53e3e"},
  ].filter(d=>d.value>0);
  if(statsFactures.length===0)statsFactures.push({name:"Aucune",value:1,color:"#e2e8f0"});

  const annee=new Date(config.exercice.debut).getFullYear();

  return <div>
    {/* ── INTRO ── */}
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:14,padding:"10px 14px",background:"linear-gradient(90deg,#0f2547,#1a3a6b)",borderRadius:"var(--r4)",border:"1px solid #06122a",boxShadow:"var(--sh2)"}}>
      <div style={{display:"flex",alignItems:"center",gap:12}}>
        <div style={{width:36,height:36,borderRadius:"var(--r3)",background:"linear-gradient(135deg,#2563eb,#1d4ed8)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:17,boxShadow:"0 2px 8px rgba(37,99,235,.5)",border:"1px solid rgba(147,197,253,.2)"}}>🖥</div>
        <div>
          <div style={{fontSize:14,fontWeight:700,color:"#dbeafe",letterSpacing:"-.2px"}}>Bureau Virtuel — {config.nomEntreprise}</div>
          <div style={{fontSize:10,color:"#4a6fa5",fontFamily:"var(--fm)",marginTop:2}}>Plan {config.planComptable} · Exercice {annee} · {D} · {new Date().toLocaleDateString("fr-FR",{weekday:"long",day:"numeric",month:"long"})}</div>
        </div>
      </div>
      <div style={{display:"flex",gap:6,alignItems:"center"}}>
        {artAlertes.length>0&&<span className="badge badge-red">⚠ {artAlertes.length} alerte(s) stock</span>}
        {factEnAttente.length>0&&<span className="badge badge-amber">⏳ {factEnAttente.length} facture(s) en attente</span>}
        <span className="badge badge-green">● Connecté</span>
      </div>
    </div>

    {/* ── KPI ── */}
    <div className="kpi-grid">
      {[
        {cl:"blue",icon:"💰",bg:"#dbeafe",lbl:"Chiffre d'Affaires",val:fmt(totalVentes,D),sub:`${factures.length} factures émises`},
        {cl:"blue",icon:"🛒",bg:"#dbeafe",lbl:"Total Achats",val:fmt(totalAchats,D),sub:`${achats.length} commandes`},
        {cl:totalVentes-totalAchats>=0?"green":"red",icon:"📈",bg:totalVentes-totalAchats>=0?"#d1fae5":"#fee2e2",lbl:"Résultat Brut",val:fmt(totalVentes-totalAchats,D),sub:"Ventes — Achats"},
        {cl:"orange",icon:"⏳",bg:"#fef3c7",lbl:"En Attente",val:fmt(factEnAttente.reduce((s,f)=>s+calcLignes(f.lignes,config.tauxTVA).ttc,0),D),sub:`${factEnAttente.length} impayée(s)`},
        {cl:"purple",icon:"👷",bg:"#f3e8ff",lbl:"Masse Salariale",val:fmt(masseSalariale,D),sub:`${employes.filter(e=>e.statut==="actif").length} employé(s)`},
        {cl:artAlertes.length>0?"red":"green",icon:"📦",bg:artAlertes.length>0?"#fee2e2":"#d1fae5",lbl:"Alertes Stock",val:artAlertes.length.toString(),sub:artAlertes.length===0?"Stocks OK":"Sous seuil minimum"},
      ].map((s,i)=><div key={i} className={`kpi-card ${s.cl}`}>
        <div className="kpi-top">
          <div className="kpi-icon" style={{background:s.bg}}>{s.icon}</div>
        </div>
        <div className="kpi-lbl">{s.lbl}</div>
        <div className="kpi-val" style={{fontSize:"1.05rem"}}>{s.val}</div>
        <div className="kpi-sub">{s.sub}</div>
      </div>)}
    </div>

    {/* ── ROW 1 ── */}
    <div className="grid-2" style={{gap:12,marginBottom:12}}>
      <div className="chart-card">
        <div className="chart-title">Ventes vs Achats vs Marge</div>
        <div className="chart-sub">Montants en k{D} par mois</div>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={ventesData} margin={{top:0,right:0,left:-22,bottom:0}} barCategoryGap="28%">
            <CartesianGrid strokeDasharray="3 3" stroke="#e8ecf2" vertical={false}/>
            <XAxis dataKey="mois" tick={{fontSize:10,fill:"#a0aec0",fontFamily:"var(--fm)"}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fontSize:10,fill:"#a0aec0",fontFamily:"var(--fm)"}} axisLine={false} tickLine={false}/>
            <Tooltip content={<CustomTooltip devise="k"/>}/>
            <Legend iconSize={8} iconType="square" wrapperStyle={{fontSize:10,fontFamily:"var(--fb)"}}/>
            <Bar dataKey="Ventes" fill="#2563eb" radius={[2,2,0,0]}/>
            <Bar dataKey="Achats" fill="#64748b" radius={[2,2,0,0]}/>
            <Bar dataKey="Marge" fill="#10b981" radius={[2,2,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="chart-card">
        <div className="chart-title">Répartition des Factures</div>
        <div className="chart-sub">Statut de facturation</div>
        <div style={{display:"flex",alignItems:"center",gap:16,marginTop:8}}>
          <ResponsiveContainer width={140} height={140}>
            <PieChart>
              <Pie data={statsFactures} cx="50%" cy="50%" innerRadius={38} outerRadius={60} paddingAngle={3} dataKey="value" strokeWidth={0}>
                {statsFactures.map((e,i)=><Cell key={i} fill={e.color}/>)}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div style={{flex:1}}>
            {statsFactures.map((e,i)=><div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"5px 0",borderBottom:"1px solid var(--g1)"}}>
              <div style={{display:"flex",alignItems:"center",gap:7,fontSize:11.5,color:"var(--g6)"}}>
                <span style={{width:8,height:8,borderRadius:"var(--r1)",background:e.color,display:"inline-block",flexShrink:0}}></span>
                {e.name}
              </div>
              <span style={{fontFamily:"var(--fm)",fontWeight:700,fontSize:12,color:"var(--g7)"}}>{e.value}</span>
            </div>)}
            <div style={{marginTop:8,fontSize:10,color:"var(--g4)",fontFamily:"var(--fm)"}}>Total: {factures.length} facture(s)</div>
          </div>
        </div>
      </div>
    </div>

    {/* ── ROW 2 ── */}
    <div className="grid-2" style={{gap:12}}>
      <div className="chart-card">
        <div className="chart-title">Évolution CA & Marge</div>
        <div className="chart-sub">Courbes mensuelles en k{D}</div>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={ventesData} margin={{top:0,right:0,left:-22,bottom:0}}>
            <defs>
              <linearGradient id="gV" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2563eb" stopOpacity={.15}/><stop offset="95%" stopColor="#2563eb" stopOpacity={0}/></linearGradient>
              <linearGradient id="gM" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#10b981" stopOpacity={.15}/><stop offset="95%" stopColor="#10b981" stopOpacity={0}/></linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#e8ecf2" vertical={false}/>
            <XAxis dataKey="mois" tick={{fontSize:10,fill:"#a0aec0",fontFamily:"var(--fm)"}} axisLine={false} tickLine={false}/>
            <YAxis tick={{fontSize:10,fill:"#a0aec0",fontFamily:"var(--fm)"}} axisLine={false} tickLine={false}/>
            <Tooltip content={<CustomTooltip devise="k"/>}/>
            <Legend iconSize={8} iconType="square" wrapperStyle={{fontSize:10}}/>
            <Area type="monotone" dataKey="Ventes" stroke="#2563eb" strokeWidth={2} fill="url(#gV)" dot={false}/>
            <Area type="monotone" dataKey="Marge" stroke="#10b981" strokeWidth={2} fill="url(#gM)" dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="panel" style={{overflow:"visible"}}>
        <div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Activité Récente</div></div>
        <div style={{padding:"0 0"}}>
          {factures.length===0&&achats.length===0?<div className="empty"><div className="empty-text">Aucune activité</div></div>:
          [...factures.slice(-3).map(f=>({type:"f",date:f.date,label:f.numero,sub:clients.find(c=>c.id===f.clientId)?.nom,amount:calcLignes(f.lignes,config.tauxTVA).ttc,statut:f.statut})),
           ...achats.slice(-2).map(a=>({type:"a",date:a.date,label:a.numero,sub:state.fournisseurs.find(f=>f.id===a.fournisseurId)?.nom,amount:calcLignes(a.lignes,config.tauxTVA).ttc,statut:a.statut}))
          ].sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,5).map((op,i)=><div key={i} style={{display:"flex",alignItems:"center",padding:"8px 14px",borderBottom:"1px solid var(--g1)",gap:10,fontSize:11.5}}>
            <div style={{width:26,height:26,borderRadius:"var(--r2)",background:op.type==="f"?"var(--navy-pale)":"var(--g1)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:12,flexShrink:0,border:"1px solid var(--g2)"}}>
              {op.type==="f"?"🧾":"🛒"}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontWeight:600,color:"var(--g7)"}}>{op.label}</div>
              <div style={{fontSize:10,color:"var(--g4)",marginTop:1}}>{op.sub||"—"} · {fmtDate(op.date)}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontFamily:"var(--fm)",fontSize:11,fontWeight:700,color:op.type==="f"?"var(--navy2)":"var(--g5)"}}>{fmt(op.amount,D)}</div>
              <span className={`badge badge-${op.statut==="payée"||op.statut==="reçue"?"green":op.statut==="en attente"?"orange":"red"}`} style={{fontSize:9,marginTop:2}}>{op.statut}</span>
            </div>
          </div>)}
        </div>
      </div>
    </div>
  </div>;
}

// ─── STOCK ────────────────────────────────────────────────────────────────────
function StockModule({state,dispatch}){
  const {articles,mouvementsStock,config}=state;
  const [tab,setTab]=useState(0);
  const [modal,setModal]=useState(null);
  const [form,setForm]=useState({code:"",designation:"",categorie:"",unite:"pièce",prixAchat:0,prixVente:0,stock:0,stockMin:5});
  const [mvtForm,setMvtForm]=useState({articleId:"",type:"entree",qte:0,motif:""});

  const save=()=>{if(!form.designation)return;if(form.id)dispatch({type:"UPD_ARTICLE",payload:{...form,prixAchat:+form.prixAchat,prixVente:+form.prixVente,stock:+form.stock,stockMin:+form.stockMin}});else dispatch({type:"ADD_ARTICLE",payload:{...form,id:genId(),prixAchat:+form.prixAchat,prixVente:+form.prixVente,stock:+form.stock,stockMin:+form.stockMin}});setModal(null);};
  const saveMvt=()=>{if(!mvtForm.articleId||!mvtForm.qte)return;const art=articles.find(a=>a.id===+mvtForm.articleId);if(!art)return;const newStock=mvtForm.type==="entree"?art.stock+ +mvtForm.qte:art.stock- +mvtForm.qte;dispatch({type:"UPD_ARTICLE",payload:{...art,stock:newStock}});dispatch({type:"ADD_MVT",payload:{id:genId(),date:new Date().toISOString().slice(0,10),...mvtForm,qte:+mvtForm.qte}});setModal(null);};
  const totalValeur=articles.reduce((s,a)=>s+a.stock*a.prixAchat,0);

  return <div>
    <div className="section-header">
      <div><div className="section-title">Gestion des Stocks</div><div className="section-sub">Valeur inventaire : {fmt(totalValeur,config.devise)} · {articles.filter(a=>a.stock<=a.stockMin).length} alerte(s)</div></div>
      <div className="flex gap-8"><button className="btn btn-outline btn-sm" onClick={()=>{setMvtForm({articleId:"",type:"entree",qte:0,motif:""});setModal("mvt");}}>± Mouvement</button><button className="btn btn-primary btn-sm" onClick={()=>{setForm({code:`ART${String(articles.length+1).padStart(3,"0")}`,designation:"",categorie:"",unite:"pièce",prixAchat:0,prixVente:0,stock:0,stockMin:5});setModal("article");}}>+ Nouvel Article</button></div>
    </div>
    <div className="tabs">{["Articles","Mouvements de Stock"].map((t,i)=><button key={i} className={`tab${tab===i?" active":""}`} onClick={()=>setTab(i)}>{t}</button>)}</div>
    {tab===0&&<div className="table-wrap">
      <table><thead><tr><th>Code</th><th>Désignation</th><th>Catégorie</th><th>Unité</th><th>Prix Achat</th><th>Prix Vente</th><th>Stock</th><th>Min</th><th>Valeur Stock</th><th></th></tr></thead>
      <tbody>{articles.map(a=><tr key={a.id}><td className="mono" style={{color:"var(--orange)"}}>{a.code}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{a.designation}</td><td><span className="badge badge-blue">{a.categorie}</span></td><td style={{color:"var(--g5)"}}>{a.unite}</td><td className="mono">{fmt(a.prixAchat,config.devise)}</td><td className="mono" style={{color:"var(--green)"}}>{fmt(a.prixVente,config.devise)}</td><td><span className="mono" style={{color:a.stock<=a.stockMin?"var(--red)":"var(--green)",fontWeight:700}}>{a.stock}</span></td><td className="mono" style={{color:"var(--g4)"}}>{a.stockMin}</td><td className="mono" style={{color:"var(--orange)"}}>{fmt(a.stock*a.prixAchat,config.devise)}</td><td><div className="flex gap-6"><button className="btn btn-outline btn-xs" onClick={()=>{setForm(a);setModal("article");}}>Modifier</button><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_ARTICLE",payload:a.id})}>✕</button></div></td></tr>)}</tbody></table>
    </div>}
    {tab===1&&<div className="table-wrap">
      <table><thead><tr><th>Date</th><th>Article</th><th>Mouvement</th><th>Quantité</th><th>Motif</th><th>Référence</th></tr></thead>
      <tbody>{[...mouvementsStock].reverse().map(m=>{const art=articles.find(a=>a.id===m.articleId);return <tr key={m.id}><td className="mono">{fmtDate(m.date)}</td><td style={{fontWeight:500}}>{art?.designation||"?"}</td><td><span className={`badge badge-${m.type==="entree"?"green":"red"}`}>{m.type==="entree"?"↑ Entrée":"↓ Sortie"}</span></td><td className="mono" style={{color:m.type==="entree"?"var(--green)":"var(--red)",fontWeight:700}}>{m.type==="entree"?"+":"-"}{m.qte}</td><td style={{color:"var(--g5)"}}>{m.motif}</td><td className="mono">{m.ref||"—"}</td></tr>;})}</tbody></table>
    </div>}
    {modal==="article"&&<Modal title={form.id?"Modifier l'article":"Nouvel article"} sub={form.id?form.code:"Fiche produit"} icon="📦" onClose={()=>setModal(null)}>
      <div className="form-grid"><div className="form-group"><label>Code</label><input value={form.code} onChange={e=>setForm({...form,code:e.target.value})}/></div><div className="form-group"><label>Catégorie</label><input value={form.categorie} onChange={e=>setForm({...form,categorie:e.target.value})}/></div><div className="form-group full"><label>Désignation</label><input value={form.designation} onChange={e=>setForm({...form,designation:e.target.value})}/></div><div className="form-group"><label>Unité</label><input value={form.unite} onChange={e=>setForm({...form,unite:e.target.value})}/></div><div className="form-group"><label>Prix Achat ({config.devise})</label><input type="number" value={form.prixAchat} onChange={e=>setForm({...form,prixAchat:e.target.value})}/></div><div className="form-group"><label>Prix Vente ({config.devise})</label><input type="number" value={form.prixVente} onChange={e=>setForm({...form,prixVente:e.target.value})}/></div><div className="form-group"><label>Stock Initial</label><input type="number" value={form.stock} onChange={e=>setForm({...form,stock:e.target.value})}/></div><div className="form-group"><label>Stock Minimum</label><input type="number" value={form.stockMin} onChange={e=>setForm({...form,stockMin:e.target.value})}/></div></div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(null)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={save}>Enregistrer</button></div>
    </Modal>}
    {modal==="mvt"&&<Modal title="Mouvement de Stock" sub="Entrée / Sortie" icon="📦" onClose={()=>setModal(null)} width={480}>
      <div className="form-grid"><div className="form-group full"><label>Article</label><select value={mvtForm.articleId} onChange={e=>setMvtForm({...mvtForm,articleId:e.target.value})}><option value="">— Sélectionner —</option>{articles.map(a=><option key={a.id} value={a.id}>{a.code} — {a.designation} (stock: {a.stock})</option>)}</select></div><div className="form-group"><label>Type</label><select value={mvtForm.type} onChange={e=>setMvtForm({...mvtForm,type:e.target.value})}><option value="entree">↑ Entrée en stock</option><option value="sortie">↓ Sortie de stock</option></select></div><div className="form-group"><label>Quantité</label><input type="number" value={mvtForm.qte} onChange={e=>setMvtForm({...mvtForm,qte:e.target.value})}/></div><div className="form-group full"><label>Motif</label><input value={mvtForm.motif} onChange={e=>setMvtForm({...mvtForm,motif:e.target.value})}/></div></div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(null)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={saveMvt}>Valider</button></div>
    </Modal>}
  </div>;
}

// ─── SERVICES ─────────────────────────────────────────────────────────────────
function ServicesModule({state,dispatch}){
  const {services,config}=state;
  const [modal,setModal]=useState(false);
  const [form,setForm]=useState({code:"",designation:"",unite:"heure",prixUnitaire:0,tva:true});
  const save=()=>{if(!form.designation)return;dispatch({type:"ADD_SERVICE",payload:{...form,id:genId(),prixUnitaire:+form.prixUnitaire}});setModal(false);};
  return <div>
    <div className="section-header"><div><div className="section-title">Catalogue Services</div><div className="section-sub">{services.length} service(s) référencé(s)</div></div><button className="btn btn-primary btn-sm" onClick={()=>{setForm({code:`SRV${String(services.length+1).padStart(3,"0")}`,designation:"",unite:"heure",prixUnitaire:0,tva:true});setModal(true);}}>+ Nouveau Service</button></div>
    <div className="table-wrap"><table><thead><tr><th>Code</th><th>Désignation</th><th>Unité</th><th>Prix Unitaire</th><th>TVA</th><th></th></tr></thead><tbody>{services.map(s=><tr key={s.id}><td className="mono" style={{color:"var(--orange)"}}>{s.code}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{s.designation}</td><td style={{color:"var(--g5)"}}>{s.unite}</td><td className="mono" style={{color:"var(--green)"}}>{fmt(s.prixUnitaire,config.devise)}</td><td>{s.tva?<span className="badge badge-blue">{config.tauxTVA}%</span>:<span className="badge badge-amber">Exonéré</span>}</td><td><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_SERVICE",payload:s.id})}>✕</button></td></tr>)}</tbody></table></div>
    {modal&&<Modal title="Nouveau service" sub="Prestation facturable" icon="🛠" onClose={()=>setModal(false)} width={480}>
      <div className="form-grid"><div className="form-group"><label>Code</label><input value={form.code} onChange={e=>setForm({...form,code:e.target.value})}/></div><div className="form-group"><label>Unité</label><input value={form.unite} onChange={e=>setForm({...form,unite:e.target.value})}/></div><div className="form-group full"><label>Désignation</label><input value={form.designation} onChange={e=>setForm({...form,designation:e.target.value})}/></div><div className="form-group"><label>Prix Unitaire ({config.devise})</label><input type="number" value={form.prixUnitaire} onChange={e=>setForm({...form,prixUnitaire:e.target.value})}/></div><div className="form-group"><label>Soumettre à TVA</label><select value={form.tva?"oui":"non"} onChange={e=>setForm({...form,tva:e.target.value==="oui"})}><option value="oui">Oui — {config.tauxTVA}%</option><option value="non">Non — Exonéré</option></select></div></div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(false)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={save}>Enregistrer</button></div>
    </Modal>}
  </div>;
}

// ─── FACTURES ─────────────────────────────────────────────────────────────────
function FacturesModule({state,dispatch}){
  const {factures,clients,articles,services,config}=state;
  const [modal,setModal]=useState(null);
  const [view,setView]=useState(null);
  const [form,setForm]=useState({numero:"",date:new Date().toISOString().slice(0,10),clientId:"",lignes:[],statut:"en attente",modePaiement:"",notes:""});
  const [newLigne,setNewLigne]=useState({type:"article",refId:"",qte:1,pu:0,tva:config.tauxTVA});
  const nextNum=()=>`FC-${new Date().getFullYear()}-${String(factures.length+1).padStart(3,"0")}`;
  const addLigne=()=>{if(!newLigne.refId||!newLigne.qte)return;const ref=newLigne.type==="article"?articles.find(a=>a.id===+newLigne.refId):services.find(s=>s.id===+newLigne.refId);if(!ref)return;setForm({...form,lignes:[...form.lignes,{...newLigne,refId:+newLigne.refId,qte:+newLigne.qte,pu:+newLigne.pu||ref.prixVente||ref.prixUnitaire,designation:ref.designation}]});setNewLigne({type:"article",refId:"",qte:1,pu:0,tva:config.tauxTVA});};
  const save=()=>{if(!form.clientId||form.lignes.length===0)return;if(form.id)dispatch({type:"UPD_FACTURE",payload:{...form,clientId:+form.clientId}});else dispatch({type:"ADD_FACTURE",payload:{...form,id:genId(),clientId:+form.clientId}});setModal(null);};
  const genEcriture=(f)=>{const client=clients.find(c=>c.id===f.clientId);const {ht,tva,ttc}=calcLignes(f.lignes,config.tauxTVA);dispatch({type:"ADD_ECRITURE",payload:{id:genId(),date:f.date,journal:"VT",libelle:`Facture ${f.numero} — ${client?.nom}`,lignes:[{compteCode:"411000",libelle:"Clients",debit:ttc,credit:0},{compteCode:"701000",libelle:"Ventes",debit:0,credit:ht},{compteCode:"445000",libelle:"TVA collectée",debit:0,credit:tva}],reference:f.numero,valide:true}});alert("Écriture comptable générée ✅");};

  return <div>
    <div className="section-header"><div><div className="section-title">Facturation Clients</div><div className="section-sub">{factures.length} factures · {factures.filter(f=>f.statut==="payée").length} payées · {factures.filter(f=>f.statut==="en attente").length} en attente</div></div><button className="btn btn-primary btn-sm" onClick={()=>{setForm({numero:nextNum(),date:new Date().toISOString().slice(0,10),clientId:"",lignes:[],statut:"en attente",modePaiement:"",notes:""});setModal("form");}}>+ Nouvelle Facture</button></div>
    <div className="table-wrap"><table>
      <thead><tr><th>N° Facture</th><th>Date</th><th>Client</th><th>Montant HT</th><th>TVA</th><th>TTC</th><th>Statut</th><th>Paiement</th><th></th></tr></thead>
      <tbody>{[...factures].reverse().map(f=>{const cli=clients.find(c=>c.id===f.clientId);const {ht,tva,ttc}=calcLignes(f.lignes,config.tauxTVA);return <tr key={f.id}><td className="mono" style={{color:"var(--orange)"}}>{f.numero}</td><td className="mono">{fmtDate(f.date)}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{cli?.nom||"?"}</td><td className="mono">{fmt(ht,config.devise)}</td><td className="mono" style={{color:"var(--g4)"}}>{fmt(tva,config.devise)}</td><td className="mono" style={{fontWeight:700,color:"var(--navy2)"}}>{fmt(ttc,config.devise)}</td><td><span className={`badge badge-${f.statut==="payée"?"green":f.statut==="en attente"?"orange":"red"}`}>{f.statut}</span></td><td style={{color:"var(--g5)",fontSize:11}}>{f.modePaiement||"—"}</td><td><div className="flex gap-6"><button className="btn btn-outline btn-xs" onClick={()=>setView(f)}>Aperçu</button><button className="btn btn-ghost btn-xs" title="Générer écriture" onClick={()=>genEcriture(f)}>📒</button><button className="btn btn-outline btn-xs" onClick={()=>{setForm({...f});setModal("form");}}>✏️</button><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_FACTURE",payload:f.id})}>✕</button></div></td></tr>;})}
      </tbody></table></div>

    {view&&<div className="modal-overlay" onClick={()=>setView(null)}><div className="modal" style={{maxWidth:760}} onClick={e=>e.stopPropagation()}>
      <div className="modal-titlebar"><div className="modal-title-icon">🧾</div><div className="modal-title">Aperçu Facture — {view.numero}</div><button className="modal-close" onClick={()=>setView(null)}>✕</button></div>
      <div className="modal-body">
        <div style={{background:"var(--white)",padding:"28px 32px",fontFamily:"var(--fb)"}}>
          <div style={{display:"flex",justifyContent:"space-between",marginBottom:24,paddingBottom:20,borderBottom:"2px solid var(--navy)"}}>
            <div><div style={{fontWeight:800,fontSize:20,color:"var(--navy)",letterSpacing:"-.5px"}}>{config.nomEntreprise}</div><div style={{fontSize:12,color:"var(--g5)",marginTop:2}}>{config.adresse}</div>{config.rccm&&<div style={{fontSize:11,color:"var(--g4)",marginTop:1}}>RCCM: {config.rccm} · IFU: {config.ifu}</div>}</div>
            <div style={{textAlign:"right"}}><div style={{fontWeight:800,fontSize:18,color:"var(--navy2)",textTransform:"uppercase",letterSpacing:"2px"}}>Facture</div><div style={{fontFamily:"var(--fm)",fontSize:13,fontWeight:600,color:"var(--g7)",marginTop:2}}>{view.numero}</div><div style={{fontSize:11,color:"var(--g4)",marginTop:2}}>{fmtDate(view.date)}</div><span style={{display:"inline-block",marginTop:6,padding:"2px 10px",borderRadius:"var(--r1)",background:view.statut==="payée"?"var(--green-bg)":"var(--orange-bg)",color:view.statut==="payée"?"var(--green)":"var(--orange)",fontSize:10,fontWeight:700,border:"1px solid",borderColor:view.statut==="payée"?"var(--green-bd)":"var(--orange-bd)",textTransform:"uppercase",letterSpacing:"1px"}}>{view.statut}</span></div>
          </div>
          <div style={{background:"var(--panel)",borderRadius:"var(--r3)",padding:"10px 14px",marginBottom:20,border:"1px solid var(--g2)"}}><div style={{fontSize:9.5,color:"var(--g4)",textTransform:"uppercase",letterSpacing:"1.5px",fontWeight:700,marginBottom:4}}>Facturé à</div><div style={{fontWeight:700,color:"var(--g8)",fontSize:14}}>{clients.find(c=>c.id===view.clientId)?.nom}</div><div style={{fontSize:11.5,color:"var(--g5)",marginTop:2}}>{clients.find(c=>c.id===view.clientId)?.adresse}</div></div>
          <table style={{width:"100%",borderCollapse:"collapse",marginBottom:16}}>
            <thead><tr style={{background:"var(--navy)"}}><th style={{padding:"8px 12px",textAlign:"left",color:"rgba(219,234,254,.7)",fontSize:9.5,letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600}}>Désignation</th><th style={{padding:"8px 12px",textAlign:"center",color:"rgba(219,234,254,.7)",fontSize:9.5,letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600}}>Qté</th><th style={{padding:"8px 12px",textAlign:"right",color:"rgba(219,234,254,.7)",fontSize:9.5,letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600}}>P.U. HT</th><th style={{padding:"8px 12px",textAlign:"right",color:"rgba(219,234,254,.7)",fontSize:9.5,letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600}}>Total HT</th></tr></thead>
            <tbody>{view.lignes.map((l,i)=><tr key={i} style={{background:i%2===0?"var(--white)":"var(--panel)",borderBottom:"1px solid var(--g2)"}}><td style={{padding:"8px 12px",color:"var(--g7)"}}>{l.designation}</td><td style={{padding:"8px 12px",textAlign:"center",fontFamily:"var(--fm)",color:"var(--g6)"}}>{l.qte}</td><td style={{padding:"8px 12px",textAlign:"right",fontFamily:"var(--fm)",color:"var(--g7)"}}>{fmt(l.pu,"")}</td><td style={{padding:"8px 12px",textAlign:"right",fontFamily:"var(--fm)",fontWeight:600,color:"var(--g8)"}}>{fmt(l.qte*l.pu,"")}</td></tr>)}</tbody>
          </table>
          {(()=>{const {ht,tva,ttc}=calcLignes(view.lignes,config.tauxTVA);return <div style={{display:"flex",justifyContent:"flex-end"}}><div style={{width:260}}>{[["Total HT",ht,false],["TVA "+config.tauxTVA+"%",tva,false],["TOTAL TTC",ttc,true]].map(([k,v,bold],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderTop:bold?"2px solid var(--navy)":"1px solid var(--g2)",fontWeight:bold?800:400,fontSize:bold?14:12.5,color:bold?"var(--navy)":"var(--g6)"}}><span>{k}</span><span style={{fontFamily:"var(--fm)"}}>{fmt(v,config.devise)}</span></div>)}</div></div>;})()}
        </div>
      </div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setView(null)}>Fermer</button><button className="btn btn-primary btn-sm" onClick={()=>window.print()}>🖨 Imprimer</button></div>
    </div></div>}

    {modal==="form"&&<Modal title={form.id?"Modifier la facture":"Nouvelle facture"} sub={form.numero||nextNum()} icon="🧾" onClose={()=>setModal(null)} width={800}>
      <div className="form-grid" style={{marginBottom:14}}><div className="form-group"><label>N° Facture</label><input value={form.numero} onChange={e=>setForm({...form,numero:e.target.value})}/></div><div className="form-group"><label>Date</label><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div><div className="form-group"><label>Client</label><select value={form.clientId} onChange={e=>setForm({...form,clientId:e.target.value})}><option value="">— Sélectionner —</option>{clients.map(c=><option key={c.id} value={c.id}>{c.code} — {c.nom}</option>)}</select></div><div className="form-group"><label>Statut</label><select value={form.statut} onChange={e=>setForm({...form,statut:e.target.value})}><option>en attente</option><option>payée</option><option>annulée</option></select></div><div className="form-group"><label>Mode paiement</label><select value={form.modePaiement} onChange={e=>setForm({...form,modePaiement:e.target.value})}><option value="">—</option><option>espèces</option><option>virement</option><option>chèque</option><option>mobile money</option></select></div></div>
      <div className="panel" style={{marginBottom:14}}>
        <div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Lignes de facturation</div><span className="badge badge-blue">{form.lignes.length} ligne(s)</span></div>
        <div style={{padding:"10px 14px"}}>
          {form.lignes.map((l,i)=><div key={i} className="list-item"><div style={{color:"var(--g7)",fontSize:12.5}}>{l.designation}</div><div className="flex items-center gap-10"><span className="mono" style={{color:"var(--g4)",fontSize:11}}>{l.qte} × {fmt(l.pu,config.devise)}</span><span className="mono" style={{color:"var(--navy2)",fontWeight:700}}>{fmt(l.qte*l.pu,config.devise)}</span><button className="btn btn-danger btn-xs" onClick={()=>setForm({...form,lignes:form.lignes.filter((_,j)=>j!==i)})}>✕</button></div></div>)}
          {form.lignes.length===0&&<div style={{color:"var(--g4)",fontSize:11,padding:"4px 0"}}>Aucune ligne.</div>}
          <div className="divider"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 70px 100px auto",gap:8,alignItems:"flex-end"}}>
            <div className="form-group" style={{margin:0}}><label>Type</label><select value={newLigne.type} onChange={e=>setNewLigne({...newLigne,type:e.target.value,refId:""})}><option value="article">Article</option><option value="service">Service</option></select></div>
            <div className="form-group" style={{margin:0}}><label>Référence</label><select value={newLigne.refId} onChange={e=>{const id=+e.target.value;const ref=newLigne.type==="article"?articles.find(a=>a.id===id):services.find(s=>s.id===id);setNewLigne({...newLigne,refId:e.target.value,pu:ref?.prixVente||ref?.prixUnitaire||0});}}><option value="">—</option>{(newLigne.type==="article"?articles:services).map(r=><option key={r.id} value={r.id}>{r.designation}</option>)}</select></div>
            <div className="form-group" style={{margin:0}}><label>Qté</label><input type="number" value={newLigne.qte} onChange={e=>setNewLigne({...newLigne,qte:e.target.value})}/></div>
            <div className="form-group" style={{margin:0}}><label>P.U.</label><input type="number" value={newLigne.pu} onChange={e=>setNewLigne({...newLigne,pu:e.target.value})}/></div>
            <button className="btn btn-primary btn-sm" style={{alignSelf:"flex-end"}} onClick={addLigne}>+ Ajouter</button>
          </div>
          {form.lignes.length>0&&(()=>{const {ht,tva,ttc}=calcLignes(form.lignes,config.tauxTVA);return <div style={{marginTop:10,textAlign:"right",fontSize:11,color:"var(--g5)"}}>HT: <span className="mono">{fmt(ht,config.devise)}</span> · TVA: <span className="mono">{fmt(tva,config.devise)}</span> · <span className="mono" style={{color:"var(--navy2)",fontWeight:700,fontSize:13}}>{fmt(ttc,config.devise)}</span></div>;})()}
        </div>
      </div>
      <div className="form-group" style={{marginBottom:12}}><label>Notes</label><textarea rows={2} value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} style={{resize:"vertical"}}/></div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(null)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={save}>Enregistrer</button></div>
    </Modal>}
  </div>;
}

// ─── ACHATS ───────────────────────────────────────────────────────────────────
function AchatsModule({state,dispatch}){
  const {achats,fournisseurs,articles,config}=state;
  const [modal,setModal]=useState(false);
  const [form,setForm]=useState({numero:"",date:"",fournisseurId:"",lignes:[],statut:"en attente",modePaiement:"",notes:""});
  const [newLigne,setNewLigne]=useState({refId:"",designation:"",qte:1,pu:0,tva:config.tauxTVA});
  const nextNum=()=>`AC-${new Date().getFullYear()}-${String(achats.length+1).padStart(3,"0")}`;
  const addLigne=()=>{const art=articles.find(a=>a.id===+newLigne.refId);setForm({...form,lignes:[...form.lignes,{...newLigne,refId:+newLigne.refId,qte:+newLigne.qte,pu:+newLigne.pu||art?.prixAchat||0,designation:art?.designation||newLigne.designation}]});setNewLigne({refId:"",designation:"",qte:1,pu:0,tva:config.tauxTVA});};
  const save=()=>{if(!form.fournisseurId||form.lignes.length===0)return;if(form.id)dispatch({type:"UPD_ACHAT",payload:{...form,fournisseurId:+form.fournisseurId}});else dispatch({type:"ADD_ACHAT",payload:{...form,id:genId(),fournisseurId:+form.fournisseurId}});setModal(false);};

  return <div>
    <div className="section-header"><div><div className="section-title">Commandes d'Achats</div><div className="section-sub">{achats.length} commandes · {fournisseurs.length} fournisseurs</div></div><div className="flex gap-8"><button className="btn btn-outline btn-sm" onClick={()=>{setForm({code:`FRN${String(fournisseurs.length+1).padStart(3,"0")}`,nom:"",adresse:"",telephone:"",email:""});setModal("fournisseur");}}>+ Fournisseur</button><button className="btn btn-primary btn-sm" onClick={()=>{setForm({numero:nextNum(),date:new Date().toISOString().slice(0,10),fournisseurId:"",lignes:[],statut:"en attente",modePaiement:"",notes:""});setModal("form");}}>+ Commande Achat</button></div></div>
    <div className="table-wrap mb-16"><table><thead><tr><th>N°</th><th>Date</th><th>Fournisseur</th><th>HT</th><th>TVA</th><th>TTC</th><th>Statut</th><th></th></tr></thead><tbody>{[...achats].reverse().map(a=>{const frn=fournisseurs.find(f=>f.id===a.fournisseurId);const {ht,tva,ttc}=calcLignes(a.lignes,config.tauxTVA);return <tr key={a.id}><td className="mono" style={{color:"var(--orange)"}}>{a.numero}</td><td className="mono">{fmtDate(a.date)}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{frn?.nom||"?"}</td><td className="mono">{fmt(ht,config.devise)}</td><td className="mono" style={{color:"var(--g4)"}}>{fmt(tva,config.devise)}</td><td className="mono" style={{fontWeight:700,color:"var(--navy2)"}}>{fmt(ttc,config.devise)}</td><td><span className={`badge badge-${a.statut==="reçue"?"green":a.statut==="en attente"?"orange":"red"}`}>{a.statut}</span></td><td><div className="flex gap-6"><button className="btn btn-outline btn-xs" onClick={()=>{setForm({...a});setModal("form");}}>✏️</button><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_ACHAT",payload:a.id})}>✕</button></div></td></tr>;})}</tbody></table></div>
    <div className="section-title" style={{marginBottom:10,fontSize:12}}>Répertoire Fournisseurs</div>
    <div className="table-wrap"><table><thead><tr><th>Code</th><th>Nom</th><th>Adresse</th><th>Téléphone</th><th></th></tr></thead><tbody>{fournisseurs.map(f=><tr key={f.id}><td className="mono" style={{color:"var(--orange)"}}>{f.code}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{f.nom}</td><td style={{color:"var(--g5)"}}>{f.adresse}</td><td className="mono">{f.telephone}</td><td><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_FOURNISSEUR",payload:f.id})}>✕</button></td></tr>)}</tbody></table></div>
    {modal==="fournisseur"&&<Modal title="Nouveau fournisseur" icon="🏢" onClose={()=>setModal(false)} width={480}><div className="form-grid"><div className="form-group"><label>Code</label><input value={form.code||""} onChange={e=>setForm({...form,code:e.target.value})}/></div><div className="form-group"><label>Nom</label><input value={form.nom||""} onChange={e=>setForm({...form,nom:e.target.value})}/></div><div className="form-group"><label>Adresse</label><input value={form.adresse||""} onChange={e=>setForm({...form,adresse:e.target.value})}/></div><div className="form-group"><label>Téléphone</label><input value={form.telephone||""} onChange={e=>setForm({...form,telephone:e.target.value})}/></div></div><div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(false)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={()=>{dispatch({type:"ADD_FOURNISSEUR",payload:{...form,id:genId()}});setModal(false);}}>Enregistrer</button></div></Modal>}
    {modal==="form"&&<Modal title={form.id?"Modifier commande":"Nouvelle commande achat"} sub={form.numero} icon="🛒" onClose={()=>setModal(false)} width={740}>
      <div className="form-grid" style={{marginBottom:14}}><div className="form-group"><label>N°</label><input value={form.numero} onChange={e=>setForm({...form,numero:e.target.value})}/></div><div className="form-group"><label>Date</label><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div><div className="form-group"><label>Fournisseur</label><select value={form.fournisseurId} onChange={e=>setForm({...form,fournisseurId:e.target.value})}><option value="">—</option>{fournisseurs.map(f=><option key={f.id} value={f.id}>{f.nom}</option>)}</select></div><div className="form-group"><label>Statut</label><select value={form.statut} onChange={e=>setForm({...form,statut:e.target.value})}><option>en attente</option><option>reçue</option><option>annulée</option></select></div></div>
      <div className="panel" style={{marginBottom:12}}><div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Lignes d'achat</div></div><div style={{padding:"10px 14px"}}>{form.lignes.map((l,i)=><div key={i} className="list-item"><span style={{color:"var(--g7)"}}>{l.designation}</span><div className="flex items-center gap-10"><span className="mono" style={{color:"var(--g4)",fontSize:11}}>{l.qte} × {fmt(l.pu,config.devise)}</span><span className="mono" style={{color:"var(--navy2)",fontWeight:700}}>{fmt(l.qte*l.pu,config.devise)}</span><button className="btn btn-danger btn-xs" onClick={()=>setForm({...form,lignes:form.lignes.filter((_,j)=>j!==i)})}>✕</button></div></div>)}<div className="divider"/><div style={{display:"grid",gridTemplateColumns:"2fr 70px 100px auto",gap:8,alignItems:"flex-end"}}><div className="form-group" style={{margin:0}}><label>Article</label><select value={newLigne.refId} onChange={e=>{const a=articles.find(x=>x.id===+e.target.value);setNewLigne({...newLigne,refId:e.target.value,pu:a?.prixAchat||0});}}><option value="">—</option>{articles.map(a=><option key={a.id} value={a.id}>{a.designation}</option>)}</select></div><div className="form-group" style={{margin:0}}><label>Qté</label><input type="number" value={newLigne.qte} onChange={e=>setNewLigne({...newLigne,qte:e.target.value})}/></div><div className="form-group" style={{margin:0}}><label>P.U.</label><input type="number" value={newLigne.pu} onChange={e=>setNewLigne({...newLigne,pu:e.target.value})}/></div><button className="btn btn-primary btn-sm" style={{alignSelf:"flex-end"}} onClick={addLigne}>+ Ajouter</button></div></div></div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(false)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={save}>Enregistrer</button></div>
    </Modal>}
  </div>;
}

// ─── CLIENTS ─────────────────────────────────────────────────────────────────
function ClientsModule({state,dispatch}){
  const {clients,factures,config}=state;
  const [modal,setModal]=useState(false);
  const [form,setForm]=useState({code:"",nom:"",adresse:"",telephone:"",email:""});
  const save=()=>{if(!form.nom)return;dispatch({type:"ADD_CLIENT",payload:{...form,id:genId(),solde:0}});setModal(false);};
  return <div>
    <div className="section-header"><div><div className="section-title">Gestion Clients</div><div className="section-sub">{clients.length} clients enregistrés</div></div><button className="btn btn-primary btn-sm" onClick={()=>{setForm({code:`CLI${String(clients.length+1).padStart(3,"0")}`,nom:"",adresse:"",telephone:"",email:""});setModal(true);}}>+ Nouveau Client</button></div>
    <div className="table-wrap"><table><thead><tr><th>Code</th><th>Nom / Raison sociale</th><th>Adresse</th><th>Téléphone</th><th>CA Total</th><th>Nb Factures</th><th></th></tr></thead><tbody>{clients.map(c=>{const cliFact=factures.filter(f=>f.clientId===c.id);const ca=cliFact.reduce((s,f)=>s+calcLignes(f.lignes,config.tauxTVA).ttc,0);return <tr key={c.id}><td className="mono" style={{color:"var(--orange)"}}>{c.code}</td><td style={{fontWeight:600,color:"var(--g7)"}}>{c.nom}</td><td style={{color:"var(--g5)"}}>{c.adresse}</td><td className="mono">{c.telephone}</td><td className="mono" style={{color:"var(--green)",fontWeight:600}}>{fmt(ca,config.devise)}</td><td className="mono" style={{color:"var(--g5)"}}>{cliFact.length}</td><td><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_CLIENT",payload:c.id})}>✕</button></td></tr>;})}</tbody></table></div>
    {modal&&<Modal title="Nouveau client" icon="👥" onClose={()=>setModal(false)} width={520}><div className="form-grid"><div className="form-group"><label>Code</label><input value={form.code} onChange={e=>setForm({...form,code:e.target.value})}/></div><div className="form-group"><label>Nom / Raison sociale</label><input value={form.nom} onChange={e=>setForm({...form,nom:e.target.value})}/></div><div className="form-group"><label>Adresse</label><input value={form.adresse} onChange={e=>setForm({...form,adresse:e.target.value})}/></div><div className="form-group"><label>Téléphone</label><input value={form.telephone} onChange={e=>setForm({...form,telephone:e.target.value})}/></div><div className="form-group full"><label>Email</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></div></div><div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(false)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={save}>Enregistrer</button></div></Modal>}
  </div>;
}

// ─── COMPTABILITÉ ─────────────────────────────────────────────────────────────
function ComptabiliteModule({state,dispatch}){
  const {ecritures,comptes,config}=state;
  const [tab,setTab]=useState(0);
  const [modal,setModal]=useState(false);
  const [form,setForm]=useState({date:"",journal:"OD",libelle:"",lignes:[{compteCode:"",libelle:"",debit:0,credit:0},{compteCode:"",libelle:"",debit:0,credit:0}],reference:"",valide:false});
  const JOURNAUX=["OD","VT","AC","BQ","CA","AN","PAIE"];
  const addLigneCpta=()=>setForm({...form,lignes:[...form.lignes,{compteCode:"",libelle:"",debit:0,credit:0}]});
  const updLigne=(i,f,v)=>setForm(s=>({...s,lignes:s.lignes.map((l,j)=>j===i?{...l,[f]:v}:l)}));
  const totalDebit=form.lignes.reduce((s,l)=>s+(+l.debit||0),0);
  const totalCredit=form.lignes.reduce((s,l)=>s+(+l.credit||0),0);
  const balanced=Math.abs(totalDebit-totalCredit)<0.01;
  const save=()=>{if(!form.date||!form.libelle||!balanced)return;dispatch({type:"ADD_ECRITURE",payload:{...form,id:genId()}});setModal(false);};

  const grandLivre=useMemo(()=>{const gl={};ecritures.forEach(e=>{e.lignes.forEach(l=>{if(!gl[l.compteCode])gl[l.compteCode]={debit:0,credit:0,lignes:[]};gl[l.compteCode].debit+=l.debit||0;gl[l.compteCode].credit+=l.credit||0;gl[l.compteCode].lignes.push({...l,date:e.date,journal:e.journal,libellePiece:e.libelle,ref:e.reference});});});return gl;},[ecritures]);

  const totalD=ecritures.reduce((s,e)=>s+e.lignes.reduce((ss,l)=>ss+(l.debit||0),0),0);
  const totalC=ecritures.reduce((s,e)=>s+e.lignes.reduce((ss,l)=>ss+(l.credit||0),0),0);

  return <div>
    <div className="section-header"><div><div className="section-title">Comptabilité Générale</div><div className="section-sub">Plan {config.planComptable} · {ecritures.length} écritures · {ecritures.filter(e=>e.valide).length} validées</div></div><button className="btn btn-primary btn-sm" onClick={()=>{setForm({date:new Date().toISOString().slice(0,10),journal:"OD",libelle:"",lignes:[{compteCode:"",libelle:"",debit:0,credit:0},{compteCode:"",libelle:"",debit:0,credit:0}],reference:"",valide:false});setModal(true);}}>+ Nouvelle Écriture</button></div>
    <div className="tabs">{["Journal Centralisateur","Grand Livre","Balance Générale"].map((t,i)=><button key={i} className={`tab${tab===i?" active":""}`} onClick={()=>setTab(i)}>{t}</button>)}</div>
    {tab===0&&<div className="table-wrap"><table><thead><tr><th>Date</th><th>Journal</th><th>Libellé</th><th>Référence</th><th>Débit</th><th>Crédit</th><th>Équilibre</th><th></th></tr></thead><tbody>{[...ecritures].reverse().map(e=>{const td=e.lignes.reduce((s,l)=>s+(l.debit||0),0);const tc=e.lignes.reduce((s,l)=>s+(l.credit||0),0);return <tr key={e.id}><td className="mono">{fmtDate(e.date)}</td><td><span className="badge badge-blue">{e.journal}</span></td><td style={{fontWeight:500,color:"var(--g7)"}}>{e.libelle}</td><td className="mono" style={{color:"var(--g4)"}}>{e.reference||"—"}</td><td className="mono" style={{color:"var(--green)"}}>{fmt(td,config.devise)}</td><td className="mono" style={{color:"var(--red)"}}>{fmt(tc,config.devise)}</td><td>{Math.abs(td-tc)<0.01?<span className="badge badge-green">✓</span>:<span className="badge badge-red">✗</span>}</td><td><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_ECRITURE",payload:e.id})}>✕</button></td></tr>;})}
    </tbody><tfoot><tr><td colSpan={4} style={{padding:"8px 10px",fontSize:9.5,fontWeight:700,color:"var(--g5)",textTransform:"uppercase",letterSpacing:"1.5px"}}>Totaux</td><td className="mono" style={{padding:"8px 10px",color:"var(--green)"}}>{fmt(totalD,config.devise)}</td><td className="mono" style={{padding:"8px 10px",color:"var(--red)"}}>{fmt(totalC,config.devise)}</td><td style={{padding:"8px 10px"}}>{Math.abs(totalD-totalC)<0.01?<span className="badge badge-green">Équilibré</span>:<span className="badge badge-red">Déséquilibré</span>}</td><td/></tr></tfoot></table></div>}
    {tab===1&&<div>{Object.entries(grandLivre).sort(([a],[b])=>a.localeCompare(b)).map(([code,data])=>{const cpt=comptes.find(c=>c.code===code);const solde=data.debit-data.credit;return <div key={code} className="gl-card"><div className="gl-card-header"><div className="flex items-center gap-10"><span className="mono" style={{color:"var(--orange)",fontWeight:700}}>{code}</span><span style={{fontWeight:600,color:"var(--g7)",fontSize:12.5}}>{cpt?.libelle||"Compte inconnu"}</span></div><div className="flex gap-12 items-center"><span style={{color:"var(--green)",fontFamily:"var(--fm)",fontSize:11}}>D: {fmt(data.debit,"")}</span><span style={{color:"var(--red)",fontFamily:"var(--fm)",fontSize:11}}>C: {fmt(data.credit,"")}</span><span style={{fontWeight:700,fontFamily:"var(--fm)",color:solde>=0?"var(--green)":"var(--red)",fontSize:12}}>Solde: {fmt(Math.abs(solde),config.devise)} {solde>=0?"D":"C"}</span></div></div><table style={{fontSize:11.5}}><thead><tr><th>Date</th><th>Journal</th><th>Libellé</th><th>Référence</th><th>Débit</th><th>Crédit</th></tr></thead><tbody>{data.lignes.map((l,i)=><tr key={i}><td className="mono">{fmtDate(l.date)}</td><td><span className="badge badge-blue" style={{fontSize:9}}>{l.journal}</span></td><td>{l.libellePiece}</td><td className="mono" style={{color:"var(--g4)"}}>{l.ref||"—"}</td><td className="mono" style={{color:"var(--green)"}}>{l.debit?fmt(l.debit,""):""}</td><td className="mono" style={{color:"var(--red)"}}>{l.credit?fmt(l.credit,""):""}</td></tr>)}</tbody></table></div>;})}
    </div>}
    {tab===2&&(()=>{const balance={};ecritures.forEach(e=>{e.lignes.forEach(l=>{if(!balance[l.compteCode])balance[l.compteCode]={debit:0,credit:0};balance[l.compteCode].debit+=l.debit||0;balance[l.compteCode].credit+=l.credit||0;});});const rows=Object.entries(balance).sort(([a],[b])=>a.localeCompare(b)).map(([code,d])=>{const cpt=comptes.find(c=>c.code===code);const sD=d.debit>d.credit?d.debit-d.credit:0;const sC=d.credit>d.debit?d.credit-d.debit:0;return{code,libelle:cpt?.libelle||"Inconnu",...d,sD,sC};});const tot=rows.reduce((s,r)=>({debit:s.debit+r.debit,credit:s.credit+r.credit,sD:s.sD+r.sD,sC:s.sC+r.sC}),{debit:0,credit:0,sD:0,sC:0});return <div className="table-wrap"><table><thead><tr><th>Compte</th><th>Libellé</th><th>Mvt Débit</th><th>Mvt Crédit</th><th>Solde Débiteur</th><th>Solde Créditeur</th></tr></thead><tbody>{rows.map(r=><tr key={r.code}><td className="mono" style={{color:"var(--orange)"}}>{r.code}</td><td>{r.libelle}</td><td className="mono" style={{color:"var(--green)"}}>{fmt(r.debit,config.devise)}</td><td className="mono" style={{color:"var(--red)"}}>{fmt(r.credit,config.devise)}</td><td className="mono" style={{color:"var(--green)"}}>{r.sD?fmt(r.sD,config.devise):"—"}</td><td className="mono" style={{color:"var(--red)"}}>{r.sC?fmt(r.sC,config.devise):"—"}</td></tr>)}</tbody><tfoot><tr><td colSpan={2} style={{padding:"8px 10px",fontSize:9.5,fontWeight:700,color:"var(--g5)",textTransform:"uppercase",letterSpacing:"1.5px"}}>Totaux généraux</td><td className="mono" style={{padding:"8px 10px",color:"var(--green)"}}>{fmt(tot.debit,config.devise)}</td><td className="mono" style={{padding:"8px 10px",color:"var(--red)"}}>{fmt(tot.credit,config.devise)}</td><td className="mono" style={{padding:"8px 10px",color:"var(--green)"}}>{fmt(tot.sD,config.devise)}</td><td className="mono" style={{padding:"8px 10px",color:"var(--red)"}}>{fmt(tot.sC,config.devise)}</td></tr></tfoot></table></div>;})()} 
    {modal&&<Modal title="Nouvelle écriture comptable" sub={`Journal ${form.journal}`} icon="📒" onClose={()=>setModal(false)} width={820}>
      <div className="form-grid" style={{marginBottom:14}}><div className="form-group"><label>Date</label><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div><div className="form-group"><label>Journal</label><select value={form.journal} onChange={e=>setForm({...form,journal:e.target.value})}>{JOURNAUX.map(j=><option key={j}>{j}</option>)}</select></div><div className="form-group full"><label>Libellé</label><input value={form.libelle} onChange={e=>setForm({...form,libelle:e.target.value})}/></div><div className="form-group"><label>Référence pièce</label><input value={form.reference} onChange={e=>setForm({...form,reference:e.target.value})}/></div></div>
      <div className="panel" style={{marginBottom:12}}><div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Lignes d'écriture</div><button className="btn btn-outline btn-xs" onClick={addLigneCpta}>+ Ligne</button></div><div style={{padding:"10px 14px",overflowX:"auto"}}><table style={{fontSize:11.5}}><thead><tr><th>N° Compte</th><th>Libellé ligne</th><th>Débit</th><th>Crédit</th><th></th></tr></thead><tbody>{form.lignes.map((l,i)=><tr key={i}><td style={{minWidth:150}}><input value={l.compteCode} style={{width:"100%"}} onChange={e=>{updLigne(i,"compteCode",e.target.value);const cpt=comptes.find(c=>c.code===e.target.value);if(cpt)updLigne(i,"libelle",cpt.libelle);}} list="clist" placeholder="ex: 521000"/><datalist id="clist">{comptes.map(c=><option key={c.code} value={c.code}>{c.code} — {c.libelle}</option>)}</datalist></td><td style={{minWidth:180}}><input value={l.libelle} style={{width:"100%"}} onChange={e=>updLigne(i,"libelle",e.target.value)}/></td><td style={{minWidth:110}}><input type="number" value={l.debit} style={{width:"100%"}} onChange={e=>updLigne(i,"debit",+e.target.value)}/></td><td style={{minWidth:110}}><input type="number" value={l.credit} style={{width:"100%"}} onChange={e=>updLigne(i,"credit",+e.target.value)}/></td><td><button className="btn btn-danger btn-xs" onClick={()=>setForm({...form,lignes:form.lignes.filter((_,j)=>j!==i)})}>✕</button></td></tr>)}</tbody><tfoot><tr><td colSpan={2} style={{padding:"7px 10px",fontSize:9.5,fontWeight:700,color:"var(--g5)"}}>Totaux</td><td className="mono" style={{padding:"7px 10px",fontWeight:800,color:balanced?"var(--green)":"var(--red)"}}>{fmt(totalDebit,"")}</td><td className="mono" style={{padding:"7px 10px",fontWeight:800,color:balanced?"var(--green)":"var(--red)"}}>{fmt(totalCredit,"")}</td><td style={{padding:"7px 10px"}}>{balanced?<span className="badge badge-green">✓ Équilibrée</span>:<span className="badge badge-red">Diff. {fmt(Math.abs(totalDebit-totalCredit),"")}</span>}</td></tr></tfoot></table></div></div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(false)}>Annuler</button><button className="btn btn-primary btn-sm" disabled={!balanced} style={{opacity:balanced?1:.4,cursor:balanced?"pointer":"not-allowed"}} onClick={save}>Valider l'écriture</button></div>
    </Modal>}
  </div>;
}

// ─── RAPPORTS / LIASSE FISCALE ────────────────────────────────────────────────
function RapportsModule({state}){
  const {ecritures,comptes,config,factures,achats}=state;
  const [tab,setTab]=useState(0);
  const annee=new Date(config.exercice.debut).getFullYear();
  const D=config.devise;

  const balance=useMemo(()=>{const b={};ecritures.forEach(e=>{e.lignes.forEach(l=>{if(!b[l.compteCode])b[l.compteCode]={debit:0,credit:0};b[l.compteCode].debit+=l.debit||0;b[l.compteCode].credit+=l.credit||0;});});return b;},[ecritures]);
  const solNet=(code)=>{const d=balance[code];if(!d)return 0;return d.debit-d.credit;};
  const solDebit=(code)=>Math.max(0,solNet(code));
  const solCredit=(code)=>Math.max(0,-solNet(code));
  const getMasse=(classe,type)=>comptes.filter(c=>c.classe===classe&&c.type===type).map(c=>{const b=balance[c.code]||{debit:0,credit:0};const brut=b.debit;const amort=b.credit;const net=Math.max(0,brut-amort);return{...c,brut,amort,net,solde:type==="actif"?solDebit(c.code):solCredit(c.code)};}).filter(c=>c.brut>0||c.net>0||c.solde>0);

  const actifImmo=getMasse("2","actif");const actifCirc=[...getMasse("3","actif"),...getMasse("4","actif")];const actifTreso=getMasse("5","actif");
  const passifCap=getMasse("1","passif");const passifDettes=[...getMasse("4","passif"),...getMasse("5","passif")];
  const charges=getMasse("6","charge");const produits=getMasse("7","produit");
  const totActifImmo=actifImmo.reduce((s,c)=>s+c.net,0);const totActifCirc=actifCirc.reduce((s,c)=>s+c.solde,0);const totActifTreso=actifTreso.reduce((s,c)=>s+c.solde,0);const totalActif=totActifImmo+totActifCirc+totActifTreso;
  const totPassifCap=passifCap.reduce((s,c)=>s+c.solde,0);const totPassifDettes=passifDettes.reduce((s,c)=>s+c.solde,0);
  const totalCharges=charges.reduce((s,c)=>s+c.solde,0);const totalProduits=produits.reduce((s,c)=>s+c.solde,0);const resultat=totalProduits-totalCharges;
  const totalPassif=totPassifCap+totPassifDettes+(resultat||0);
  const totalVentes=factures.reduce((s,f)=>s+calcLignes(f.lignes,config.tauxTVA).ht,0);
  const totalAchatsHT=achats.reduce((s,a)=>s+calcLignes(a.lignes,config.tauxTVA).ht,0);
  const n=(v)=>(v&&Math.round(v)!==0)?new Intl.NumberFormat("fr-FR").format(Math.round(v)):"-";

  const TH={padding:"7px 10px",fontSize:"9.5px",fontWeight:700,textTransform:"uppercase",letterSpacing:"1.5px",borderBottom:"2px solid var(--navy)",color:"var(--navy2)",background:"linear-gradient(180deg,#f0f5fc,#e8f0f9)"};
  const TD=(extra={})=>({padding:"6px 10px",borderBottom:"1px solid var(--g1)",fontSize:"12px",...extra});
  const secRow=(bg="#0f2547",color="#dbeafe")=>({padding:"6px 10px",background:bg,color,fontSize:"9.5px",fontWeight:700,letterSpacing:"2px",textTransform:"uppercase"});
  const totRow=(extra={})=>({padding:"8px 10px",background:"#eef4fe",fontFamily:"var(--fm)",fontWeight:800,...extra});

  const BilTable=({cols,rows})=><div style={{overflowX:"auto",marginTop:10}}><table style={{width:"100%",borderCollapse:"collapse"}}><thead><tr>{cols.map((c,i)=><th key={i} style={{...TH,textAlign:i>0?"right":"left"}}>{c}</th>)}</tr></thead><tbody>{rows.map((r,ri)=>{if(!r)return <tr key={ri}><td colSpan={cols.length} style={{height:6,background:"var(--g1)"}}></td></tr>;if(r.section)return <tr key={ri}><td colSpan={cols.length} style={secRow(r.color,r.textColor)}>{r.label}</td></tr>;if(r.total)return <tr key={ri}><td colSpan={cols.length>3?cols.length-2:1} style={totRow({color:"var(--navy2)"})}>{r.label}</td>{r.values.map((v,vi)=><td key={vi} style={{...totRow(),textAlign:"right",color:"var(--navy4)",fontSize:13}}>{v}</td>)}</tr>;if(r.grand)return <tr key={ri}><td colSpan={cols.length>3?cols.length-2:1} style={{...totRow(),background:"var(--navy)",color:"#dbeafe"}}>{r.label}</td>{r.values.map((v,vi)=><td key={vi} style={{...totRow(),background:"var(--navy)",color:"#f0b429",textAlign:"right",fontSize:14}}>{v}</td>)}</tr>;return <tr key={ri} style={{background:ri%2===1?"var(--g0)":""}}>{r.cells.map((c,ci)=><td key={ci} style={TD({textAlign:ci>0?"right":"left",fontFamily:ci>0?"var(--fm)":"",color:ci===0?"var(--g7)":ci===1?"var(--navy3)":"var(--g4)"})}>{c}</td>)}</tr>;})}</tbody></table></div>;

  return <div>
    <div className="section-header"><div><div className="section-title">Liasse Fiscale OHADA</div><div className="section-sub">Exercice {annee} · Plan {config.planComptable} · {config.nomEntreprise}</div></div><div className="flex gap-8"><button className="btn btn-outline btn-sm" onClick={()=>window.print()}>🖨 Imprimer</button></div></div>
    <div style={{padding:"8px 12px",background:"linear-gradient(90deg,#eff6ff,var(--white))",border:"1px solid #bfdbfe",borderLeft:"3px solid var(--navy4)",borderRadius:"var(--r3)",marginBottom:14,display:"flex",alignItems:"center",justifyContent:"space-between",fontSize:12}}>
      <span style={{color:"var(--navy2)"}}><strong>{config.nomEntreprise}</strong> · {config.adresse}{config.rccm&&` · RCCM: ${config.rccm}`}{config.ifu&&` · IFU: ${config.ifu}`}</span>
      <span className={`badge badge-${Math.abs(totalActif-totalPassif)<1?"green":"red"}`} style={{fontSize:10}}>{Math.abs(totalActif-totalPassif)<1?"Bilan équilibré ✓":"Bilan déséquilibré ⚠"}</span>
    </div>
    <div className="tabs">{["Bilan Actif","Bilan Passif","Compte de Résultat","Indicateurs"].map((t,i)=><button key={i} className={`tab${tab===i?" active":""}`} onClick={()=>setTab(i)}>{t}</button>)}</div>
    {tab===0&&<BilTable cols={["N° Cpt","Désignation","Brut","Amort.","Net N","Net N-1"]} rows={[{section:true,label:"ACTIF IMMOBILISÉ"},{section:true,label:"Immobilisations corporelles et incorporelles",color:"#1a3a6b",textColor:"#93c5fd"},...(actifImmo.length===0?[{cells:["—","Aucune immobilisation","—","—","—","—"]}]:actifImmo.map(c=>({cells:[c.code,c.libelle,n(c.brut),n(c.amort)||"-",n(c.net),"-"]}))),{total:true,label:"Sous-total Actif Immobilisé",values:[n(actifImmo.reduce((s,c)=>s+c.brut,0)),n(actifImmo.reduce((s,c)=>s+c.amort,0)),n(totActifImmo),"-"]},{section:true,label:"ACTIF CIRCULANT",color:"#1a3a6b",textColor:"#93c5fd"},...(actifCirc.length===0?[{cells:["—","Aucun actif circulant","—","—","—","—"]}]:actifCirc.map(c=>({cells:[c.code,c.libelle,n(c.solde),"-",n(c.solde),"-"]}))),{total:true,label:"Sous-total Actif Circulant",values:[n(totActifCirc),"-",n(totActifCirc),"-"]},{section:true,label:"TRÉSORERIE — ACTIF",color:"#1a3a6b",textColor:"#93c5fd"},...(actifTreso.length===0?[{cells:["—","Aucune trésorerie actif","—","—","—","—"]}]:actifTreso.map(c=>({cells:[c.code,c.libelle,n(c.solde),"-",n(c.solde),"-"]}))),{total:true,label:"Sous-total Trésorerie-Actif",values:[n(totActifTreso),"-",n(totActifTreso),"-"]},{grand:true,label:"TOTAL GÉNÉRAL ACTIF",values:["-","-",n(totalActif),"-"]}]}/>}
    {tab===1&&<BilTable cols={["N° Cpt","Désignation","Montant N","Montant N-1"]} rows={[{section:true,label:"CAPITAUX PROPRES"},{section:true,label:"Ressources propres de financement",color:"#1a3a6b",textColor:"#93c5fd"},...(passifCap.length===0?[{cells:["—","Aucun","-","-"]}]:passifCap.map(c=>({cells:[c.code,c.libelle,n(c.solde),"-"]}))),{cells:["120000","Résultat de l'exercice "+(resultat>=0?"(bénéfice)":"(perte)"),n(Math.abs(resultat)),"-"]},{total:true,label:"Sous-total Capitaux Propres",values:[n(totPassifCap+(resultat||0)),"-"]},{section:true,label:"DETTES ET PASSIF CIRCULANT",color:"#1a3a6b",textColor:"#93c5fd"},...(passifDettes.length===0?[{cells:["—","Aucune dette","-","-"]}]:passifDettes.map(c=>({cells:[c.code,c.libelle,n(c.solde),"-"]}))),{total:true,label:"Sous-total Dettes et Passif Circulant",values:[n(totPassifDettes),"-"]},{grand:true,label:"TOTAL GÉNÉRAL PASSIF",values:[n(totalPassif),"-"]}]}/>}
    {tab===2&&<div className="grid-2" style={{gap:14}}>
      <div><div style={{padding:"6px 10px",background:"var(--red-bg)",borderLeft:"3px solid var(--red2)",fontSize:10,fontWeight:700,color:"var(--red)",textTransform:"uppercase",letterSpacing:"1.5px",marginBottom:4}}>Charges de l'exercice</div><div className="table-wrap"><table><thead><tr><th>Compte</th><th>Libellé</th><th style={{textAlign:"right"}}>Montant N</th></tr></thead><tbody>{charges.filter(c=>c.solde>0).map((c,i)=><tr key={i} style={{background:i%2===1?"var(--g0)":""}}><td className="mono" style={{color:"var(--orange)"}}>{c.code}</td><td>{c.libelle}</td><td className="mono" style={{textAlign:"right",color:"var(--red)"}}>{n(c.solde)}</td></tr>)}</tbody><tfoot><tr><td colSpan={2} style={{padding:"8px 10px",fontWeight:800,color:"var(--red)",fontSize:11}}>TOTAL CHARGES</td><td className="mono" style={{padding:"8px 10px",fontWeight:800,color:"var(--red)",textAlign:"right"}}>{n(totalCharges)}</td></tr></tfoot></table></div></div>
      <div><div style={{padding:"6px 10px",background:"var(--green-bg)",borderLeft:"3px solid var(--green2)",fontSize:10,fontWeight:700,color:"var(--green)",textTransform:"uppercase",letterSpacing:"1.5px",marginBottom:4}}>Produits de l'exercice</div><div className="table-wrap"><table><thead><tr><th>Compte</th><th>Libellé</th><th style={{textAlign:"right"}}>Montant N</th></tr></thead><tbody>{produits.filter(p=>p.solde>0).map((p,i)=><tr key={i} style={{background:i%2===1?"var(--g0)":""}}><td className="mono" style={{color:"var(--orange)"}}>{p.code}</td><td>{p.libelle}</td><td className="mono" style={{textAlign:"right",color:"var(--green)"}}>{n(p.solde)}</td></tr>)}</tbody><tfoot><tr><td colSpan={2} style={{padding:"8px 10px",fontWeight:800,color:"var(--green)",fontSize:11}}>TOTAL PRODUITS</td><td className="mono" style={{padding:"8px 10px",fontWeight:800,color:"var(--green)",textAlign:"right"}}>{n(totalProduits)}</td></tr></tfoot></table></div></div>
      <div style={{gridColumn:"1/-1",padding:"14px 18px",background:resultat>=0?"var(--green-bg)":"var(--red-bg)",border:"1px solid",borderColor:resultat>=0?"var(--green-bd)":"var(--red-bd)",borderRadius:"var(--r4)",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div><div style={{fontWeight:700,fontSize:13,color:resultat>=0?"var(--green)":"var(--red)"}}>{resultat>=0?"RÉSULTAT NET — BÉNÉFICE":"RÉSULTAT NET — PERTE"}</div><div style={{fontSize:10,color:resultat>=0?"var(--green)":"var(--red2)",fontFamily:"var(--fm)",marginTop:2}}>Total Produits − Total Charges</div></div>
        <div style={{fontFamily:"var(--fm)",fontSize:"1.6rem",fontWeight:800,color:resultat>=0?"var(--green)":"var(--red)"}}>{n(Math.abs(resultat))} <span style={{fontSize:"0.9rem",opacity:.7}}>{D}</span></div>
      </div>
    </div>}
    {tab===3&&<div>
      <div className="kpi-grid">
        {[{cl:"blue",icon:"📈",bg:"#dbeafe",lbl:"CA HT",val:fmt(totalVentes,D),sub:`${factures.length} factures`},{cl:"blue",icon:"📉",bg:"#dbeafe",lbl:"Achats HT",val:fmt(totalAchatsHT,D),sub:`${achats.length} cmds`},{cl:totalVentes-totalAchatsHT>=0?"green":"red",icon:"⚖️",bg:"#d1fae5",lbl:"Marge Brute",val:fmt(totalVentes-totalAchatsHT,D),sub:`Taux: ${totalVentes>0?((totalVentes-totalAchatsHT)/totalVentes*100).toFixed(1):0}%`},{cl:resultat>=0?"green":"red",icon:"💼",bg:resultat>=0?"#d1fae5":"#fee2e2",lbl:"Résultat Net",val:fmt(Math.abs(resultat),D),sub:resultat>=0?"Bénéfice":"Perte"},{cl:"blue",icon:"🏦",bg:"#dbeafe",lbl:"Total Actif",val:fmt(totalActif,D),sub:"Bilan"},{cl:"blue",icon:"💰",bg:"#dbeafe",lbl:"Capitaux Propres",val:fmt(totPassifCap+(resultat||0),D),sub:"Dont résultat"}].map((s,i)=><div key={i} className={`kpi-card ${s.cl}`}><div className="kpi-icon" style={{background:s.bg,marginBottom:8}}>{s.icon}</div><div className="kpi-lbl">{s.lbl}</div><div className="kpi-val" style={{fontSize:"1rem"}}>{s.val}</div><div className="kpi-sub">{s.sub}</div></div>)}
      </div>
    </div>}
  </div>;
}

// ─── PLAN COMPTABLE ───────────────────────────────────────────────────────────
function PlanComptableModule({state,dispatch}){
  const {comptes,config}=state;
  const [modal,setModal]=useState(false);
  const [filtre,setFiltre]=useState("");
  const [form,setForm]=useState({code:"",libelle:"",classe:"1",type:"actif"});
  const filtered=comptes.filter(c=>c.code.includes(filtre)||c.libelle.toLowerCase().includes(filtre.toLowerCase()));
  const byClasse={};filtered.forEach(c=>{if(!byClasse[c.classe])byClasse[c.classe]=[];byClasse[c.classe].push(c);});
  const CLASSES={"1":"Capitaux","2":"Actifs immobilisés","3":"Stocks","4":"Comptes de tiers","5":"Trésorerie","6":"Charges","7":"Produits","8":"Comptes spéciaux"};
  const TYPE_BADGE={actif:"badge-blue",passif:"badge-amber",charge:"badge-red",produit:"badge-jade"};
  return <div>
    <div className="section-header"><div><div className="section-title">Plan Comptable {config.planComptable}</div><div className="section-sub">{comptes.length} comptes</div></div><div className="flex gap-8"><select style={{padding:"6px 10px",borderRadius:"var(--r2)",fontSize:12,border:"1px solid var(--g3)",color:"var(--g6)",background:"var(--white)"}} value={config.planComptable} onChange={e=>dispatch({type:"SET_PLAN",payload:e.target.value})}><option value="OHADA">OHADA</option><option value="PCG">PCG France</option></select><button className="btn btn-primary btn-sm" onClick={()=>{setForm({code:"",libelle:"",classe:"1",type:"actif"});setModal(true);}}>+ Ajouter</button></div></div>
    <input placeholder="Rechercher par code ou libellé…" value={filtre} onChange={e=>setFiltre(e.target.value)} style={{marginBottom:14,padding:"7px 12px",width:"100%",borderRadius:"var(--r3)",border:"1px solid var(--g3)",fontSize:12.5,outline:"none"}}/>
    {Object.entries(byClasse).sort(([a],[b])=>a.localeCompare(b)).map(([cl,cpts])=><div key={cl} style={{marginBottom:12}}>
      <div style={{padding:"6px 12px",background:"linear-gradient(90deg,var(--navy),var(--navy2))",borderRadius:"var(--r3) var(--r3) 0 0",display:"flex",alignItems:"center",gap:10}}>
        <span style={{fontFamily:"var(--fm)",color:"#93c5fd",fontWeight:700,fontSize:12}}>Cl. {cl}</span>
        <span style={{color:"#dbeafe",fontSize:11.5,fontWeight:600}}>{CLASSES[cl]||""}</span>
        <span className="badge badge-blue" style={{marginLeft:"auto",fontSize:9}}>{cpts.length}</span>
      </div>
      <div className="table-wrap" style={{borderRadius:"0 0 var(--r3) var(--r3)",borderTop:"none"}}><table><tbody>{cpts.sort((a,b)=>a.code.localeCompare(b.code)).map(c=><tr key={c.code}><td className="mono" style={{color:"var(--orange)",width:100}}>{c.code}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{c.libelle}</td><td style={{width:90}}><span className={`badge ${TYPE_BADGE[c.type]||"badge-blue"}`}>{c.type}</span></td><td style={{width:40}}><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_COMPTE",payload:c.code})}>✕</button></td></tr>)}</tbody></table></div>
    </div>)}
    {modal&&<Modal title="Ajouter un compte" icon="📚" onClose={()=>setModal(false)} width={500}><div className="form-grid"><div className="form-group"><label>N° Compte</label><input value={form.code} onChange={e=>setForm({...form,code:e.target.value})} placeholder="ex: 521100"/></div><div className="form-group"><label>Classe</label><select value={form.classe} onChange={e=>setForm({...form,classe:e.target.value})}>{["1","2","3","4","5","6","7","8"].map(c=><option key={c}>{c}</option>)}</select></div><div className="form-group full"><label>Libellé</label><input value={form.libelle} onChange={e=>setForm({...form,libelle:e.target.value})}/></div><div className="form-group"><label>Type</label><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option value="actif">Actif</option><option value="passif">Passif</option><option value="charge">Charge</option><option value="produit">Produit</option></select></div></div><div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(false)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={()=>{if(!form.code||!form.libelle)return;dispatch({type:"ADD_COMPTE",payload:form});setModal(false);}}>Ajouter</button></div></Modal>}
  </div>;
}

// ─── CONFIG ───────────────────────────────────────────────────────────────────
function ConfigModule({state,dispatch}){
  const {config}=state;
  const [form,setForm]=useState({...config});
  const [saved,setSaved]=useState(false);
  const save=()=>{dispatch({type:"SET_CONFIG",payload:{...form,tauxTVA:+form.tauxTVA}});setSaved(true);setTimeout(()=>setSaved(false),2500);};
  return <div>
    <div className="section-header"><div><div className="section-title">Configuration Dossier</div><div className="section-sub">Paramètres entreprise et exercice comptable</div></div><div className="flex gap-8 items-center">{saved&&<span className="badge badge-green" style={{fontSize:11}}>✓ Enregistré</span>}<button className="btn btn-primary" onClick={save}>Enregistrer</button></div></div>
    <div className="grid-2" style={{gap:14}}>
      <div className="panel"><div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Informations Entreprise</div></div><div className="panel-body"><div className="form-grid"><div className="form-group full"><label>Raison sociale</label><input value={form.nomEntreprise} onChange={e=>setForm({...form,nomEntreprise:e.target.value})}/></div><div className="form-group full"><label>Adresse complète</label><input value={form.adresse} onChange={e=>setForm({...form,adresse:e.target.value})}/></div><div className="form-group"><label>Téléphone</label><input value={form.telephone} onChange={e=>setForm({...form,telephone:e.target.value})}/></div><div className="form-group"><label>Email</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></div><div className="form-group"><label>RCCM</label><input value={form.rccm} onChange={e=>setForm({...form,rccm:e.target.value})}/></div><div className="form-group"><label>IFU / NIF</label><input value={form.ifu} onChange={e=>setForm({...form,ifu:e.target.value})}/></div></div></div></div>
      <div style={{display:"flex",flexDirection:"column",gap:12}}>
        <div className="panel"><div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Paramètres Comptables</div></div><div className="panel-body"><div className="form-grid"><div className="form-group"><label>Plan Comptable</label><select value={form.planComptable} onChange={e=>{setForm({...form,planComptable:e.target.value});dispatch({type:"SET_PLAN",payload:e.target.value});}}><option value="OHADA">OHADA — Afrique</option><option value="PCG">PCG — France</option></select></div><div className="form-group"><label>Devise</label><select value={form.devise} onChange={e=>setForm({...form,devise:e.target.value})}><option value="FCFA">FCFA</option><option value="EUR">EUR</option><option value="USD">USD</option><option value="XOF">XOF</option></select></div><div className="form-group"><label>Taux TVA (%)</label><input type="number" value={form.tauxTVA} onChange={e=>setForm({...form,tauxTVA:e.target.value})}/></div></div></div></div>
        <div className="panel"><div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Exercice Comptable</div></div><div className="panel-body"><div className="form-grid"><div className="form-group"><label>Début d'exercice</label><input type="date" value={form.exercice?.debut||""} onChange={e=>setForm({...form,exercice:{...form.exercice,debut:e.target.value}})}/></div><div className="form-group"><label>Fin d'exercice</label><input type="date" value={form.exercice?.fin||""} onChange={e=>setForm({...form,exercice:{...form.exercice,fin:e.target.value}})}/></div></div></div></div>
      </div>
    </div>
  </div>;
}

// ─── PAIE ─────────────────────────────────────────────────────────────────────
function calcBulletin(emp,params){
  const primes=(emp.primes||[]).reduce((s,p)=>s+(+p.montant||0),0);
  const salBrut=(+emp.salBase||0)+primes;
  const baseCNPS=Math.min(salBrut,+params.plafondCNPS||600000);
  const cnps_sal=Math.round(baseCNPS*(+params.tauxCNPS_sal||3.6)/100);
  const cnps_pat=Math.round(baseCNPS*(+params.tauxCNPS_pat||16.4)/100);
  const its=Math.round((salBrut-cnps_sal)*(+params.tauxITS||15)/100);
  const salaireNet=salBrut-cnps_sal-its;
  return{salBrut,primes,cnps_sal,cnps_pat,its,salaireNet,coutTotal:salBrut+cnps_pat};
}
const MOIS_FR=["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
const fmtMois=m=>{if(!m)return"—";const [y,mo]=m.split("-");return `${MOIS_FR[+mo-1]} ${y}`;};

function PaieModule({state,dispatch}){
  const {employes,bulletins,parametresPaie,config}=state;
  const [tab,setTab]=useState(0);
  const [modal,setModal]=useState(null);
  const [viewBul,setViewBul]=useState(null);
  const [empForm,setEmpForm]=useState({matricule:"",nom:"",poste:"",departement:"",dateEmbauche:"",salBase:0,primes:[],statut:"actif"});
  const [bulForm,setBulForm]=useState({employeId:"",mois:new Date().toISOString().slice(0,7),date:new Date().toISOString().slice(0,10)});
  const [newPrime,setNewPrime]=useState({libelle:"",montant:0});

  const saveEmp=()=>{if(!empForm.nom)return;if(empForm.id)dispatch({type:"UPD_EMPLOYE",payload:{...empForm,salBase:+empForm.salBase}});else dispatch({type:"ADD_EMPLOYE",payload:{...empForm,id:genId(),salBase:+empForm.salBase}});setModal(null);};
  const genBulletin=()=>{const emp=employes.find(e=>e.id===+bulForm.employeId);if(!emp)return;const calc=calcBulletin(emp,parametresPaie);dispatch({type:"ADD_BULLETIN",payload:{id:genId(),mois:bulForm.mois,employeId:emp.id,salBase:emp.salBase,primes:[...emp.primes||[]],cotisations:{cnps_sal:calc.cnps_sal,its:calc.its,cnps_pat:calc.cnps_pat},salaireNet:calc.salaireNet,statut:"en attente",date:bulForm.date}});setModal(null);};
  const moisDispos=[...new Set(bulletins.map(b=>b.mois))].sort().reverse();
  const masseNette=employes.filter(e=>e.statut==="actif").reduce((s,e)=>s+calcBulletin(e,parametresPaie).salaireNet,0);

  return <div>
    <div className="section-header"><div><div className="section-title">Gestion de la Paie</div><div className="section-sub">{employes.filter(e=>e.statut==="actif").length} employé(s) actif(s) · Masse nette estimée : {fmt(masseNette,config.devise)}</div></div><div className="flex gap-8"><button className="btn btn-outline btn-sm" onClick={()=>{setEmpForm({matricule:`EMP${String(employes.length+1).padStart(3,"0")}`,nom:"",poste:"",departement:"",dateEmbauche:"",salBase:0,primes:[],statut:"actif"});setModal("employe");}}>+ Employé</button><button className="btn btn-primary btn-sm" onClick={()=>{setBulForm({employeId:"",mois:new Date().toISOString().slice(0,7),date:new Date().toISOString().slice(0,10)});setModal("bulletin");}}>+ Bulletin de Paie</button></div></div>
    <div className="kpi-grid" style={{gridTemplateColumns:"repeat(4,1fr)",marginBottom:14}}>
      {[{cl:"blue",bg:"#dbeafe",icon:"👷",lbl:"Effectif actif",val:employes.filter(e=>e.statut==="actif").length.toString()},{cl:"green",bg:"#d1fae5",icon:"💵",lbl:"Masse salariale nette",val:fmt(masseNette,config.devise)},{cl:"blue",bg:"#dbeafe",icon:"🏦",lbl:"Coût total employeur",val:fmt(employes.filter(e=>e.statut==="actif").reduce((s,e)=>s+calcBulletin(e,parametresPaie).coutTotal,0),config.devise)},{cl:"green",bg:"#d1fae5",icon:"📋",lbl:"Bulletins émis",val:bulletins.length.toString()}].map((s,i)=><div key={i} className={`kpi-card ${s.cl}`}><div className="kpi-icon" style={{background:s.bg,marginBottom:8}}>{s.icon}</div><div className="kpi-lbl">{s.lbl}</div><div className="kpi-val" style={{fontSize:"1rem"}}>{s.val}</div></div>)}
    </div>
    <div className="tabs">{["Employés","Bulletins de Paie"].map((t,i)=><button key={i} className={`tab${tab===i?" active":""}`} onClick={()=>setTab(i)}>{t}</button>)}</div>
    {tab===0&&<div className="table-wrap"><table><thead><tr><th>Matricule</th><th>Nom & Prénom</th><th>Poste</th><th>Département</th><th>Base</th><th>Primes</th><th>Brut</th><th>Net Estimé</th><th>Statut</th><th></th></tr></thead><tbody>{employes.map(e=>{const calc=calcBulletin(e,parametresPaie);return <tr key={e.id}><td className="mono" style={{color:"var(--orange)"}}>{e.matricule}</td><td style={{fontWeight:600,color:"var(--g7)"}}>{e.nom}</td><td style={{color:"var(--g6)"}}>{e.poste}</td><td><span className="badge badge-blue">{e.departement}</span></td><td className="mono">{fmt(e.salBase,config.devise)}</td><td className="mono" style={{color:"var(--green)"}}>{fmt(calc.primes,config.devise)}</td><td className="mono" style={{fontWeight:600}}>{fmt(calc.salBrut,config.devise)}</td><td className="mono" style={{color:"var(--green)",fontWeight:700}}>{fmt(calc.salaireNet,config.devise)}</td><td><span className={`badge badge-${e.statut==="actif"?"green":"red"}`}>{e.statut}</span></td><td><div className="flex gap-6"><button className="btn btn-outline btn-xs" onClick={()=>{setEmpForm({...e});setModal("employe");}}>✏️</button><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_EMPLOYE",payload:e.id})}>✕</button></div></td></tr>;})}
    </tbody></table></div>}
    {tab===1&&<div>
      {moisDispos.length===0&&<div className="empty"><div className="empty-icon">📋</div><div className="empty-text">Aucun bulletin généré</div></div>}
      {moisDispos.map(mois=>{
        const buls=bulletins.filter(b=>b.mois===mois);
        const totNet=buls.reduce((s,b)=>s+b.salaireNet,0);
        const totBrut=buls.reduce((s,b)=>s+b.salBase+(b.primes||[]).reduce((sp,p)=>sp+p.montant,0),0);
        return <div key={mois} style={{marginBottom:14}}>
          <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"7px 12px",background:"linear-gradient(90deg,var(--navy),var(--navy2))",borderRadius:"var(--r3) var(--r3) 0 0"}}>
            <div className="flex items-center gap-10"><span style={{fontFamily:"var(--fm)",fontSize:12,fontWeight:700,color:"#dbeafe"}}>{fmtMois(mois)}</span><span className="badge badge-blue" style={{fontSize:9}}>{buls.length} bul.</span></div>
            <div className="flex items-center gap-12"><span style={{fontSize:11,color:"#4a6fa5"}}>Brut: <span className="mono" style={{color:"#93c5fd"}}>{fmt(totBrut,config.devise)}</span></span><span style={{fontSize:11,color:"#4a6fa5"}}>Net: <span className="mono" style={{color:"#34d399",fontWeight:700}}>{fmt(totNet,config.devise)}</span></span></div>
          </div>
          <div className="table-wrap" style={{borderRadius:"0 0 var(--r3) var(--r3)",borderTop:"none"}}>
            <table><thead><tr><th>Matricule</th><th>Employé</th><th>Brut</th><th>CNPS Sal.</th><th>ITS</th><th>Net à Payer</th><th>Statut</th><th></th></tr></thead>
            <tbody>{buls.map(b=>{const emp=employes.find(e=>e.id===b.employeId);const brut=b.salBase+(b.primes||[]).reduce((s,p)=>s+p.montant,0);return <tr key={b.id}><td className="mono" style={{color:"var(--orange)"}}>{emp?.matricule||"?"}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{emp?.nom||"?"}</td><td className="mono">{fmt(brut,config.devise)}</td><td className="mono" style={{color:"var(--red)"}}>-{fmt(b.cotisations.cnps_sal,config.devise)}</td><td className="mono" style={{color:"var(--red)"}}>-{fmt(b.cotisations.its,config.devise)}</td><td className="mono" style={{color:"var(--green)",fontWeight:700}}>{fmt(b.salaireNet,config.devise)}</td><td><span className={`badge badge-${b.statut==="payé"?"green":"orange"}`}>{b.statut}</span></td><td><button className="btn btn-outline btn-xs" onClick={()=>setViewBul(b)}>Aperçu</button></td></tr>;})}
            </tbody></table>
          </div>
        </div>;
      })}
    </div>}

    {modal==="employe"&&<Modal title={empForm.id?"Modifier employé":"Nouvel employé"} sub="Fiche salariale" icon="👷" onClose={()=>setModal(null)} width={660}>
      <div className="form-grid" style={{marginBottom:12}}>
        <div className="form-group"><label>Matricule</label><input value={empForm.matricule} onChange={e=>setEmpForm({...empForm,matricule:e.target.value})}/></div>
        <div className="form-group"><label>Statut</label><select value={empForm.statut} onChange={e=>setEmpForm({...empForm,statut:e.target.value})}><option value="actif">Actif</option><option value="inactif">Inactif</option></select></div>
        <div className="form-group full"><label>Nom & Prénom</label><input value={empForm.nom} onChange={e=>setEmpForm({...empForm,nom:e.target.value})}/></div>
        <div className="form-group"><label>Poste</label><input value={empForm.poste} onChange={e=>setEmpForm({...empForm,poste:e.target.value})}/></div>
        <div className="form-group"><label>Département</label><input value={empForm.departement} onChange={e=>setEmpForm({...empForm,departement:e.target.value})}/></div>
        <div className="form-group"><label>Date d'embauche</label><input type="date" value={empForm.dateEmbauche} onChange={e=>setEmpForm({...empForm,dateEmbauche:e.target.value})}/></div>
        <div className="form-group"><label>Salaire de base ({config.devise})</label><input type="number" value={empForm.salBase} onChange={e=>setEmpForm({...empForm,salBase:e.target.value})}/></div>
      </div>
      <div className="panel" style={{marginBottom:12}}>
        <div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>Primes</div></div>
        <div style={{padding:"8px 12px"}}>
          {(empForm.primes||[]).map((p,i)=><div key={i} className="list-item"><span style={{color:"var(--g6)",fontSize:12}}>{p.libelle}</span><div className="flex items-center gap-8"><span className="mono" style={{color:"var(--green)",fontSize:11}}>{fmt(p.montant,config.devise)}</span><button className="btn btn-danger btn-xs" onClick={()=>setEmpForm({...empForm,primes:empForm.primes.filter((_,j)=>j!==i)})}>✕</button></div></div>)}
          <div className="divider"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 120px auto",gap:8,alignItems:"flex-end"}}>
            <div className="form-group" style={{margin:0}}><label>Libellé prime</label><input value={newPrime.libelle} onChange={e=>setNewPrime({...newPrime,libelle:e.target.value})} placeholder="ex: Prime de transport"/></div>
            <div className="form-group" style={{margin:0}}><label>Montant</label><input type="number" value={newPrime.montant} onChange={e=>setNewPrime({...newPrime,montant:e.target.value})}/></div>
            <button className="btn btn-primary btn-sm" style={{alignSelf:"flex-end"}} onClick={()=>{if(!newPrime.libelle)return;setEmpForm({...empForm,primes:[...(empForm.primes||[]),{libelle:newPrime.libelle,montant:+newPrime.montant}]});setNewPrime({libelle:"",montant:0});}}>+</button>
          </div>
          {empForm.salBase&&(()=>{const calc=calcBulletin({...empForm,salBase:+empForm.salBase},parametresPaie);return <div style={{marginTop:10,display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6,padding:"10px 12px",background:"var(--navy-pale)",border:"1px solid var(--navy-mid)",borderRadius:"var(--r3)"}}>{[["Brut",calc.salBrut,"var(--navy4)"],["CNPS",-calc.cnps_sal,"var(--red)"],["ITS",-calc.its,"var(--red)"],["Net",calc.salaireNet,"var(--green)"]].map(([l,v,c],i)=><div key={i}><div style={{fontSize:9,color:"var(--g4)",textTransform:"uppercase",letterSpacing:"1.5px",marginBottom:2}}>{l}</div><div className="mono" style={{fontWeight:700,color:c,fontSize:13}}>{fmt(Math.abs(v),config.devise)}</div></div>)}</div>;})()} 
        </div>
      </div>
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(null)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={saveEmp}>Enregistrer</button></div>
    </Modal>}

    {modal==="bulletin"&&<Modal title="Générer un bulletin" sub="Calcul automatique CNPS + ITS" icon="📋" onClose={()=>setModal(null)} width={540}>
      <div className="form-grid" style={{marginBottom:14}}>
        <div className="form-group"><label>Employé</label><select value={bulForm.employeId} onChange={e=>setBulForm({...bulForm,employeId:e.target.value})}><option value="">— Sélectionner —</option>{employes.filter(e=>e.statut==="actif").map(e=><option key={e.id} value={e.id}>{e.matricule} — {e.nom}</option>)}</select></div>
        <div className="form-group"><label>Mois de paie</label><input type="month" value={bulForm.mois} onChange={e=>setBulForm({...bulForm,mois:e.target.value})}/></div>
        <div className="form-group"><label>Date de paiement</label><input type="date" value={bulForm.date} onChange={e=>setBulForm({...bulForm,date:e.target.value})}/></div>
      </div>
      {bulForm.employeId&&(()=>{const emp=employes.find(e=>e.id===+bulForm.employeId);if(!emp)return null;const calc=calcBulletin(emp,parametresPaie);return <div style={{background:"var(--panel)",border:"1px solid var(--g2)",borderRadius:"var(--r3)",padding:"12px 14px",marginBottom:12}}><div style={{fontWeight:700,fontSize:12,color:"var(--navy2)",marginBottom:10}}>{emp.nom} — {fmtMois(bulForm.mois)}</div><div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"5px 20px",fontSize:12}}>{[["Salaire de base",fmt(emp.salBase,config.devise),""],["Primes",fmt(calc.primes,config.devise),"var(--green)"],["Brut total",fmt(calc.salBrut,config.devise),"var(--navy2)"],["CNPS ("+parametresPaie.tauxCNPS_sal+"%)","-"+fmt(calc.cnps_sal,config.devise),"var(--red)"],["ITS ("+parametresPaie.tauxITS+"%)","-"+fmt(calc.its,config.devise),"var(--red)"]].map(([l,v,c],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",borderBottom:"1px solid var(--g2)"}}><span style={{color:"var(--g5)"}}>{l}</span><span className="mono" style={{color:c||"var(--g7)",fontWeight:600}}>{v}</span></div>)}</div><div style={{display:"flex",justifyContent:"space-between",padding:"10px 0 0",fontWeight:800,fontSize:13,borderTop:"2px solid var(--navy)",marginTop:6}}><span>Net à payer</span><span className="mono" style={{color:"var(--green)",fontSize:15}}>{fmt(calc.salaireNet,config.devise)}</span></div></div>;})()} 
      <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(null)}>Annuler</button><button className="btn btn-primary btn-sm" disabled={!bulForm.employeId} style={{opacity:bulForm.employeId?1:.4}} onClick={genBulletin}>Générer</button></div>
    </Modal>}

    {viewBul&&(()=>{const emp=employes.find(e=>e.id===viewBul.employeId);const brut=viewBul.salBase+(viewBul.primes||[]).reduce((s,p)=>s+p.montant,0);return <div className="modal-overlay" onClick={()=>setViewBul(null)}><div className="modal" style={{maxWidth:600}} onClick={e=>e.stopPropagation()}><div className="modal-titlebar"><div className="modal-title-icon">📋</div><div className="modal-title">Bulletin de Paie — {fmtMois(viewBul.mois)}</div><button className="modal-close" onClick={()=>setViewBul(null)}>✕</button></div><div className="modal-body"><div style={{padding:"20px 24px",fontFamily:"var(--fb)"}}>
      <div style={{display:"flex",justifyContent:"space-between",marginBottom:18,paddingBottom:14,borderBottom:"2px solid var(--navy)"}}>
        <div><div style={{fontWeight:800,fontSize:17,color:"var(--navy)",letterSpacing:"-.3px"}}>{config.nomEntreprise}</div><div style={{fontSize:11.5,color:"var(--g5)",marginTop:2}}>{config.adresse}</div></div>
        <div style={{textAlign:"right"}}><div style={{fontWeight:800,fontSize:14,color:"var(--navy2)",textTransform:"uppercase",letterSpacing:"1.5px"}}>Bulletin de Paie</div><div style={{fontFamily:"var(--fm)",fontSize:12,color:"var(--g7)",marginTop:2}}>{fmtMois(viewBul.mois)}</div></div>
      </div>
      <div style={{background:"var(--panel)",borderRadius:"var(--r3)",padding:"10px 14px",marginBottom:14,border:"1px solid var(--g2)",display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
        {[["Nom",emp?.nom||"?"],["Matricule",emp?.matricule||"?"],["Poste",emp?.poste||"?"],["Date paiement",fmtDate(viewBul.date)]].map(([l,v],i)=><div key={i}><div style={{fontSize:9,color:"var(--g4)",textTransform:"uppercase",letterSpacing:"1.5px",fontWeight:700,marginBottom:2}}>{l}</div><div style={{fontWeight:600,color:"var(--g8)",fontSize:13}}>{v}</div></div>)}
      </div>
      <table style={{width:"100%",borderCollapse:"collapse",marginBottom:14,fontSize:12.5}}><thead><tr style={{background:"var(--navy)"}}><th style={{padding:"7px 12px",color:"rgba(219,234,254,.7)",fontSize:9.5,letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600,textAlign:"left"}}>Rubrique</th><th style={{padding:"7px 12px",color:"rgba(219,234,254,.7)",fontSize:9.5,letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600,textAlign:"right"}}>Gains</th><th style={{padding:"7px 12px",color:"rgba(219,234,254,.7)",fontSize:9.5,letterSpacing:"1.5px",textTransform:"uppercase",fontWeight:600,textAlign:"right"}}>Retenues</th></tr></thead><tbody>
        <tr style={{borderBottom:"1px solid var(--g2)"}}><td style={{padding:"7px 12px"}}>Salaire de base</td><td style={{padding:"7px 12px",textAlign:"right",fontFamily:"var(--fm)",fontWeight:600}}>{fmt(viewBul.salBase,"")}</td><td></td></tr>
        {(viewBul.primes||[]).map((p,i)=><tr key={i} style={{background:"var(--g0)",borderBottom:"1px solid var(--g2)"}}><td style={{padding:"7px 12px",color:"var(--g6)"}}>{p.libelle}</td><td style={{padding:"7px 12px",textAlign:"right",fontFamily:"var(--fm)",color:"var(--g6)"}}>{fmt(p.montant,"")}</td><td></td></tr>)}
        <tr style={{borderBottom:"1px solid var(--g2)"}}><td style={{padding:"7px 12px"}}>CNPS salarié ({parametresPaie.tauxCNPS_sal}%)</td><td></td><td style={{padding:"7px 12px",textAlign:"right",fontFamily:"var(--fm)",color:"var(--red)"}}>{fmt(viewBul.cotisations.cnps_sal,"")}</td></tr>
        <tr style={{background:"var(--g0)",borderBottom:"1px solid var(--g2)"}}><td style={{padding:"7px 12px"}}>ITS ({parametresPaie.tauxITS}%)</td><td></td><td style={{padding:"7px 12px",textAlign:"right",fontFamily:"var(--fm)",color:"var(--red)"}}>{fmt(viewBul.cotisations.its,"")}</td></tr>
      </tbody></table>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:12}}>
        <div style={{padding:"10px 14px",background:"var(--panel)",borderRadius:"var(--r3)",border:"1px solid var(--g2)"}}><div style={{fontSize:9,color:"var(--g4)",textTransform:"uppercase",letterSpacing:"1.5px",marginBottom:3}}>Total Brut</div><div style={{fontFamily:"var(--fm)",fontSize:14,fontWeight:700,color:"var(--navy2)"}}>{fmt(brut,config.devise)}</div></div>
        <div style={{padding:"10px 14px",background:"var(--green-bg)",borderRadius:"var(--r3)",border:"1px solid var(--green-bd)"}}><div style={{fontSize:9,color:"var(--green)",textTransform:"uppercase",letterSpacing:"1.5px",marginBottom:3}}>Net à Payer</div><div style={{fontFamily:"var(--fm)",fontSize:16,fontWeight:800,color:"var(--green)"}}>{fmt(viewBul.salaireNet,config.devise)}</div></div>
      </div>
    </div></div><div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setViewBul(null)}>Fermer</button><button className="btn btn-primary btn-sm" onClick={()=>window.print()}>🖨 Imprimer</button></div></div></div>;})()} 
  </div>;
}

// ─── RAPPROCHEMENT BANCAIRE ───────────────────────────────────────────────────
function RapprochementModule({state,dispatch}){
  const {relevésBancaires=[],ecritures=[],config,rapprochements=[]}=state;
  const D=config.devise;
  const [tab,setTab]=useState(0);
  const [modal,setModal]=useState(null);
  const [filtreMois,setFiltreMois]=useState(new Date().toISOString().slice(0,7));
  const [form,setForm]=useState({date:"",libelle:"",montant:0,type:"credit",ref:""});

  const ecrituresBanque=useMemo(()=>{const rows=[];ecritures.forEach(e=>{e.lignes.forEach(l=>{if(l.compteCode&&l.compteCode.startsWith("52")){rows.push({id:e.id+"-"+l.compteCode,date:e.date,libelle:e.libelle,debit:l.debit||0,credit:l.credit||0,ref:e.reference,journal:e.journal});}});});return rows.sort((a,b)=>new Date(a.date)-new Date(b.date));},[ecritures]);

  const relevéFiltré=relevésBancaires.filter(r=>r.date&&r.date.slice(0,7)===filtreMois);
  const soldeBancaire=relevésBancaires.reduce((s,r)=>s+r.montant,0);
  const soldeComptable=ecrituresBanque.reduce((s,r)=>s+r.debit-r.credit,0);
  const écart=soldeBancaire-soldeComptable;

  return <div>
    <div className="section-header"><div><div className="section-title">Rapprochement Bancaire</div><div className="section-sub">{relevésBancaires.length} ligne(s) relevé · {relevésBancaires.filter(r=>r.rapproché).length} rapprochée(s)</div></div><div className="flex gap-8"><button className="btn btn-outline btn-sm" onClick={()=>dispatch({type:"SAVE_RAPPROCHEMENT",payload:{id:genId(),date:new Date().toISOString().slice(0,10),soldeBancaire,soldeComptable,ecart:écart,statut:Math.abs(écart)<1?"équilibré":"avec écart"}})}>💾 Sauvegarder</button><button className="btn btn-primary btn-sm" onClick={()=>{setForm({date:new Date().toISOString().slice(0,10),libelle:"",montant:0,type:"credit",ref:""});setModal("releve");}}>+ Ligne relevé</button></div></div>
    <div className="kpi-grid" style={{gridTemplateColumns:"repeat(4,1fr)",marginBottom:14}}>
      {[{cl:"blue",bg:"#dbeafe",icon:"🏦",lbl:"Solde Relevé",val:fmt(soldeBancaire,D)},{cl:"blue",bg:"#dbeafe",icon:"📒",lbl:"Solde Comptable",val:fmt(soldeComptable,D)},{cl:Math.abs(écart)<1?"green":"red",bg:Math.abs(écart)<1?"#d1fae5":"#fee2e2",icon:"⚖️",lbl:"Écart",val:fmt(Math.abs(écart),D)},{cl:"green",bg:"#d1fae5",icon:"🔗",lbl:"Rapprochées",val:`${relevésBancaires.filter(r=>r.rapproché).length}/${relevésBancaires.length}`}].map((s,i)=><div key={i} className={`kpi-card ${s.cl}`}><div className="kpi-icon" style={{background:s.bg,marginBottom:8}}>{s.icon}</div><div className="kpi-lbl">{s.lbl}</div><div className="kpi-val" style={{fontSize:"1rem"}}>{s.val}</div></div>)}
    </div>
    <div className="tabs">{["Relevé Bancaire","Écritures Comptables","État de Rapprochement"].map((t,i)=><button key={i} className={`tab${tab===i?" active":""}`} onClick={()=>setTab(i)}>{t}</button>)}</div>
    {tab===0&&<div><div className="flex items-center gap-10 mb-10"><label style={{fontSize:10.5,color:"var(--g5)",fontWeight:700}}>Filtre mois :</label><input type="month" value={filtreMois} onChange={e=>setFiltreMois(e.target.value)} style={{width:150}}/><span style={{fontSize:10.5,color:"var(--g4)",fontFamily:"var(--fm)"}}>{relevéFiltré.length} op.</span></div>
      <div className="table-wrap"><table><thead><tr><th></th><th>Date</th><th>Libellé</th><th>Référence</th><th>Débit</th><th>Crédit</th><th>Statut</th><th></th></tr></thead><tbody>{relevéFiltré.map(r=><tr key={r.id} style={{opacity:r.rapproché?.65:1}}><td style={{width:36}}><input type="checkbox" checked={r.rapproché||false} onChange={()=>dispatch({type:"TOGGLE_RAPPROCHE",payload:r.id})} style={{width:14,height:14,cursor:"pointer",accentColor:"var(--navy4)"}}/></td><td className="mono">{fmtDate(r.date)}</td><td style={{fontWeight:500,color:"var(--g7)"}}>{r.libelle}</td><td className="mono" style={{color:"var(--g4)"}}>{r.ref||"—"}</td><td className="mono" style={{color:"var(--red)"}}>{r.montant<0?fmt(Math.abs(r.montant),D):"—"}</td><td className="mono" style={{color:"var(--green)"}}>{r.montant>0?fmt(r.montant,D):"—"}</td><td>{r.rapproché?<span className="badge badge-green">✓</span>:<span className="badge badge-orange">Attente</span>}</td><td><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_RELEVE",payload:r.id})}>✕</button></td></tr>)}</tbody></table></div>
    </div>}
    {tab===1&&<div className="table-wrap"><table><thead><tr><th>Date</th><th>Journal</th><th>Libellé</th><th>Débit</th><th>Crédit</th></tr></thead><tbody>{ecrituresBanque.map((e,i)=><tr key={i}><td className="mono">{fmtDate(e.date)}</td><td><span className="badge badge-blue">{e.journal}</span></td><td style={{fontWeight:500,color:"var(--g7)"}}>{e.libelle}</td><td className="mono" style={{color:"var(--green)"}}>{e.debit?fmt(e.debit,D):"—"}</td><td className="mono" style={{color:"var(--red)"}}>{e.credit?fmt(e.credit,D):"—"}</td></tr>)}</tbody></table></div>}
    {tab===2&&<div className="panel"><div className="panel-hdr"><div className="panel-title"><div className="panel-title-dot"></div>État de Rapprochement au {new Date().toLocaleDateString("fr-FR")}</div><span className={`badge badge-${Math.abs(écart)<1?"green":"red"}`}>{Math.abs(écart)<1?"Équilibré":"Écart détecté"}</span></div><div className="panel-body"><div className="grid-2" style={{gap:20}}><div><div style={{fontSize:10,fontWeight:700,color:"var(--navy2)",textTransform:"uppercase",letterSpacing:"1.5px",borderBottom:"2px solid var(--navy4)",paddingBottom:5,marginBottom:10}}>D'après le relevé bancaire</div>{[["Solde relevé",soldeBancaire,true],["Virements en transit",0],["Chèques en circulation",0]].map(([l,v,bold],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid var(--g1)",fontSize:12}}><span style={{color:bold?"var(--g7)":"var(--g5)",fontWeight:bold?600:400}}>{l}</span><span className="mono" style={{color:bold?"var(--navy2)":"var(--g5)",fontWeight:bold?700:400}}>{fmt(v,D)}</span></div>)}<div style={{display:"flex",justifyContent:"space-between",padding:"8px 0 0",fontWeight:800,fontSize:13,borderTop:"2px solid var(--navy)"}}><span>Solde ajusté</span><span className="mono">{fmt(soldeBancaire,D)}</span></div></div><div><div style={{fontSize:10,fontWeight:700,color:"var(--navy2)",textTransform:"uppercase",letterSpacing:"1.5px",borderBottom:"2px solid var(--navy4)",paddingBottom:5,marginBottom:10}}>D'après la comptabilité</div>{[["Solde comptable 521xxx",soldeComptable,true],["Erreurs à régulariser",0],["Charges bancaires",0]].map(([l,v,bold],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:"1px solid var(--g1)",fontSize:12}}><span style={{color:bold?"var(--g7)":"var(--g5)",fontWeight:bold?600:400}}>{l}</span><span className="mono" style={{color:bold?"var(--navy2)":"var(--g5)",fontWeight:bold?700:400}}>{fmt(v,D)}</span></div>)}<div style={{display:"flex",justifyContent:"space-between",padding:"8px 0 0",fontWeight:800,fontSize:13,borderTop:"2px solid var(--navy)"}}><span>Solde ajusté</span><span className="mono">{fmt(soldeComptable,D)}</span></div></div></div><div style={{marginTop:14,padding:"12px 14px",background:Math.abs(écart)<1?"var(--green-bg)":"var(--red-bg)",border:"1px solid",borderColor:Math.abs(écart)<1?"var(--green-bd)":"var(--red-bd)",borderRadius:"var(--r3)",display:"flex",justifyContent:"space-between",alignItems:"center",fontSize:12}}><span style={{fontWeight:600,color:Math.abs(écart)<1?"var(--green)":"var(--red)"}}>{Math.abs(écart)<1?"✅ Rapprochement équilibré — Soldes concordants":"⚠️ Écart : "+fmt(Math.abs(écart),D)+" à régulariser"}</span><button className="btn btn-outline btn-sm" onClick={()=>window.print()}>🖨 Imprimer</button></div></div></div>}
    {modal==="releve"&&<Modal title="Ajouter ligne de relevé" icon="🏦" onClose={()=>setModal(null)} width={480}><div className="form-grid"><div className="form-group"><label>Date</label><input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div><div className="form-group"><label>Type</label><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option value="credit">Crédit (entrée)</option><option value="debit">Débit (sortie)</option></select></div><div className="form-group full"><label>Libellé</label><input value={form.libelle} onChange={e=>setForm({...form,libelle:e.target.value})}/></div><div className="form-group"><label>Montant ({D})</label><input type="number" value={form.montant} onChange={e=>setForm({...form,montant:+e.target.value})}/></div><div className="form-group"><label>Référence</label><input value={form.ref} onChange={e=>setForm({...form,ref:e.target.value})}/></div></div><div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(null)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={()=>{if(!form.date||!form.libelle)return;const montant=form.type==="debit"?-Math.abs(form.montant):Math.abs(form.montant);dispatch({type:"ADD_RELEVE",payload:{...form,id:genId(),montant,rapproché:false}});setModal(null);}}>Ajouter</button></div></Modal>}
  </div>;
}

// ─── TVA ──────────────────────────────────────────────────────────────────────
const PERIODES_LABELS=["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"];
function TVAModule({state,dispatch}){
  const {factures=[],achats=[],declarationsTVA=[],config}=state;
  const D=config.devise;const tT=config.tauxTVA||18;
  const [tab,setTab]=useState(0);const [modal,setModal]=useState(null);const [periode,setPeriode]=useState(new Date().toISOString().slice(0,7));
  const annee=new Date(config.exercice.debut).getFullYear();
  const calcTVA=(p)=>({tvaCollectee:Math.round(factures.filter(f=>f.date&&f.date.slice(0,7)===p).reduce((s,f)=>s+calcLignes(f.lignes,tT).tva,0)),tvaDeductible:Math.round(achats.filter(a=>a.date&&a.date.slice(0,7)===p).reduce((s,a)=>s+calcLignes(a.lignes,tT).tva,0))});
  const moisAnnee=Array.from({length:12},(_,i)=>{const m=String(i+1).padStart(2,"0");const p=`${annee}-${m}`;const {tvaCollectee,tvaDeductible}=calcTVA(p);const decl=declarationsTVA.find(d=>d.periode===p);return{periode:p,mois:PERIODES_LABELS[i],tvaCollectee,tvaDeductible,tvaNette:tvaCollectee-tvaDeductible,decl};});
  const totalC=moisAnnee.reduce((s,m)=>s+m.tvaCollectee,0);const totalD=moisAnnee.reduce((s,m)=>s+m.tvaDeductible,0);const totalN=totalC-totalD;
  const genDecl=()=>{if(declarationsTVA.find(d=>d.periode===periode)){alert("Déclaration déjà existante.");return;}const calc=calcTVA(periode);dispatch({type:"ADD_DECLARATION_TVA",payload:{id:genId(),periode,...calc,tvaNette:calc.tvaCollectee-calc.tvaDeductible,statut:"brouillon",dateDepot:null,ref:"TVA-"+periode}});setModal(null);};
  return <div>
    <div className="section-header"><div><div className="section-title">Gestion de la TVA</div><div className="section-sub">Taux {tT}% · Exercice {annee}</div></div><div className="flex gap-8"><button className="btn btn-primary btn-sm" onClick={()=>{setPeriode(new Date().toISOString().slice(0,7));setModal("gen");}}>+ Déclaration TVA</button></div></div>
    <div className="kpi-grid" style={{gridTemplateColumns:"repeat(4,1fr)",marginBottom:14}}>
      {[{cl:"blue",bg:"#dbeafe",icon:"📥",lbl:"TVA Collectée (annuel)",val:fmt(totalC,D)},{cl:"blue",bg:"#dbeafe",icon:"📤",lbl:"TVA Déductible (annuel)",val:fmt(totalD,D)},{cl:totalN>=0?"orange":"green",bg:totalN>=0?"#fef3c7":"#d1fae5",icon:"💰",lbl:totalN>=0?"À payer":"Crédit TVA",val:fmt(Math.abs(totalN),D)},{cl:"blue",bg:"#dbeafe",icon:"📋",lbl:"Déclarations",val:declarationsTVA.length.toString()}].map((s,i)=><div key={i} className={`kpi-card ${s.cl}`}><div className="kpi-icon" style={{background:s.bg,marginBottom:8}}>{s.icon}</div><div className="kpi-lbl">{s.lbl}</div><div className="kpi-val" style={{fontSize:"1rem"}}>{s.val}</div></div>)}
    </div>
    <div className="tabs">{["Tableau Annuel","Déclarations"].map((t,i)=><button key={i} className={`tab${tab===i?" active":""}`} onClick={()=>setTab(i)}>{t}</button>)}</div>
    {tab===0&&<div className="table-wrap"><table><thead><tr><th>Mois</th><th>TVA Collectée</th><th>TVA Déductible</th><th>TVA Nette</th><th>Statut</th><th></th></tr></thead><tbody>{moisAnnee.filter(m=>m.tvaCollectee>0||m.tvaDeductible>0||m.decl).map(m=><tr key={m.periode}><td style={{fontWeight:600,color:"var(--g7)"}}>{m.mois} {annee}</td><td className="mono" style={{color:"var(--navy4)"}}>{fmt(m.tvaCollectee,D)}</td><td className="mono" style={{color:"var(--blue)"}}>{fmt(m.tvaDeductible,D)}</td><td className="mono" style={{color:m.tvaNette>=0?"var(--orange)":"var(--green)",fontWeight:700}}>{m.tvaNette>=0?"À payer: ":"Crédit: "}{fmt(Math.abs(m.tvaNette),D)}</td><td>{m.decl?<span className={`badge badge-${m.decl.statut==="déposée"?"green":m.decl.statut==="comptabilisée"?"blue":"orange"}`}>{m.decl.statut}</span>:<span className="badge badge-gray">—</span>}</td><td>{!m.decl&&<button className="btn btn-outline btn-xs" onClick={()=>{setPeriode(m.periode);setModal("gen");}}>Créer</button>}</td></tr>)}</tbody><tfoot><tr><td style={{padding:"8px 10px",fontWeight:700,fontSize:10,color:"var(--g5)",textTransform:"uppercase",letterSpacing:"1.5px"}}>TOTAUX ANNUELS</td><td className="mono" style={{padding:"8px 10px",color:"var(--navy4)"}}>{fmt(totalC,D)}</td><td className="mono" style={{padding:"8px 10px",color:"var(--blue)"}}>{fmt(totalD,D)}</td><td className="mono" style={{padding:"8px 10px",color:totalN>=0?"var(--orange)":"var(--green)",fontWeight:700}}>{fmt(Math.abs(totalN),D)}</td><td colSpan={2}/></tr></tfoot></table></div>}
    {tab===1&&<div className="table-wrap"><table><thead><tr><th>Référence</th><th>Période</th><th>TVA Collectée</th><th>TVA Déductible</th><th>TVA Nette</th><th>Statut</th><th>Date Dépôt</th><th></th></tr></thead><tbody>{declarationsTVA.length===0&&<tr><td colSpan={8}><div className="empty"><div className="empty-icon">📋</div><div className="empty-text">Aucune déclaration</div></div></td></tr>}{[...declarationsTVA].reverse().map(d=>{const [y,m]=d.periode.split("-");return <tr key={d.id}><td className="mono" style={{color:"var(--orange)"}}>{d.ref}</td><td style={{fontWeight:600}}>{PERIODES_LABELS[+m-1]} {y}</td><td className="mono" style={{color:"var(--navy4)"}}>{fmt(d.tvaCollectee,D)}</td><td className="mono" style={{color:"var(--blue)"}}>{fmt(d.tvaDeductible,D)}</td><td className="mono" style={{color:d.tvaNette>=0?"var(--orange)":"var(--green)",fontWeight:700}}>{d.tvaNette>=0?"À payer":"Crédit"}: {fmt(Math.abs(d.tvaNette),D)}</td><td><span className={`badge badge-${d.statut==="déposée"?"green":d.statut==="comptabilisée"?"blue":"orange"}`}>{d.statut}</span></td><td className="mono">{d.dateDepot?fmtDate(d.dateDepot):"—"}</td><td><button className="btn btn-danger btn-xs" onClick={()=>dispatch({type:"DEL_DECLARATION_TVA",payload:d.id})}>✕</button></td></tr>;})}</tbody></table></div>}
    {modal==="gen"&&<Modal title="Générer déclaration TVA" icon="🧮" onClose={()=>setModal(null)} width={460}><div className="form-group" style={{marginBottom:14}}><label>Période</label><input type="month" value={periode} onChange={e=>setPeriode(e.target.value)}/></div>{(()=>{const calc=calcTVA(periode);const[y,m]=periode.split("-");return <div style={{background:"var(--panel)",border:"1px solid var(--g2)",borderRadius:"var(--r3)",padding:"12px 14px",marginBottom:14}}><div style={{fontWeight:700,fontSize:12,color:"var(--navy2)",marginBottom:8}}>{PERIODES_LABELS[+m-1]} {y}</div>{[["TVA collectée",calc.tvaCollectee,"var(--navy4)"],["TVA déductible",calc.tvaDeductible,"var(--blue)"],[(calc.tvaCollectee-calc.tvaDeductible)>=0?"Nette à payer":"Crédit TVA",Math.abs(calc.tvaCollectee-calc.tvaDeductible),(calc.tvaCollectee-calc.tvaDeductible)>=0?"var(--orange)":"var(--green)"]].map(([l,v,c],i)=><div key={i} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:i===2?"none":"1px solid var(--g2)",fontWeight:i===2?800:400,fontSize:i===2?13:12}}><span style={{color:"var(--g6)"}}>{l}</span><span className="mono" style={{color:c,fontWeight:i===2?800:600}}>{fmt(v,D)}</span></div>)}</div>;})()} <div className="modal-footer"><button className="btn btn-outline btn-sm" onClick={()=>setModal(null)}>Annuler</button><button className="btn btn-primary btn-sm" onClick={genDecl}>Générer</button></div></Modal>}
  </div>;
}

// ─── PERSISTENCE ─────────────────────────────────────────────────────────────
const STORAGE_KEY="africompta_v4";const STORAGE_VERSION=4;
function loadState(){try{const raw=localStorage.getItem(STORAGE_KEY);if(!raw)return initialState;const p=JSON.parse(raw);if(p._version!==STORAGE_VERSION)return initialState;delete p._version;return{...initialState,...p};}catch{return initialState;}}
function saveState(s){try{localStorage.setItem(STORAGE_KEY,JSON.stringify({...s,_version:STORAGE_VERSION}));}catch(e){console.warn("Save error",e);}}

// ─── MENUS ────────────────────────────────────────────────────────────────────
// ─── MENU BAR COMPONENT ──────────────────────────────────────────────────────
function MenuBar({setPage, handleExport, handleImport, handleReset, config, dispatch}){
  const [open, setOpen] = useState(null);
  const ref = useRef(null);

  useEffect(()=>{
    const handler = e => { if(ref.current && !ref.current.contains(e.target)) setOpen(null); };
    document.addEventListener("mousedown", handler);
    return ()=>document.removeEventListener("mousedown", handler);
  },[]);

  const go = (page) => { setPage(page); setOpen(null); };

  const MENUS_DEF = {
    "Fichier": [
      {icon:"🏠", label:"Bureau Virtuel", action:()=>go("dashboard"), shortcut:"Ctrl+H"},
      {sep:true},
      {icon:"↓", label:"Exporter les données (.json)", action:()=>{handleExport();setOpen(null);}},
      {icon:"↑", label:"Importer des données (.json)", action:()=>{handleImport();setOpen(null);}},
      {sep:true},
      {icon:"⚙", label:"Paramètres du dossier", action:()=>go("config")},
      {sep:true},
      {icon:"🖨", label:"Imprimer la page active", action:()=>{window.print();setOpen(null);}},
      {sep:true},
      {icon:"⟳", label:"Réinitialiser le dossier", action:()=>{handleReset();setOpen(null);}, danger:true},
    ],
    "Édition": [
      {icon:"🔍", label:"Rechercher un compte…", action:()=>go("planComptable")},
      {sep:true},
      {icon:"📊", label:"Plan comptable OHADA", action:()=>{dispatch({type:"SET_PLAN",payload:"OHADA"});setOpen(null);}},
      {icon:"📊", label:"Plan comptable PCG (France)", action:()=>{dispatch({type:"SET_PLAN",payload:"PCG"});setOpen(null);}},
      {sep:true},
      {icon:"💱", label:"Devise : FCFA", action:()=>{dispatch({type:"SET_CONFIG",payload:{devise:"FCFA"}});setOpen(null);}},
      {icon:"💱", label:"Devise : EUR", action:()=>{dispatch({type:"SET_CONFIG",payload:{devise:"EUR"}});setOpen(null);}},
      {icon:"💱", label:"Devise : USD", action:()=>{dispatch({type:"SET_CONFIG",payload:{devise:"USD"}});setOpen(null);}},
    ],
    "Affichage": [
      {icon:"🏠", label:"Tableau de bord", action:()=>go("dashboard"), shortcut:"F1"},
      {sep:true},
      {icon:"📦", label:"Stocks & Inventaire", action:()=>go("stock")},
      {icon:"🛠", label:"Catalogue Services", action:()=>go("services")},
      {icon:"👥", label:"Clients / Tiers", action:()=>go("clients")},
      {sep:true},
      {icon:"🧾", label:"Facturation", action:()=>go("factures")},
      {icon:"🛒", label:"Achats / Fournisseurs", action:()=>go("achats")},
    ],
    "Comptabilité": [
      {icon:"📒", label:"Saisie des écritures", action:()=>go("comptabilite"), shortcut:"F5"},
      {icon:"📚", label:"Plan de comptes", action:()=>go("planComptable"), shortcut:"F6"},
      {sep:true},
      {icon:"📋", label:"Journal centralisateur", action:()=>go("comptabilite")},
      {icon:"📖", label:"Grand livre", action:()=>go("comptabilite")},
      {icon:"⚖️", label:"Balance générale", action:()=>go("comptabilite")},
      {sep:true},
      {icon:"🔗", label:"Rapprochement bancaire", action:()=>go("rapprochement")},
    ],
    "Gestion": [
      {icon:"📊", label:"Liasse fiscale OHADA", action:()=>go("rapports"), shortcut:"F8"},
      {icon:"🧮", label:"Gestion de la TVA", action:()=>go("tva"), shortcut:"F9"},
      {sep:true},
      {icon:"🧾", label:"Nouvelle facture", action:()=>go("factures")},
      {icon:"🛒", label:"Nouvelle commande achat", action:()=>go("achats")},
      {sep:true},
      {icon:"📦", label:"Stocks & alertes", action:()=>go("stock")},
      {icon:"🛠", label:"Catalogue services", action:()=>go("services")},
    ],
    "Paie": [
      {icon:"💵", label:"Tableau de bord paie", action:()=>go("paie"), shortcut:"F10"},
      {sep:true},
      {icon:"👷", label:"Fiche employé", action:()=>go("paie")},
      {icon:"📋", label:"Générer un bulletin", action:()=>go("paie")},
      {sep:true},
      {icon:"⚙", label:"Paramètres CNPS / ITS", action:()=>go("paie")},
    ],
    "Outils": [
      {icon:"⚙", label:"Paramètres du dossier", action:()=>go("config")},
      {sep:true},
      {icon:"↓", label:"Exporter les données", action:()=>{handleExport();setOpen(null);}},
      {icon:"↑", label:"Importer des données", action:()=>{handleImport();setOpen(null);}},
      {sep:true},
      {icon:"🖨", label:"Imprimer", action:()=>{window.print();setOpen(null);}, shortcut:"Ctrl+P"},
    ],
    "Aide": [
      {icon:"📘", label:"À propos d'Africompta", action:()=>{alert("Africompta v4.0\nLogiciel de comptabilité OHADA/PCG\nInspired by Memsoft Oxygène");setOpen(null);}},
      {sep:true},
      {icon:"🌐", label:"Documentation OHADA", action:()=>{window.open("https://www.ohada.com","_blank");setOpen(null);}},
      {icon:"📺", label:"Tutoriels Memsoft Oxygène", action:()=>{window.open("https://www.youtube.com/channel/UCEwkL7_F9fob_wOIRBuRL6Q","_blank");setOpen(null);}},
      {sep:true},
      {icon:"ℹ️", label:"Version 4.0 — Plan OHADA/PCG", disabled:true},
    ],
  };

  return (
    <div className="menu-bar" ref={ref}>
      {Object.entries(MENUS_DEF).map(([label, items])=>(
        <div key={label} className={`menu-item${open===label?" open":""}`} onClick={()=>setOpen(open===label?null:label)}>
          {label}
          {open===label&&(
            <div className="menu-dropdown" onClick={e=>e.stopPropagation()}>
              {items.map((item,i)=>
                item.sep
                  ? <div key={i} className="md-sep"/>
                  : <div key={i} className={`md-item${item.disabled?" disabled":""}`}
                      style={item.danger?{color:"var(--red2)"}:{}}
                      onClick={item.disabled?undefined:item.action}>
                      <span className="md-icon">{item.icon}</span>
                      <span>{item.label}</span>
                      {item.shortcut&&<span className="md-shortcut">{item.shortcut}</span>}
                    </div>
              )}
            </div>
          )}
        </div>
      ))}
      <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:8,padding:"0 8px"}}>
        <div style={{fontSize:9,color:"var(--tx4)",fontFamily:"var(--fm)",letterSpacing:"1px"}}>
          {new Date().toLocaleDateString("fr-FR").replace(/\//g,".")}
        </div>
        <div style={{width:1,height:12,background:"var(--b3)"}}/>
        <div style={{fontSize:9,fontWeight:600,padding:"2px 8px",fontFamily:"var(--fm)",letterSpacing:"2px",textTransform:"uppercase",background:"var(--cyan-g)",color:"var(--cyan)",border:"1px solid rgba(0,229,255,.25)",clipPath:"polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)"}}>{config.devise}</div>
        <div style={{fontSize:9,fontWeight:600,padding:"2px 8px",fontFamily:"var(--fm)",letterSpacing:"2px",textTransform:"uppercase",background:"var(--lime-g)",color:"var(--lime)",border:"1px solid rgba(57,255,20,.25)",clipPath:"polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)"}}>{config.planComptable}</div>
      </div>
    </div>
  );
}

  const MENUS=[
  {id:"dashboard",icon:"🏠",label:"Bureau Virtuel",section:"ACCUEIL"},
  {id:"stock",icon:"📦",label:"Stocks & Inventaire",section:"GESTION COMMERCIALE"},
  {id:"services",icon:"🛠",label:"Catalogue Services",section:"GESTION COMMERCIALE"},
  {id:"clients",icon:"👥",label:"Clients / Tiers",section:"GESTION COMMERCIALE"},
  {id:"factures",icon:"🧾",label:"Facturation",section:"GESTION COMMERCIALE"},
  {id:"achats",icon:"🛒",label:"Achats / Fournisseurs",section:"GESTION COMMERCIALE"},
  {id:"comptabilite",icon:"📒",label:"Saisie Comptable",section:"COMPTABILITÉ"},
  {id:"planComptable",icon:"📚",label:"Plan de Comptes",section:"COMPTABILITÉ"},
  {id:"rapports",icon:"📊",label:"Liasse Fiscale",section:"COMPTABILITÉ"},
  {id:"rapprochement",icon:"🔗",label:"Rapprochement Bancaire",section:"COMPTABILITÉ"},
  {id:"tva",icon:"🧮",label:"Gestion TVA",section:"COMPTABILITÉ"},
  {id:"paie",icon:"💵",label:"Paie & RH",section:"PAIE & RH"},
  {id:"config",icon:"⚙",label:"Paramètres Dossier",section:"ADMINISTRATION"},
];

// ─── APP ROOT ─────────────────────────────────────────────────────────────────
export default function App(){
  const [state,dispatch]=useReducer(reducer,null,loadState);
  const [page,setPage]=useState("dashboard");
  const [saveStatus,setSaveStatus]=useState("saved");
  const [lastSaved,setLastSaved]=useState(null);
  const saveTimer=useRef(null);

  useEffect(()=>{setSaveStatus("saving");if(saveTimer.current)clearTimeout(saveTimer.current);saveTimer.current=setTimeout(()=>{try{saveState(state);setSaveStatus("saved");setLastSaved(new Date());}catch{setSaveStatus("error");}},800);return()=>{if(saveTimer.current)clearTimeout(saveTimer.current);};},[state]);

  const handleExport=useCallback(()=>{const blob=new Blob([JSON.stringify({...state,_version:STORAGE_VERSION},null,2)],{type:"application/json"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`africompta_${state.config.nomEntreprise.replace(/\s+/g,"_")}_${new Date().toISOString().slice(0,10)}.json`;a.click();URL.revokeObjectURL(url);},[state]);
  const handleImport=useCallback(()=>{const input=document.createElement("input");input.type="file";input.accept=".json";input.onchange=e=>{const file=e.target.files[0];if(!file)return;const reader=new FileReader();reader.onload=ev=>{try{const data=JSON.parse(ev.target.result);if(window.confirm("Importer ? Les données actuelles seront remplacées.")){dispatch({type:"__IMPORT_ALL",payload:data});}}catch{alert("Fichier invalide");}};reader.readAsText(file);};input.click();},[]);
  const handleReset=useCallback(()=>{if(window.confirm("Réinitialiser toutes les données ? Irréversible.")){if(window.confirm("Confirmer la réinitialisation ?")){dispatch({type:"__IMPORT_ALL",payload:initialState});localStorage.removeItem(STORAGE_KEY);}}},[]);

  const sections=[...new Set(MENUS.map(m=>m.section))];
  const currentMenu=MENUS.find(m=>m.id===page);

  const PAGES={
    dashboard:<Dashboard state={state}/>,
    stock:<StockModule state={state} dispatch={dispatch}/>,
    services:<ServicesModule state={state} dispatch={dispatch}/>,
    clients:<ClientsModule state={state} dispatch={dispatch}/>,
    factures:<FacturesModule state={state} dispatch={dispatch}/>,
    achats:<AchatsModule state={state} dispatch={dispatch}/>,
    comptabilite:<ComptabiliteModule state={state} dispatch={dispatch}/>,
    planComptable:<PlanComptableModule state={state} dispatch={dispatch}/>,
    rapports:<RapportsModule state={state}/>,
    rapprochement:<RapprochementModule state={state} dispatch={dispatch}/>,
    tva:<TVAModule state={state} dispatch={dispatch}/>,
    paie:<PaieModule state={state} dispatch={dispatch}/>,
    config:<ConfigModule state={state} dispatch={dispatch}/>,
  };

  const artAlertes=state.articles.filter(a=>a.stock<=a.stockMin).length;
  const factEnAttente=state.factures.filter(f=>f.statut==="en attente").length;
  const annee=new Date(state.config.exercice.debut).getFullYear();

  return <>
    <style>{styles}</style>
    <div className="app">

      {/* ── BARRE TITRE ── */}
      <div className="title-bar">
        <div className="title-bar-logo">A</div>
        <div className="title-bar-text">Africompta — {state.config.nomEntreprise}</div>
        <div className="title-bar-sep"/>
        <div className="title-bar-info">{state.config.planComptable} · {state.config.devise} · Exercice {annee}</div>
        <div className="title-bar-btns">
          <div className="title-bar-btn" style={{background:"#ffcc00"}}></div>
          <div className="title-bar-btn" style={{background:"#27c93f"}}></div>
          <div className="title-bar-btn" style={{background:"#ff5f57"}}></div>
        </div>
      </div>

      {/* ── MENU BAR ── */}
      <MenuBar
        setPage={setPage}
        handleExport={handleExport}
        handleImport={handleImport}
        handleReset={handleReset}
        config={state.config}
        dispatch={dispatch}
      />

      {/* ── RIBBON ── */}
      <div className="ribbon">
        {[
          {icon:"🏠",txt:"Accueil",action:()=>setPage("dashboard")},
          {sep:true},
          {icon:"🧾",txt:"Facture",action:()=>setPage("factures")},
          {icon:"🛒",txt:"Achat",action:()=>setPage("achats")},
          {icon:"📦",txt:"Stock",action:()=>setPage("stock")},
          {sep:true},
          {icon:"📒",txt:"Écriture",action:()=>setPage("comptabilite")},
          {icon:"📊",txt:"Liasse",action:()=>setPage("rapports")},
          {icon:"🔗",txt:"Rapproch.",action:()=>setPage("rapprochement")},
          {icon:"🧮",txt:"TVA",action:()=>setPage("tva")},
          {sep:true},
          {icon:"💵",txt:"Paie",action:()=>setPage("paie")},
          {sep:true},
          {icon:"↓",txt:"Exporter",action:handleExport},
          {icon:"↑",txt:"Importer",action:handleImport},
          {icon:"⟳",txt:"Reset",action:handleReset,danger:true},
        ].map((b,i)=>b.sep?<div key={i} className="ribbon-sep"/>:<button key={i} className={`rbtn${b.id===page?" primary":""}`} style={b.danger?{color:"var(--red)"}:{}} onClick={b.action}><span className="rbtn-icon">{b.icon}</span><span className="rbtn-txt">{b.txt}</span></button>)}
        <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:8}}>
          {artAlertes>0&&<span className="badge badge-red" style={{fontSize:10}}>📦 {artAlertes} alerte(s)</span>}
          {factEnAttente>0&&<span className="badge badge-amber" style={{fontSize:10}}>⏳ {factEnAttente} en attente</span>}
        </div>
      </div>

      {/* ── BODY ── */}
      <div className="body">
        {/* NAVPANEL */}
        <nav className="navpanel">
          <div className="navpanel-header">
            <div className="navpanel-logo">A</div>
            <div><div className="navpanel-name">Afri<em>compta</em></div><div className="navpanel-sub">{state.config.planComptable} · {state.config.devise}</div></div>
          </div>
          {sections.map(sec=><div key={sec}>
            <div className="nav-section">{sec}</div>
            {MENUS.filter(m=>m.section===sec).map(m=><div key={m.id} className={`nav-item${page===m.id?" active":""}`} onClick={()=>setPage(m.id)}>
              <span className="nav-icon">{m.icon}</span>
              <span>{m.label}</span>
              {m.id==="factures"&&factEnAttente>0&&<span className="nav-badge warn">{factEnAttente}</span>}
              {m.id==="stock"&&artAlertes>0&&<span className="nav-badge warn">{artAlertes}</span>}
            </div>)}
          </div>)}
          <div className="navpanel-bottom">
            <div className="status-pill">
              <span className={`status-dot ${saveStatus==="saving"?"busy":"ok"}`}/>
              <span className="status-text">{saveStatus==="saving"?"Sauvegarde...":lastSaved?`Sauvé à ${lastSaved.toLocaleTimeString("fr-FR",{hour:"2-digit",minute:"2-digit"})}`:"Prêt"}</span>
            </div>
            <div className="nav-actions">
              <button className="nav-act" onClick={handleExport} title="Exporter">↓ Exp</button>
              <button className="nav-act" onClick={handleImport} title="Importer">↑ Imp</button>
              <button className="nav-act" onClick={handleReset} title="Réinitialiser" style={{color:"var(--red-bd)"}}>⟳ Rst</button>
            </div>
            <div className="nav-company">{state.config.nomEntreprise}</div>
          </div>
        </nav>

        {/* WORKSPACE */}
        <div className="workspace">
          {/* ADDRESSBAR */}
          <div className="addressbar">
            <span className="addr-module">{currentMenu?.section}</span>
            <span className="addr-sep">›</span>
            <span className="addr-page">{currentMenu?.label}</span>
            <div className="addr-right">
              <div className="addr-tag blue">{state.config.planComptable}</div>
              <div className="addr-tag green">{state.config.devise}</div>
              <div className="addr-date">{state.config.nomEntreprise} · Ex. {annee}</div>
            </div>
          </div>

          {/* CONTENT */}
          <div className="content">{PAGES[page]||<div className="empty"><div className="empty-icon">🚧</div><div className="empty-text">Page en construction</div></div>}</div>

          {/* STATUS BAR */}
          <div className="statusbar">
            <div className="sb-item">Africompta <span>v4.0</span></div>
            <div className="sb-sep"/>
            <div className="sb-item">Module: <span>{currentMenu?.label}</span></div>
            <div className="sb-sep"/>
            <div className="sb-item">Exercice: <span>{annee}</span></div>
            <div className="sb-sep"/>
            <div className="sb-item">Plan: <span>{state.config.planComptable}</span></div>
            <div className="sb-sep"/>
            <div className="sb-item">Articles: <span>{state.articles.length}</span></div>
            <div className="sb-sep"/>
            <div className="sb-item">Factures: <span>{state.factures.length}</span></div>
            <div className="sb-right">
              <div className="sb-item sb-ok">● {saveStatus==="saving"?"Sauvegarde...":"Données sauvegardées"}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>;
}
