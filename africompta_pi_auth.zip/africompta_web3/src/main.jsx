import { createRoot } from 'react-dom/client';
import AppWeb3 from './AppWeb3_v2.jsx';

createRoot(document.getElementById('root')).render(<AppWeb3 />);
