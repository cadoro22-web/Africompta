import { useState, useCallback } from 'react';
import { connectPi, isPiAvailable }    from '../lib/pi.js';
import { supabase }                    from '../lib/supabase.js';

const VALIDATE_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/pi-auth-validate`;
const ANON_KEY     =  import.meta.env.VITE_SUPABASE_ANON_KEY;

/**
 * usePiAuth — Pi Network authentication hook
 *
 * Flow:
 *  1. connectPi() → PiSdkBase.connect() → awaits Pi.init then Pi.authenticate
 *  2. Send accessToken to /pi-auth-validate Edge Function
 *  3. Edge Function calls GET https://api.minepi.com/v2/me (no API key needed)
 *  4. On valid UID: upsert Supabase user, sign in with derived credentials
 */
export default function usePiAuth() {
  const [piUser,  setPiUser]  = useState(null);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');

  const login = useCallback(async () => {
    setLoading(true);
    setError('');

    try {
      // Step 1 — Pi.init (awaited) + Pi.authenticate via pi-sdk-js
      const { user: piU, accessToken } = await connectPi();

      // Step 2 — Backend validates token by calling /v2/me (no API key)
      const valRes = await fetch(VALIDATE_URL, {
        method:  'POST',
        headers: { 'Content-Type':'application/json', 'Authorization':`Bearer ${ANON_KEY}` },
        body:    JSON.stringify({ accessToken }),
      });
      if (!valRes.ok) {
        const err = await valRes.json().catch(() => ({}));
        throw new Error(err.error || 'Pi token validation failed');
      }
      const { uid, username } = await valRes.json();

      // Step 3 — Establish Supabase session using deterministic credentials
      const email    = `${uid}@pi.africompta.app`;
      const password = `pi_${uid}_${username}`;

      let { data, error: signInErr } = await supabase.auth.signInWithPassword({ email, password });

      if (signInErr?.message?.includes('Invalid login credentials')) {
        const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
          email, password,
          options: { data: { display_name: username, pi_username: username, pi_uid: uid } },
        });
        if (signUpErr) throw signUpErr;
        data = signUpData;
      } else if (signInErr) {
        throw signInErr;
      }

      // Step 4 — Keep pi_username in sync
      if (data?.user) {
        await supabase.from('users')
          .update({ pi_username: username, display_name: username })
          .eq('auth_id', data.user.id);
      }

      setPiUser({ uid, username, accessToken });
      return { user: data?.user, piUser: { uid, username } };

    } catch (err) {
      const msg = err.message || 'Erreur d\'authentification Pi';
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    piUser,
    loading,
    error,
    login,
    isPiAvailable: isPiAvailable(),
  };
}
