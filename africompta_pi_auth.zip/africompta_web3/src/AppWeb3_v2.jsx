import { useState, useEffect, useCallback } from 'react';
import { auth, userApi }                     from './lib/supabase.js';
import { connectPi, isPiAvailable }          from './lib/pi.js';
import { companiesApi, subscriptionsApi, loadCompanyState } from './lib/api.js';
import AuthScreen        from './components/AuthScreen.jsx';
import CompanySelector   from './components/CompanySelector.jsx';
import SubscriptionModal from './components/SubscriptionModal.jsx';
import AppAccounting     from './App.jsx';

const STAGE = { LOADING:'loading', AUTH:'auth', COMPANY:'company', APP:'app' };

export default function AppWeb3() {
  const [stage,        setStage]       = useState(STAGE.LOADING);
  const [authUser,     setAuthUser]    = useState(null);
  const [profile,      setProfile]     = useState(null);
  const [subscription, setSub]         = useState(null);
  const [companies,    setCompanies]   = useState([]);
  const [company,      setCompany]     = useState(null);
  const [appState,     setAppState]    = useState(null);
  const [loadingMsg,   setLoadingMsg]  = useState('Initialisation…');
  const [showSub,      setShowSub]     = useState(false);

  // ── Bootstrap: check existing Supabase session first ─────────
  // If Pi Browser is detected, auto-trigger Pi auth via AuthScreen's useEffect.
  useEffect(() => {
    (async () => {
      const session = await auth.getSession();
      if (session?.user) {
        await loadUserData(session.user);
      } else {
        setStage(STAGE.AUTH);
      }
    })();

    const sub = auth.onAuthChange(async (event, session) => {
      if (event === 'SIGNED_IN'  && session?.user) await loadUserData(session.user);
      if (event === 'SIGNED_OUT')                   resetState();
    });
    return () => sub.unsubscribe();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadUserData = async (user) => {
    setStage(STAGE.LOADING);
    setLoadingMsg('Chargement du profil…');
    setAuthUser(user);
    try {
      const { data: prof } = await userApi.getProfile();
      setProfile(prof);

      setLoadingMsg('Vérification abonnement…');
      const { data: sub } = await subscriptionsApi.getActive();
      setSub(sub);

      setLoadingMsg('Chargement des entreprises…');
      const { data: cos } = await companiesApi.list();
      setCompanies(cos || []);

      if (cos?.length === 1) await openCompany(cos[0]);
      else                   setStage(STAGE.COMPANY);
    } catch {
      setStage(STAGE.AUTH);
    }
  };

  const openCompany = useCallback(async (co) => {
    setStage(STAGE.LOADING);
    setLoadingMsg(`Ouverture de ${co.nomEntreprise}…`);
    try {
      setCompany(co);
      setAppState(await loadCompanyState(co.id));
      setStage(STAGE.APP);
    } catch { setStage(STAGE.COMPANY); }
  }, []);

  const handleLogout       = useCallback(async () => { await auth.signOut(); resetState(); }, []);
  const handleSwitchCo     = useCallback(async () => {
    const { data: cos } = await companiesApi.list();
    setCompanies(cos || []);
    setStage(STAGE.COMPANY);
    setCompany(null);
    setAppState(null);
  }, []);
  const handleSubscribed   = useCallback(async () => {
    setShowSub(false);
    const { data: sub } = await subscriptionsApi.getActive();
    setSub(sub);
  }, []);

  const resetState = () => {
    setAuthUser(null); setProfile(null); setSub(null);
    setCompanies([]); setCompany(null); setAppState(null);
    setStage(STAGE.AUTH);
  };

  // ── Loading screen ────────────────────────────────────────────
  if (stage === STAGE.LOADING) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',background:'#020810',gap:16,position:'relative',zIndex:1}}>
      <div style={{position:'fixed',inset:0,backgroundImage:'linear-gradient(#0e2040 1px,transparent 1px),linear-gradient(90deg,#0e2040 1px,transparent 1px)',backgroundSize:'40px 40px',opacity:.25,zIndex:0}}/>
      <div style={{width:52,height:52,background:'rgba(0,229,255,.1)',border:'1px solid #00b8d4',clipPath:'polygon(8px 0%,100% 0%,100% calc(100% - 8px),calc(100% - 8px) 100%,0% 100%,0% 8px)',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'Rajdhani,sans-serif',fontWeight:700,fontSize:20,color:'#00e5ff',animation:'glow 2s ease-in-out infinite',position:'relative',zIndex:1}}>NX</div>
      <div style={{fontFamily:'Share Tech Mono,monospace',fontSize:11,color:'#2e6a7e',letterSpacing:'2px',textTransform:'uppercase',position:'relative',zIndex:1}}>{loadingMsg}</div>
      <style>{`@keyframes glow{0%,100%{box-shadow:0 0 20px rgba(0,229,255,.3)}50%{box-shadow:0 0 40px rgba(0,229,255,.6)}}`}</style>
    </div>
  );

  const SubModal = showSub && (
    <SubscriptionModal user={profile} subscription={subscription} companyId={company?.id}
      onClose={()=>setShowSub(false)} onSubscribed={handleSubscribed}/>
  );

  if (stage === STAGE.AUTH)    return <><AuthScreen onAuth={loadUserData}/>{SubModal}</>;
  if (stage === STAGE.COMPANY) return <><CompanySelector companies={companies} subscription={subscription} user={profile} onSelect={openCompany} onCreated={async co=>{ const{data:cos}=await companiesApi.list(); setCompanies(cos||[]); await openCompany(co); }} onSubscribe={()=>setShowSub(true)}/>{SubModal}</>;
  if (stage === STAGE.APP && appState) return <><AppAccounting initialState={appState} companyId={company.id} user={profile} subscription={subscription} onLogout={handleLogout} onSwitchCompany={handleSwitchCo} onSubscribe={()=>setShowSub(true)}/>{SubModal}</>;
  return null;
}
