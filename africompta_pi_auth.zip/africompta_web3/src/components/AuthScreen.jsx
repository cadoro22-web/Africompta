import { useState, useEffect } from 'react';
import { auth }       from '../lib/supabase.js';
import usePiAuth      from '../hooks/usePiAuth.js';

/**
 * AuthScreen
 *
 * - Auto-triggers Pi authentication on mount (if Pi Browser detected)
 * - Shows manual Pi sign-in button for retry
 * - Falls back to email/password or magic link
 */
export default function AuthScreen({ onAuth }) {
  const { login: piLogin, loading: piLoading, error: piError, isPiAvailable } = usePiAuth();

  const [mode,    setMode]    = useState('login');
  const [email,   setEmail]   = useState('');
  const [pass,    setPass]    = useState('');
  const [name,    setName]    = useState('');
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState('');
  const [sent,    setSent]    = useState(false);

  // ── Auto-trigger Pi auth on mount ──────────────────────────
  useEffect(() => {
    if (!isPiAvailable) return;
    handlePiLogin();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPiAvailable]);

  // ── Pi sign-in handler ─────────────────────────────────────
  const handlePiLogin = async () => {
    setError('');
    try {
      const result = await piLogin();
      if (result?.user) onAuth(result.user);
    } catch (err) {
      setError(err.message || 'Connexion Pi annulée ou impossible');
    }
  };

  // ── Email/password or magic link ───────────────────────────
  const handleEmailAuth = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      if (mode === 'magic') {
        const { error: err } = await auth.signInWithMagicLink(email);
        if (err) throw err;
        setSent(true);
      } else if (mode === 'signup') {
        const { error: err } = await auth.signUp(email, pass, name);
        if (err) throw err;
        setSent(true);
      } else {
        const { data, error: err } = await auth.signIn(email, pass);
        if (err) throw err;
        onAuth(data.user);
      }
    } catch (err) {
      setError(err.message || 'Erreur de connexion');
    } finally {
      setLoading(false);
    }
  };

  // ── Sent confirmation ──────────────────────────────────────
  if (sent) return (
    <div style={WRAP}>
      <div style={CARD}>
        <div style={{fontSize:'2rem',marginBottom:16,textAlign:'center'}}>📧</div>
        <div style={TITLE}>Vérifiez votre email</div>
        <div style={SUB}>Lien envoyé à <strong style={{color:'var(--cyan)'}}>{email}</strong></div>
        <button style={{...BTN_PRI,marginTop:20,width:'100%',justifyContent:'center'}} onClick={()=>setSent(false)}>← Retour</button>
      </div>
    </div>
  );

  return (
    <div style={WRAP}>
      {/* Grid backdrop */}
      <div style={{position:'fixed',inset:0,backgroundImage:'linear-gradient(#0e2040 1px,transparent 1px),linear-gradient(90deg,#0e2040 1px,transparent 1px)',backgroundSize:'40px 40px',opacity:.25,zIndex:0,pointerEvents:'none'}}/>

      <div style={{...CARD,position:'relative',zIndex:1}}>
        {/* Logo */}
        <div style={{textAlign:'center',marginBottom:22}}>
          <div style={{width:48,height:48,margin:'0 auto 12px',background:'rgba(0,229,255,.1)',border:'1px solid #00b8d4',clipPath:'polygon(7px 0%,100% 0%,100% calc(100% - 7px),calc(100% - 7px) 100%,0% 100%,0% 7px)',display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'Rajdhani,sans-serif',fontWeight:700,fontSize:18,color:'#00e5ff',boxShadow:'0 0 18px rgba(0,229,255,.2)'}}>NX</div>
          <div style={{fontFamily:'Rajdhani,sans-serif',fontSize:'1.5rem',fontWeight:700,color:'#cce8f0',letterSpacing:2,textTransform:'uppercase'}}>Afri<span style={{color:'#00e5ff'}}>compta</span></div>
          <div style={{fontSize:9,color:'#2e6a7e',fontFamily:'Share Tech Mono,monospace',letterSpacing:'2.5px',marginTop:3,textTransform:'uppercase'}}>NEXUS · Comptabilité Web3</div>
        </div>

        {/* Pi sign-in — primary CTA */}
        {isPiAvailable && (
          <div style={{marginBottom:18}}>
            <button
              onClick={handlePiLogin}
              disabled={piLoading}
              style={{...BTN_PI, width:'100%', justifyContent:'center', opacity: piLoading ? .65 : 1}}
            >
              <span style={{fontSize:20,lineHeight:1}}>π</span>
              {piLoading ? 'Connexion Pi en cours…' : 'Se connecter avec Pi Network'}
            </button>
            {piError && <div style={ERR}>⚠ {piError}</div>}
          </div>
        )}

        {/* Divider */}
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:18}}>
          <div style={{flex:1,height:1,background:'#1a3060'}}/>
          <span style={{fontSize:10,color:'#2e6a7e',fontFamily:'Share Tech Mono,monospace',letterSpacing:'2px'}}>OU</span>
          <div style={{flex:1,height:1,background:'#1a3060'}}/>
        </div>

        {/* Mode tabs */}
        <div style={{display:'flex',gap:2,background:'rgba(8,20,40,.8)',border:'1px solid #1a3060',padding:3,marginBottom:18,clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))'}}>
          {[['login','Connexion'],['signup','Inscription'],['magic','Magic Link']].map(([m,l])=>(
            <button key={m} onClick={()=>{setMode(m);setError('');}} style={{flex:1,padding:'6px 6px',border:'1px solid transparent',background:mode===m?'rgba(0,229,255,.1)':'transparent',color:mode===m?'#00e5ff':'#2e6a7e',fontFamily:'Share Tech Mono,monospace',fontSize:9,cursor:'pointer',textTransform:'uppercase',letterSpacing:'1.5px',transition:'all .15s',...(mode===m?{borderColor:'rgba(0,229,255,.2)'}:{})}}>
              {l}
            </button>
          ))}
        </div>

        {/* Email form */}
        <form onSubmit={handleEmailAuth}>
          {mode==='signup'&&<div style={FG}><label style={LBL}>Nom complet</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Jean-Baptiste Koffi" required style={INP}/></div>}
          <div style={FG}><label style={LBL}>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="contact@monentreprise.com" required style={INP}/></div>
          {mode!=='magic'&&<div style={{...FG,marginBottom:18}}><label style={LBL}>Mot de passe</label><input type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••" required minLength={6} style={INP}/></div>}
          {error&&<div style={ERR}>⚠ {error}</div>}
          <button type="submit" disabled={loading} style={{...BTN_PRI,width:'100%',justifyContent:'center',opacity:loading?.6:1,marginTop:4}}>
            {loading?'…':mode==='signup'?'Créer le compte':mode==='magic'?'Envoyer le lien':'Se connecter'}
          </button>
        </form>

        {/* Not in Pi Browser notice */}
        {!isPiAvailable&&(
          <div style={{marginTop:16,padding:'10px 13px',background:'rgba(0,229,255,.04)',border:'1px solid rgba(0,229,255,.1)',clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))'}}>
            <div style={{fontSize:9,color:'#00e5ff',fontFamily:'Share Tech Mono,monospace',letterSpacing:'2px',textTransform:'uppercase',marginBottom:4}}>Pi Network</div>
            <div style={{fontSize:11,color:'#2e6a7e',lineHeight:1.6}}>Ouvrez cette app dans <strong style={{color:'#cce8f0'}}>Pi Browser</strong> pour vous connecter avec votre compte Pi et payer en π.</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Styles ─────────────────────────────────────────────────────
const WRAP  = { display:'flex', alignItems:'center', justifyContent:'center', height:'100vh', background:'#020810', position:'relative', zIndex:1, padding:20 };
const CARD  = { background:'rgba(11,26,53,.97)', border:'1px solid #2050a0', padding:'26px 28px', width:'100%', maxWidth:400, clipPath:'polygon(0 0,calc(100% - 18px) 0,100% 18px,100% 100%,18px 100%,0 calc(100% - 18px))', backdropFilter:'blur(24px)', boxShadow:'0 0 50px rgba(0,229,255,.05),0 20px 60px rgba(0,0,0,.8)' };
const TITLE = { fontFamily:'Rajdhani,sans-serif', fontSize:'1.2rem', fontWeight:700, color:'#cce8f0', textAlign:'center', textTransform:'uppercase', letterSpacing:2, marginBottom:6 };
const SUB   = { fontSize:12.5, color:'#5ea8bc', textAlign:'center', lineHeight:1.7 };
const LBL   = { display:'block', fontSize:8.5, fontWeight:600, color:'#2e6a7e', textTransform:'uppercase', letterSpacing:'2px', fontFamily:'Share Tech Mono,monospace', marginBottom:5 };
const INP   = { display:'block', width:'100%', background:'#081428', border:'1px solid #1a3060', padding:'8px 11px', color:'#cce8f0', fontFamily:'Share Tech Mono,monospace', fontSize:12, outline:'none', clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)' };
const FG    = { display:'flex', flexDirection:'column', gap:5, marginBottom:12 };
const ERR   = { background:'rgba(255,23,68,.1)', border:'1px solid rgba(255,23,68,.25)', color:'#ff5252', padding:'7px 11px', fontSize:11.5, fontFamily:'Share Tech Mono,monospace', marginBottom:12, clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)' };
const BTN_PRI = { display:'inline-flex', alignItems:'center', gap:8, padding:'9px 18px', background:'rgba(0,229,255,.08)', border:'1px solid rgba(0,229,255,.3)', color:'#00e5ff', fontFamily:'Rajdhani,sans-serif', fontSize:12, fontWeight:600, cursor:'pointer', textTransform:'uppercase', letterSpacing:'2px', clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)', boxShadow:'0 0 10px rgba(0,229,255,.12)', transition:'all .15s' };
const BTN_PI  = { display:'inline-flex', alignItems:'center', gap:10, padding:'11px 18px', background:'rgba(57,255,20,.08)', border:'1px solid rgba(57,255,20,.35)', color:'#39ff14', fontFamily:'Rajdhani,sans-serif', fontSize:13, fontWeight:700, cursor:'pointer', textTransform:'uppercase', letterSpacing:'2px', clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)', boxShadow:'0 0 14px rgba(57,255,20,.12)', transition:'all .15s' };
