import { useState } from 'react';
import { PI_PLANS, createSubscriptionPayment } from '../lib/pi.js';
import { subscriptionsApi } from '../lib/api.js';

// ═══════════════════════════════════════════════════════════════
//  MODAL D'ABONNEMENT PI NETWORK
// ═══════════════════════════════════════════════════════════════
export default function SubscriptionModal({ user, subscription, companyId, onClose, onSubscribed }) {
  const [step,      setStep]      = useState('plans');  // plans | paying | success | error
  const [selected,  setSelected]  = useState('business');
  const [piStatus,  setPiStatus]  = useState('');
  const [txid,      setTxid]      = useState('');
  const [errMsg,    setErrMsg]    = useState('');

  const currentPlan = subscription?.plan || 'none';

  const startPayment = async () => {
    setStep('paying');
    setPiStatus('Ouverture du wallet Pi...');

    try {
      await createSubscriptionPayment({
        plan:      selected,
        userId:    user?.id,
        companyId,

        onApproved: (paymentId) => {
          setPiStatus('Paiement approuvé — transaction en cours...');
        },

        onCompleted: async (paymentId, tx) => {
          setPiStatus('Transaction confirmée — activation de l\'abonnement...');
          setTxid(tx);

          // Enregistrer l'abonnement en base
          const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
          await subscriptionsApi.create({
            userId:      user?.id,
            plan:        selected,
            status:      'active',
            startsAt:    new Date().toISOString(),
            expiresAt:   expiresAt.toISOString(),
            piPaymentId: paymentId,
            piTxid:      tx,
            amountPi:    PI_PLANS[selected].pi,
          });

          setStep('success');
          setTimeout(() => onSubscribed(selected), 2000);
        },

        onCancelled: () => {
          setErrMsg('Paiement annulé par l\'utilisateur.');
          setStep('error');
        },

        onError: (err) => {
          setErrMsg(err?.message || 'Erreur de paiement Pi');
          setStep('error');
        },
      });
    } catch (err) {
      setErrMsg(err?.message || 'Impossible de lancer le paiement');
      setStep('error');
    }
  };

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(2,8,16,.88)',backdropFilter:'blur(10px)',zIndex:300,display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <div style={{
        background:'rgba(11,26,53,.97)',border:'1px solid var(--b3)',
        padding:'28px 30px',width:'100%',maxWidth:680,maxHeight:'90vh',overflowY:'auto',
        clipPath:'polygon(0 0,calc(100% - 20px) 0,100% 20px,100% 100%,20px 100%,0 calc(100% - 20px))',
        backdropFilter:'blur(24px)',boxShadow:'0 0 60px rgba(57,255,20,.05),0 20px 60px rgba(0,0,0,.8)',
        position:'relative',
      }}>

        {/* Bande décorative */}
        <div style={{position:'absolute',top:0,right:20,left:0,height:2,background:'linear-gradient(90deg,transparent,var(--lime),var(--cyan),transparent)'}}/>

        {/* Header */}
        <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:24,paddingBottom:16,borderBottom:'1px solid var(--b1)'}}>
          <div>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:4}}>
              <div style={{width:30,height:30,background:'var(--lime-g)',border:'1px solid rgba(57,255,20,.3)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:14,clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)'}}>π</div>
              <div style={{fontFamily:'var(--fh)',fontSize:'1.2rem',fontWeight:700,color:'var(--lime)',textTransform:'uppercase',letterSpacing:2,textShadow:'0 0 12px rgba(57,255,20,.3)'}}>
                Abonnement Pi Network
              </div>
            </div>
            <div style={{fontSize:11,color:'var(--tx4)',fontFamily:'var(--fm)',letterSpacing:'1.5px'}}>
              {currentPlan!=='none' ? `Plan actuel : ${currentPlan.toUpperCase()} · Renouveler ou changer` : 'Choisissez votre plan'}
            </div>
          </div>
          <button onClick={onClose} style={{background:'var(--cosmos)',border:'1px solid var(--b2)',color:'var(--tx3)',cursor:'pointer',width:26,height:26,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,flexShrink:0}}>✕</button>
        </div>

        {/* ── ÉTAPE : CHOIX DU PLAN ── */}
        {step==='plans'&&(
          <>
            <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:12,marginBottom:20}}>
              {Object.values(PI_PLANS).map(plan=>(
                <div key={plan.id} onClick={()=>setSelected(plan.id)} style={{
                  background: selected===plan.id ? 'rgba(57,255,20,.06)' : 'rgba(11,26,53,.6)',
                  border: selected===plan.id ? '1px solid rgba(57,255,20,.4)' : '1px solid var(--b2)',
                  padding:'16px 14px',cursor:'pointer',transition:'all .2s',
                  clipPath:'polygon(0 0,calc(100% - 12px) 0,100% 12px,100% 100%,12px 100%,0 calc(100% - 12px))',
                  boxShadow: selected===plan.id ? '0 0 20px rgba(57,255,20,.08)' : 'none',
                }}>
                  {plan.recommended&&(
                    <div style={{fontSize:8,fontFamily:'var(--fm)',letterSpacing:'2px',textTransform:'uppercase',color:'var(--lime)',marginBottom:6,
                      padding:'2px 7px',background:'var(--lime-g)',border:'1px solid rgba(57,255,20,.2)',
                      clipPath:'polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px)',
                      display:'inline-block'}}>Recommandé</div>
                  )}
                  <div style={{fontFamily:'var(--fh)',fontSize:'1.1rem',fontWeight:700,color:selected===plan.id?'var(--lime)':'var(--tx)',textTransform:'uppercase',letterSpacing:1,marginBottom:2}}>
                    {plan.label}
                  </div>
                  <div style={{display:'flex',alignItems:'baseline',gap:4,marginBottom:12}}>
                    <span style={{fontFamily:'var(--fh)',fontSize:'1.8rem',fontWeight:700,color:selected===plan.id?'var(--lime)':'var(--tx)',textShadow:selected===plan.id?'0 0 10px rgba(57,255,20,.3)':'none'}}>
                      {plan.pi}
                    </span>
                    <span style={{fontFamily:'var(--fm)',fontSize:12,color:'var(--tx3)'}}>π / mois</span>
                  </div>
                  <div style={{borderTop:'1px solid var(--b1)',paddingTop:10}}>
                    {plan.features.map((f,i)=>(
                      <div key={i} style={{display:'flex',alignItems:'center',gap:6,padding:'3px 0',fontSize:10.5,color:'var(--tx2)',fontFamily:'var(--fb)'}}>
                        <span style={{color:selected===plan.id?'var(--lime)':'var(--b4)',fontSize:10}}>✓</span>
                        {f}
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Note sur la valeur FCFA */}
            <div style={{background:'rgba(0,229,255,.05)',border:'1px solid rgba(0,229,255,.12)',padding:'10px 14px',marginBottom:20,fontSize:12,color:'var(--tx2)',lineHeight:1.7,
              clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))'}}>
              <span style={{color:'var(--cyan)',fontFamily:'var(--fm)',fontSize:10,textTransform:'uppercase',letterSpacing:'1.5px'}}>Note Pi Network </span><br/>
              Le paiement s'effectue via votre wallet Pi. La valeur cible est <strong style={{color:'var(--tx)'}}>3 000–7 000 FCFA/mois</strong> pour le plan Business, selon le taux de migration Pi. Votre abonnement est valable <strong style={{color:'var(--tx)'}}>30 jours</strong> à compter du paiement.
            </div>

            <div style={{display:'flex',justifyContent:'flex-end',gap:10}}>
              <button onClick={onClose} style={{padding:'8px 18px',background:'transparent',border:'1px solid var(--b3)',color:'var(--tx2)',fontFamily:'var(--fh)',fontSize:11,cursor:'pointer',textTransform:'uppercase',letterSpacing:'2px',clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)'}}>
                Annuler
              </button>
              <button onClick={startPayment} style={{padding:'9px 22px',background:'var(--lime-g)',border:'1px solid rgba(57,255,20,.4)',color:'var(--lime)',fontFamily:'var(--fh)',fontSize:12,cursor:'pointer',textTransform:'uppercase',letterSpacing:'2px',clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)',boxShadow:'0 0 15px rgba(57,255,20,.15)',fontWeight:600}}>
                Payer {PI_PLANS[selected].pi}π avec Pi →
              </button>
            </div>
          </>
        )}

        {/* ── ÉTAPE : PAIEMENT EN COURS ── */}
        {step==='paying'&&(
          <div style={{textAlign:'center',padding:'40px 20px'}}>
            {/* Spinner Pi */}
            <div style={{width:72,height:72,margin:'0 auto 24px',position:'relative'}}>
              <div style={{position:'absolute',inset:0,border:'2px solid transparent',borderTopColor:'var(--lime)',borderRadius:'50%',animation:'spin 1s linear infinite'}}/>
              <div style={{position:'absolute',inset:8,border:'2px solid transparent',borderTopColor:'var(--cyan)',borderRadius:'50%',animation:'spin .7s linear infinite reverse'}}/>
              <div style={{position:'absolute',inset:0,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'var(--fh)',fontSize:22,fontWeight:700,color:'var(--lime)'}}>π</div>
            </div>
            <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>

            <div style={{fontFamily:'var(--fh)',fontSize:'1.2rem',fontWeight:700,color:'var(--tx)',textTransform:'uppercase',letterSpacing:2,marginBottom:10}}>
              Paiement en cours
            </div>
            <div style={{fontSize:12,color:'var(--tx3)',fontFamily:'var(--fm)',letterSpacing:'1px',marginBottom:24}}>
              {piStatus || 'En attente de confirmation Pi Network...'}
            </div>

            {/* Étapes visuelles */}
            <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:6,flexWrap:'wrap'}}>
              {[
                ['Wallet Pi ouvert','var(--lime)'],
                ['Approbation','var(--cyan)'],
                ['Blockchain','var(--tx3)'],
                ['Activation','var(--tx3)'],
              ].map(([lbl,col],i)=>(
                <div key={i} style={{display:'flex',alignItems:'center',gap:6}}>
                  <div style={{padding:'4px 10px',background:'rgba(255,255,255,.04)',border:`1px solid ${col}`,color:col,fontSize:9,fontFamily:'var(--fm)',letterSpacing:'1.5px',textTransform:'uppercase',
                    clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)',opacity:piStatus.includes(lbl.split(' ')[0].toLowerCase())?1:.4}}>
                    {lbl}
                  </div>
                  {i<3&&<span style={{color:'var(--b3)',fontSize:12}}>→</span>}
                </div>
              ))}
            </div>

            <div style={{marginTop:28,fontSize:11,color:'var(--tx4)',fontFamily:'var(--fm)'}}>
              Ne fermez pas cette fenêtre. La transaction est en cours de validation sur la blockchain Pi.
            </div>
          </div>
        )}

        {/* ── ÉTAPE : SUCCÈS ── */}
        {step==='success'&&(
          <div style={{textAlign:'center',padding:'40px 20px'}}>
            <div style={{width:70,height:70,margin:'0 auto 20px',background:'var(--lime-g)',border:'2px solid rgba(57,255,20,.4)',
              clipPath:'polygon(10px 0%,100% 0%,100% calc(100% - 10px),calc(100% - 10px) 100%,0% 100%,0% 10px)',
              display:'flex',alignItems:'center',justifyContent:'center',fontSize:28,color:'var(--lime)',
              boxShadow:'0 0 30px rgba(57,255,20,.25)',animation:'glow-in .5s ease'}}>
              ✓
            </div>
            <style>{`@keyframes glow-in{from{opacity:0;transform:scale(.8)}to{opacity:1;transform:scale(1)}}`}</style>

            <div style={{fontFamily:'var(--fh)',fontSize:'1.4rem',fontWeight:700,color:'var(--lime)',textTransform:'uppercase',letterSpacing:2,marginBottom:6,textShadow:'0 0 20px rgba(57,255,20,.4)'}}>
              Abonnement activé
            </div>
            <div style={{fontSize:13,color:'var(--tx2)',marginBottom:6}}>
              Plan <strong style={{color:'var(--tx)'}}>{PI_PLANS[selected].label}</strong> · 30 jours
            </div>
            {txid&&(
              <div style={{fontSize:10,color:'var(--tx4)',fontFamily:'var(--fm)',letterSpacing:'1px',marginBottom:20}}>
                TX: {txid.slice(0,16)}...{txid.slice(-8)}
              </div>
            )}
            <div style={{fontSize:12,color:'var(--tx3)',fontFamily:'var(--fm)'}}>
              Redirection en cours...
            </div>
          </div>
        )}

        {/* ── ÉTAPE : ERREUR ── */}
        {step==='error'&&(
          <div style={{textAlign:'center',padding:'32px 20px'}}>
            <div style={{fontSize:36,marginBottom:16,color:'var(--red2)'}}>⚠</div>
            <div style={{fontFamily:'var(--fh)',fontSize:'1.1rem',fontWeight:700,color:'var(--red2)',textTransform:'uppercase',letterSpacing:2,marginBottom:10}}>
              Paiement non complété
            </div>
            <div style={{fontSize:12,color:'var(--tx3)',fontFamily:'var(--fm)',marginBottom:24,lineHeight:1.7}}>
              {errMsg}
            </div>
            <div style={{display:'flex',gap:10,justifyContent:'center'}}>
              <button onClick={()=>{setStep('plans');setErrMsg('');}} style={{padding:'8px 18px',background:'transparent',border:'1px solid var(--b3)',color:'var(--tx2)',fontFamily:'var(--fh)',fontSize:11,cursor:'pointer',textTransform:'uppercase',letterSpacing:'2px',clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)'}}>
                ← Réessayer
              </button>
              <button onClick={onClose} style={{padding:'8px 18px',background:'var(--red-g)',border:'1px solid rgba(255,23,68,.3)',color:'var(--red2)',fontFamily:'var(--fh)',fontSize:11,cursor:'pointer',textTransform:'uppercase',letterSpacing:'2px',clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)'}}>
                Fermer
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
