import { useState } from 'react';
import {
  exportBilan, exportCompteResultat, exportBalance,
  exportJournal, exportFacture, exportBulletin,
  exportDeclarationTVA, exportAllDocuments,
} from '../lib/pdfExport.js';

// ═══════════════════════════════════════════════════════════════
//  GESTIONNAIRE D'EXPORT PDF
//  Panneau central pour télécharger tous les états financiers
// ═══════════════════════════════════════════════════════════════
export default function ExportManager({ state, onClose }) {
  const { config, factures, bulletins, declarationsTVA } = state;
  const [loading, setLoading] = useState('');
  const [done, setDone]       = useState([]);
  const annee = config.exercice?.debut ? new Date(config.exercice.debut).getFullYear() : new Date().getFullYear();

  const run = async (key, fn) => {
    setLoading(key);
    try {
      await new Promise(r => setTimeout(r, 100)); // micro-tick pour l'UI
      fn();
      setDone(prev => [...prev, key]);
    } catch (e) {
      console.error('Export error:', e);
    } finally {
      setLoading('');
    }
  };

  const allExports = async () => {
    setLoading('all');
    await exportAllDocuments(state);
    setDone(['bilan','resultat','balance','journal']);
    setLoading('');
  };

  const DOCS = [
    {
      group: 'États Financiers',
      items: [
        { key:'bilan',    icon:'📊', label:'Bilan Actif & Passif', sub:`Exercice ${annee} · OHADA/PCG`, fn:()=>exportBilan(state) },
        { key:'resultat', icon:'📈', label:'Compte de Résultat',   sub:`Exercice ${annee} · Avec SIG`,  fn:()=>exportCompteResultat(state) },
        { key:'balance',  icon:'⚖️', label:'Balance Générale',     sub:`${state.comptes?.length||0} comptes`, fn:()=>exportBalance(state) },
        { key:'journal',  icon:'📒', label:'Journal Comptable',    sub:`${state.ecritures?.length||0} écritures`, fn:()=>exportJournal(state, null) },
      ],
    },
    {
      group: 'Journaux par type',
      items: [
        { key:'j-vt',   icon:'🧾', label:'Journal Ventes (VT)',   sub:'Toutes les factures', fn:()=>exportJournal(state,'VT') },
        { key:'j-ac',   icon:'🛒', label:'Journal Achats (AC)',   sub:'Toutes les commandes', fn:()=>exportJournal(state,'AC') },
        { key:'j-bq',   icon:'🏦', label:'Journal Banque (BQ)',   sub:'Opérations bancaires', fn:()=>exportJournal(state,'BQ') },
        { key:'j-paie', icon:'💵', label:'Journal Paie (PAIE)',   sub:'Bulletins comptabilisés', fn:()=>exportJournal(state,'PAIE') },
        { key:'j-od',   icon:'✍️', label:'Journal OD',            sub:'Opérations diverses', fn:()=>exportJournal(state,'OD') },
      ],
    },
    {
      group: 'Fiscalité',
      items: declarationsTVA?.length > 0
        ? declarationsTVA.map(d => ({
            key:  'tva-'+d.periode,
            icon: '🧮',
            label: `Déclaration TVA ${d.periode}`,
            sub:   `${d.statut} · ${d.ref || ''}`,
            fn:   () => exportDeclarationTVA(d, state),
          }))
        : [{ key:'notva', icon:'🧮', label:'Aucune déclaration TVA', sub:'Créer dans le module TVA', fn:null }],
    },
    {
      group: 'Paie',
      items: bulletins?.length > 0
        ? [...new Set(bulletins.map(b => b.mois))].sort().reverse().slice(0, 6).map(mois => ({
            key:  'bul-'+mois,
            icon: '📋',
            label: `Bulletins de paie ${mois}`,
            sub:   `${bulletins.filter(b=>b.mois===mois).length} bulletin(s)`,
            fn: () => {
              const moisBulletins = bulletins.filter(b => b.mois === mois);
              moisBulletins.forEach((b, i) =>
                setTimeout(() => exportBulletin(b, state), i * 500)
              );
            },
          }))
        : [{ key:'nopay', icon:'📋', label:'Aucun bulletin de paie', sub:'Créer dans le module Paie', fn:null }],
    },
    {
      group: 'Facturation',
      items: factures?.length > 0
        ? [...factures].reverse().slice(0, 8).map(f => {
            const cli = state.clients?.find(c => c.id === f.clientId);
            return {
              key:  'fac-'+f.id,
              icon: '🧾',
              label: `${f.numero}`,
              sub:   `${cli?.nom || 'Client'} · ${new Date(f.date).toLocaleDateString('fr-FR')}`,
              badge: f.statut,
              fn:   () => exportFacture(f, state),
            };
          })
        : [{ key:'nofac', icon:'🧾', label:'Aucune facture', sub:'Créer dans le module Facturation', fn:null }],
    },
  ];

  return (
    <div style={{position:'fixed',inset:0,background:'rgba(2,8,16,.88)',backdropFilter:'blur(10px)',zIndex:300,display:'flex',alignItems:'center',justifyContent:'center',padding:16}}>
      <div style={{
        background:'rgba(11,26,53,.97)',border:'1px solid var(--b3)',
        width:'100%',maxWidth:760,maxHeight:'92vh',
        display:'flex',flexDirection:'column',
        clipPath:'polygon(0 0,calc(100% - 20px) 0,100% 20px,100% 100%,20px 100%,0 calc(100% - 20px))',
        backdropFilter:'blur(24px)',
        boxShadow:'0 0 60px rgba(57,255,20,.04),0 20px 60px rgba(0,0,0,.8)',
        position:'relative',
      }}>
        {/* Bande décorative */}
        <div style={{position:'absolute',top:0,right:20,left:0,height:2,background:'linear-gradient(90deg,transparent,var(--lime),var(--cyan),transparent)'}}/>

        {/* Header */}
        <div style={{padding:'20px 24px 16px',borderBottom:'1px solid var(--b1)',display:'flex',alignItems:'center',justifyContent:'space-between',flexShrink:0}}>
          <div>
            <div style={{fontFamily:'var(--fh)',fontSize:'1.15rem',fontWeight:700,color:'var(--tx)',textTransform:'uppercase',letterSpacing:2,display:'flex',alignItems:'center',gap:10}}>
              <span style={{fontSize:18}}>📥</span>
              Export des États Financiers
            </div>
            <div style={{fontSize:10,color:'var(--tx4)',fontFamily:'var(--fm)',letterSpacing:'1.5px',marginTop:3}}>
              {config.nomEntreprise} · Exercice {annee} · Plan {config.planComptable}
            </div>
          </div>
          <div style={{display:'flex',gap:8,alignItems:'center'}}>
            {/* Bouton tout exporter */}
            <button onClick={allExports} disabled={!!loading} style={{
              padding:'7px 16px',background:'var(--lime-g)',border:'1px solid rgba(57,255,20,.35)',
              color:'var(--lime)',fontFamily:'var(--fh)',fontSize:10,cursor:loading?'wait':'pointer',
              textTransform:'uppercase',letterSpacing:'2px',opacity:loading?.6:1,
              clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)',
            }}>
              {loading==='all' ? '⏳ Export...' : '↓ Tout exporter'}
            </button>
            <button onClick={onClose} style={{background:'var(--cosmos)',border:'1px solid var(--b2)',color:'var(--tx3)',cursor:'pointer',width:28,height:28,display:'flex',alignItems:'center',justifyContent:'center',fontSize:13}}>✕</button>
          </div>
        </div>

        {/* Contenu scrollable */}
        <div style={{overflowY:'auto',padding:'16px 24px',flex:1}}>
          {DOCS.map(group => (
            <div key={group.group} style={{marginBottom:20}}>
              <div style={{fontSize:9,fontFamily:'var(--fm)',color:'var(--tx4)',letterSpacing:'3px',textTransform:'uppercase',marginBottom:8,paddingBottom:4,borderBottom:'1px solid var(--b1)'}}>
                {group.group}
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                {group.items.map(item => {
                  const isDone    = done.includes(item.key);
                  const isLoading = loading === item.key;
                  const isDisabled = !item.fn;

                  return (
                    <div key={item.key}
                      onClick={()=> item.fn && !loading && run(item.key, item.fn)}
                      style={{
                        display:'flex',alignItems:'center',gap:12,padding:'10px 14px',
                        background: isDone ? 'rgba(57,255,20,.06)' : 'rgba(11,26,53,.6)',
                        border: isDone ? '1px solid rgba(57,255,20,.3)' : '1px solid var(--b2)',
                        cursor: isDisabled ? 'default' : isLoading ? 'wait' : 'pointer',
                        opacity: isDisabled ? 0.4 : isLoading ? 0.7 : 1,
                        transition:'all .15s',
                        clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))',
                      }}
                      onMouseEnter={e=>{ if(!isDisabled&&!loading) e.currentTarget.style.borderColor='rgba(57,255,20,.4)'; }}
                      onMouseLeave={e=>{ e.currentTarget.style.borderColor = isDone?'rgba(57,255,20,.3)':'var(--b2)'; }}
                    >
                      {/* Icône */}
                      <div style={{width:32,height:32,flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',fontSize:15,
                        background: isDone?'var(--lime-g)':'var(--cosmos)',border:`1px solid ${isDone?'rgba(57,255,20,.2)':'var(--b2)'}`,
                        clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)'}}>
                        {isLoading ? <span style={{animation:'spin .8s linear infinite',display:'inline-block'}}>⟳</span> : isDone ? <span style={{color:'var(--lime)'}}>✓</span> : item.icon}
                      </div>

                      {/* Texte */}
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontSize:12.5,fontWeight:500,color:isDone?'var(--lime)':'var(--tx)',fontFamily:'var(--fb)',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>
                          {item.label}
                        </div>
                        <div style={{fontSize:10,color:'var(--tx4)',fontFamily:'var(--fm)',marginTop:1}}>
                          {item.sub}
                        </div>
                      </div>

                      {/* Statut badge */}
                      {item.badge && (
                        <div style={{fontSize:8,fontFamily:'var(--fm)',letterSpacing:'1px',textTransform:'uppercase',padding:'2px 6px',
                          background:item.badge==='payée'?'var(--lime-g)':item.badge==='en attente'?'var(--amber-g)':'var(--red-g)',
                          color:item.badge==='payée'?'var(--lime)':item.badge==='en attente'?'var(--amber2)':'var(--red2)',
                          border:`1px solid ${item.badge==='payée'?'rgba(57,255,20,.2)':item.badge==='en attente'?'rgba(255,171,0,.2)':'rgba(255,23,68,.2)'}`,
                          clipPath:'polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px)',flexShrink:0}}>
                          {item.badge}
                        </div>
                      )}

                      {/* Flèche download */}
                      {!isDisabled && !isDone && !isLoading && (
                        <div style={{color:'var(--tx4)',fontSize:12,flexShrink:0}}>↓</div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{padding:'10px 24px',borderTop:'1px solid var(--b1)',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{fontSize:9.5,color:'var(--tx4)',fontFamily:'var(--fm)'}}>
            {done.length > 0 ? `${done.length} document(s) téléchargé(s)` : 'Cliquer sur un document pour le télécharger en PDF'}
          </div>
          <div style={{fontSize:9,color:'var(--tx4)',fontFamily:'var(--fm)',letterSpacing:'1px'}}>
            FORMAT A4 · jsPDF
          </div>
        </div>
        <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      </div>
    </div>
  );
}
