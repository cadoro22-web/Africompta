// ─── BADGE PI DANS LA SIDEBAR ────────────────────────────────
// À intégrer dans AppAccounting.jsx en bas de la sidebar

export default function PiBadge({ subscription, onSubscribe, piReady }) {
  if (!subscription) {
    return (
      <div onClick={onSubscribe} style={{
        cursor:'pointer',
        background:'rgba(57,255,20,.05)',
        border:'1px solid rgba(57,255,20,.2)',
        padding:'10px 12px',marginBottom:8,
        clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))',
        transition:'all .15s',
      }}
      onMouseEnter={e=>e.currentTarget.style.borderColor='rgba(57,255,20,.4)'}
      onMouseLeave={e=>e.currentTarget.style.borderColor='rgba(57,255,20,.2)'}
      >
        <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:4}}>
          <span style={{fontFamily:'var(--fh)',fontSize:14,color:'var(--lime)'}}>π</span>
          <span style={{fontFamily:'var(--fm)',fontSize:9,color:'var(--lime)',letterSpacing:'1.5px',textTransform:'uppercase'}}>Mode Gratuit</span>
        </div>
        <div style={{fontSize:10,color:'var(--tx3)',lineHeight:1.5}}>
          Activer un abonnement Pi pour l'accès complet
        </div>
        <div style={{marginTop:6,fontSize:9,fontFamily:'var(--fm)',color:'var(--lime)',letterSpacing:'1px',textTransform:'uppercase'}}>
          → S'abonner dès 5π/mois
        </div>
      </div>
    );
  }

  const daysLeft = Math.max(0, Math.ceil(
    (new Date(subscription.expiresAt || subscription.expires_at) - Date.now()) / 86400000
  ));
  const isExpiringSoon = daysLeft <= 7;
  const color = isExpiringSoon ? 'var(--amber)' : 'var(--lime)';
  const colorBg = isExpiringSoon ? 'rgba(255,171,0,.08)' : 'rgba(57,255,20,.05)';
  const colorBorder = isExpiringSoon ? 'rgba(255,171,0,.25)' : 'rgba(57,255,20,.2)';

  return (
    <div style={{
      background:colorBg,border:`1px solid ${colorBorder}`,
      padding:'10px 12px',marginBottom:8,
      clipPath:'polygon(0 0,calc(100% - 8px) 0,100% 8px,100% 100%,8px 100%,0 calc(100% - 8px))',
    }}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:3}}>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <span style={{fontFamily:'var(--fh)',fontSize:13,color}}>π</span>
          <span style={{fontFamily:'var(--fm)',fontSize:9,color,letterSpacing:'1.5px',textTransform:'uppercase'}}>
            {(subscription.plan || 'starter').toUpperCase()}
          </span>
        </div>
        <span style={{fontSize:9,fontFamily:'var(--fm)',color,letterSpacing:'1px'}}>
          {daysLeft}j
        </span>
      </div>

      {/* Barre de progression */}
      <div style={{height:2,background:'var(--b1)',marginBottom:5,overflow:'hidden'}}>
        <div style={{height:'100%',background:color,width:`${Math.min(100,(daysLeft/30)*100)}%`,transition:'width .4s',boxShadow:`0 0 4px ${color}`}}/>
      </div>

      {isExpiringSoon ? (
        <div onClick={onSubscribe} style={{fontSize:9,color:'var(--amber)',fontFamily:'var(--fm)',cursor:'pointer',textTransform:'uppercase',letterSpacing:'1px'}}>
          ⚠ Expire bientôt — Renouveler →
        </div>
      ) : (
        <div style={{fontSize:9,color:'var(--tx4)',fontFamily:'var(--fm)'}}>
          Expire dans {daysLeft} jours
        </div>
      )}
    </div>
  );
}
