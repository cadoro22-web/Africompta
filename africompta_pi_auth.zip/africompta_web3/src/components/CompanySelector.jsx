import { useState } from 'react';
import { companiesApi, comptesApi } from '../lib/api.js';

// ─── SÉLECTEUR / CRÉATEUR D'ENTREPRISE ───────────────────────
export default function CompanySelector({ companies, subscription, user, onSelect, onCreated }) {
  const [modal, setModal]   = useState(false);
  const [loading, setLoad]  = useState(false);
  const [error, setError]   = useState('');
  const [form, setForm]     = useState({
    nomEntreprise: '', adresse: 'Cotonou, Bénin',
    telephone: '', email: '', rccm: '', ifu: '',
    planComptable: 'OHADA', devise: 'FCFA', tauxTVA: 18,
    exerciceDebut: '2025-01-01', exerciceFin: '2025-12-31',
  });

  // Limite selon plan
  const maxCompanies = { starter:1, business:1, enterprise:5 }[subscription?.plan || 'starter'];
  const canCreate = companies.length < maxCompanies;

  const createCompany = async () => {
    if (!form.nomEntreprise.trim()) { setError('Le nom de l\'entreprise est requis'); return; }
    setLoad(true); setError('');
    try {
      const { data, error: err } = await companiesApi.create({
        ownerId: user.id,
        nomEntreprise: form.nomEntreprise,
        adresse: form.adresse,
        telephone: form.telephone,
        email: form.email,
        rccm: form.rccm,
        ifu: form.ifu,
        planComptable: form.planComptable,
        devise: form.devise,
        tauxTva: form.tauxTVA,
        exerciceDebut: form.exerciceDebut,
        exerciceFin: form.exerciceFin,
      });
      if (err) throw err;

      // Initialiser le plan comptable
      await comptesApi.seed(data.id, form.planComptable);

      setModal(false);
      onCreated(data);
    } catch (e) {
      setError(e.message || 'Erreur lors de la création');
    } finally {
      setLoad(false);
    }
  };

  return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh',background:'var(--void)',position:'relative',zIndex:1,padding:20}}>
      <div style={{width:'100%',maxWidth:760}}>

        {/* Header */}
        <div style={{textAlign:'center',marginBottom:32}}>
          <div style={{fontFamily:'var(--fh)',fontSize:'2rem',fontWeight:700,color:'var(--tx)',letterSpacing:3,textTransform:'uppercase'}}>
            Afri<span style={{color:'var(--cyan)'}}>compta</span>
          </div>
          <div style={{fontSize:11,color:'var(--tx3)',fontFamily:'var(--fm)',letterSpacing:'2px',marginTop:6,textTransform:'uppercase'}}>
            Sélectionnez ou créez votre entreprise
          </div>
        </div>

        {/* Statut abonnement */}
        <div style={{
          display:'flex',alignItems:'center',justifyContent:'space-between',
          padding:'10px 16px',marginBottom:20,
          background:'rgba(0,229,255,.05)',border:'1px solid rgba(0,229,255,.15)',
          clipPath:'polygon(0 0,calc(100% - 10px) 0,100% 10px,100% 100%,10px 100%,0 calc(100% - 10px))',
        }}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <span style={{width:8,height:8,borderRadius:'50%',background:subscription?.status==='active'?'var(--lime)':'var(--red)',display:'inline-block',boxShadow:subscription?.status==='active'?'var(--glow-l)':'var(--glow-p)'}}/>
            <span style={{fontFamily:'var(--fm)',fontSize:11,color:'var(--tx2)',letterSpacing:'1px',textTransform:'uppercase'}}>
              Plan {(subscription?.plan || 'Starter').toUpperCase()} · {companies.length}/{maxCompanies} entreprise(s)
            </span>
          </div>
          {subscription?.expiresAt && (
            <span style={{fontSize:10,color:'var(--tx4)',fontFamily:'var(--fm)'}}>
              Expire: {new Date(subscription.expiresAt).toLocaleDateString('fr-FR')}
            </span>
          )}
        </div>

        {/* Liste des entreprises */}
        <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(220px,1fr))',gap:14,marginBottom:14}}>
          {companies.map(co => (
            <div key={co.id} onClick={()=>onSelect(co)} style={{
              background:'rgba(11,26,53,.8)',border:'1px solid var(--b2)',padding:18,
              cursor:'pointer',transition:'all .2s',
              clipPath:'polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px))',
            }}
            onMouseEnter={e=>e.currentTarget.style.borderColor='var(--cyan2)'}
            onMouseLeave={e=>e.currentTarget.style.borderColor='var(--b2)'}
            >
              {/* Icône */}
              <div style={{
                width:40,height:40,marginBottom:12,
                background:'var(--cyan-g)',border:'1px solid var(--b3)',
                clipPath:'polygon(5px 0%,100% 0%,100% calc(100% - 5px),calc(100% - 5px) 100%,0% 100%,0% 5px)',
                display:'flex',alignItems:'center',justifyContent:'center',
                fontFamily:'var(--fh)',fontSize:16,fontWeight:700,color:'var(--cyan)',
              }}>
                {co.sigle || co.nomEntreprise.slice(0,2).toUpperCase()}
              </div>
              <div style={{fontFamily:'var(--fh)',fontSize:'1rem',fontWeight:600,color:'var(--tx)',textTransform:'uppercase',letterSpacing:1,marginBottom:4}}>
                {co.nomEntreprise}
              </div>
              <div style={{fontSize:10,color:'var(--tx3)',fontFamily:'var(--fm)',letterSpacing:'1px',marginBottom:4}}>
                {co.planComptable} · {co.devise}
              </div>
              {co.adresse && (
                <div style={{fontSize:11,color:'var(--tx4)',fontFamily:'var(--fm)'}}>{co.adresse}</div>
              )}
              <div style={{
                marginTop:10,padding:'3px 8px',display:'inline-flex',alignItems:'center',gap:6,
                background:'var(--cyan-g)',color:'var(--cyan)',border:'1px solid rgba(0,229,255,.2)',
                fontSize:9,fontFamily:'var(--fm)',letterSpacing:'2px',textTransform:'uppercase',
                clipPath:'polygon(2px 0%,100% 0%,100% calc(100% - 2px),calc(100% - 2px) 100%,0% 100%,0% 2px)',
              }}>
                → Ouvrir
              </div>
            </div>
          ))}

          {/* Bouton créer nouvelle entreprise */}
          {canCreate && (
            <div onClick={()=>setModal(true)} style={{
              background:'rgba(0,229,255,.03)',border:'1px dashed var(--b3)',padding:18,
              cursor:'pointer',transition:'all .2s',
              clipPath:'polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px))',
              display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:8,minHeight:140,
            }}
            onMouseEnter={e=>e.currentTarget.style.borderColor='var(--cyan2)'}
            onMouseLeave={e=>e.currentTarget.style.borderColor='var(--b3)'}
            >
              <div style={{fontSize:28,color:'var(--tx4)'}}>+</div>
              <div style={{fontFamily:'var(--fm)',fontSize:10,color:'var(--tx3)',letterSpacing:'2px',textTransform:'uppercase'}}>
                Nouvelle entreprise
              </div>
            </div>
          )}

          {/* Limite atteinte */}
          {!canCreate && (
            <div style={{
              background:'rgba(255,171,0,.04)',border:'1px solid rgba(255,171,0,.15)',padding:18,
              clipPath:'polygon(0 0,calc(100% - 14px) 0,100% 14px,100% 100%,14px 100%,0 calc(100% - 14px))',
              display:'flex',flexDirection:'column',justifyContent:'center',gap:6,minHeight:100,
            }}>
              <div style={{fontSize:11,color:'var(--amber2)',fontFamily:'var(--fm)',letterSpacing:'1px',textTransform:'uppercase'}}>
                Limite atteinte ({maxCompanies}/{maxCompanies})
              </div>
              <div style={{fontSize:11,color:'var(--tx3)'}}>
                Passez au plan Enterprise pour gérer jusqu'à 5 entreprises.
              </div>
            </div>
          )}
        </div>

        {/* MODAL CRÉATION ──────────────────────────────────────── */}
        {modal && (
          <div style={{position:'fixed',inset:0,background:'rgba(2,8,16,.85)',backdropFilter:'blur(8px)',zIndex:200,display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
            <div style={{
              background:'rgba(11,26,53,.97)',border:'1px solid var(--b3)',
              padding:'26px 28px',width:'100%',maxWidth:600,maxHeight:'90vh',overflowY:'auto',
              clipPath:'polygon(0 0,calc(100% - 18px) 0,100% 18px,100% 100%,18px 100%,0 calc(100% - 18px))',
              backdropFilter:'blur(24px)',boxShadow:'0 0 50px rgba(0,229,255,.06)',
              position:'relative',
            }}>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:20,paddingBottom:14,borderBottom:'1px solid var(--b1)'}}>
                <div style={{fontFamily:'var(--fh)',fontSize:'1.1rem',fontWeight:700,color:'var(--cyan)',textTransform:'uppercase',letterSpacing:'2px'}}>
                  Nouvelle entreprise
                </div>
                <button onClick={()=>setModal(false)} style={{background:'var(--cosmos)',border:'1px solid var(--b2)',color:'var(--tx3)',cursor:'pointer',width:26,height:26,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12}}>✕</button>
              </div>

              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
                {[
                  ['nomEntreprise','Nom de l\'entreprise *','text','Mon Entreprise SARL','full'],
                  ['adresse','Adresse','text','Cotonou, Bénin','full'],
                  ['telephone','Téléphone','text','+229 00 00 00 00',''],
                  ['email','Email','email','contact@entreprise.com',''],
                  ['rccm','RCCM','text','RB/COT/00/A/000',''],
                  ['ifu','IFU','text','0000000000000',''],
                ].map(([key,lbl,type,ph,full])=>(
                  <div key={key} style={{gridColumn:full==='full'?'1/-1':'auto'}}>
                    <label style={{display:'block',fontSize:9,color:'var(--tx3)',fontFamily:'var(--fm)',textTransform:'uppercase',letterSpacing:'2px',marginBottom:5}}>{lbl}</label>
                    <input
                      type={type} placeholder={ph}
                      value={form[key]} onChange={e=>setForm({...form,[key]:e.target.value})}
                      style={{display:'block',width:'100%',background:'var(--cosmos)',border:'1px solid var(--b2)',padding:'8px 11px',color:'var(--tx)',fontFamily:'var(--fm)',fontSize:12,outline:'none',clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)'}}
                    />
                  </div>
                ))}

                {/* Plan comptable */}
                <div>
                  <label style={{display:'block',fontSize:9,color:'var(--tx3)',fontFamily:'var(--fm)',textTransform:'uppercase',letterSpacing:'2px',marginBottom:5}}>Plan comptable</label>
                  <select value={form.planComptable} onChange={e=>setForm({...form,planComptable:e.target.value})}
                    style={{display:'block',width:'100%',background:'var(--cosmos)',border:'1px solid var(--b2)',padding:'8px 11px',color:'var(--tx)',fontFamily:'var(--fm)',fontSize:12,outline:'none',clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)'}}>
                    <option value="OHADA">OHADA (Bénin / Afrique)</option>
                    <option value="PCG">PCG (France)</option>
                  </select>
                </div>

                {/* Devise */}
                <div>
                  <label style={{display:'block',fontSize:9,color:'var(--tx3)',fontFamily:'var(--fm)',textTransform:'uppercase',letterSpacing:'2px',marginBottom:5}}>Devise</label>
                  <select value={form.devise} onChange={e=>setForm({...form,devise:e.target.value})}
                    style={{display:'block',width:'100%',background:'var(--cosmos)',border:'1px solid var(--b2)',padding:'8px 11px',color:'var(--tx)',fontFamily:'var(--fm)',fontSize:12,outline:'none',clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)'}}>
                    <option value="FCFA">FCFA — Franc CFA</option>
                    <option value="EUR">EUR — Euro</option>
                    <option value="USD">USD — Dollar</option>
                    <option value="GHS">GHS — Cedi</option>
                    <option value="NGN">NGN — Naira</option>
                  </select>
                </div>

                {/* Exercice */}
                <div>
                  <label style={{display:'block',fontSize:9,color:'var(--tx3)',fontFamily:'var(--fm)',textTransform:'uppercase',letterSpacing:'2px',marginBottom:5}}>Début exercice</label>
                  <input type="date" value={form.exerciceDebut} onChange={e=>setForm({...form,exerciceDebut:e.target.value})}
                    style={{display:'block',width:'100%',background:'var(--cosmos)',border:'1px solid var(--b2)',padding:'8px 11px',color:'var(--tx)',fontFamily:'var(--fm)',fontSize:12,outline:'none',clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)'}}/>
                </div>
                <div>
                  <label style={{display:'block',fontSize:9,color:'var(--tx3)',fontFamily:'var(--fm)',textTransform:'uppercase',letterSpacing:'2px',marginBottom:5}}>Fin exercice</label>
                  <input type="date" value={form.exerciceFin} onChange={e=>setForm({...form,exerciceFin:e.target.value})}
                    style={{display:'block',width:'100%',background:'var(--cosmos)',border:'1px solid var(--b2)',padding:'8px 11px',color:'var(--tx)',fontFamily:'var(--fm)',fontSize:12,outline:'none',clipPath:'polygon(3px 0%,100% 0%,100% calc(100% - 3px),calc(100% - 3px) 100%,0% 100%,0% 3px)'}}/>
                </div>
              </div>

              {error && (
                <div style={{marginTop:14,background:'rgba(255,23,68,.1)',border:'1px solid rgba(255,23,68,.3)',color:'#ff5252',padding:'8px 12px',fontSize:12,fontFamily:'var(--fm)'}}>
                  ⚠ {error}
                </div>
              )}

              <div style={{display:'flex',justifyContent:'flex-end',gap:10,marginTop:20,paddingTop:14,borderTop:'1px solid var(--b1)'}}>
                <button onClick={()=>setModal(false)} style={{padding:'7px 16px',background:'transparent',border:'1px solid var(--b3)',color:'var(--tx2)',fontFamily:'var(--fh)',fontSize:11,cursor:'pointer',textTransform:'uppercase',letterSpacing:'2px',clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)'}}>
                  Annuler
                </button>
                <button onClick={createCompany} disabled={loading} style={{padding:'7px 18px',background:'var(--cyan-g)',border:'1px solid var(--cyan2)',color:'var(--cyan)',fontFamily:'var(--fh)',fontSize:11,cursor:'pointer',textTransform:'uppercase',letterSpacing:'2px',clipPath:'polygon(4px 0%,100% 0%,100% calc(100% - 4px),calc(100% - 4px) 100%,0% 100%,0% 4px)',boxShadow:'0 0 10px rgba(0,229,255,.15)',opacity:loading?.6:1}}>
                  {loading ? 'Création...' : 'Créer l\'entreprise'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
