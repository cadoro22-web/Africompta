# Africompta Web3 — Guide d'installation Phase 2

## Architecture

```
Pi Browser / Navigateur web
       │
       ▼
┌─────────────────────────────┐
│  Africompta React (Vercel)  │
│                             │
│  AuthScreen (email/Pi)      │
│  CompanySelector            │
│  AppAccounting (NEXUS)      │
└──────────┬──────────────────┘
           │ Supabase JS SDK
           ▼
┌─────────────────────────────┐
│  Supabase (PostgreSQL)      │
│                             │
│  users                      │
│  subscriptions (Pi txid)    │
│  companies (multi-tenant)   │
│  ecritures, factures...     │
│  Row Level Security ✓       │
└─────────────────────────────┘
```

---

## Étape 1 — Créer le projet Supabase

1. Aller sur **https://app.supabase.com**
2. **New project** → nommer `africompta-prod`
3. Choisir région **Singapore** (proche Afrique de l'Ouest)
4. Mot de passe base de données → noter quelque part

---

## Étape 2 — Exécuter le schéma SQL

1. Dans Supabase → **SQL Editor**
2. Copier-coller le contenu de `supabase/schema.sql`
3. Cliquer **Run** → attendre `Success`

---

## Étape 3 — Récupérer les clés API

Dans Supabase → **Settings** → **API** :
- `Project URL` → copier dans `.env.local` : `VITE_SUPABASE_URL`
- `anon public` → copier dans `.env.local` : `VITE_SUPABASE_ANON_KEY`

---

## Étape 4 — Configurer l'authentification

Dans Supabase → **Authentication** → **Settings** :
- **Site URL** : `https://votre-domaine.vercel.app`
- **Redirect URLs** : ajouter `https://votre-domaine.vercel.app/**`
- Activer **Email provider** (confirmation email optionnelle pour les tests)

---

## Étape 5 — Intégrer AppWeb3 dans le projet

Remplacer dans `src/main.jsx` :

```jsx
// AVANT
import App from './App.jsx'
createRoot(document.getElementById('root')).render(<App />)

// APRÈS
import AppWeb3 from './AppWeb3.jsx'
createRoot(document.getElementById('root')).render(<AppWeb3 />)
```

Renommer l'actuel `App.jsx` en `AppAccounting.jsx` et modifier son export :

```jsx
// Dans AppAccounting.jsx — remplacer export default function App() {
export default function AppAccounting({ initialState, companyId, user, subscription, onLogout, onSwitchCompany }) {
  // Initialiser avec initialState au lieu de loadState()
  const [state, dispatch] = useReducer(reducer, initialState);
  // ... reste identique
```

---

## Étape 6 — Installer et lancer

```bash
cd africompta_web3
npm install
cp .env.local .env.local   # remplir les variables
npm run dev
# → http://localhost:5174
```

---

## Étape 7 — Déployer sur Vercel

```bash
npm install -g vercel
vercel deploy --prod
```

Dans le dashboard Vercel → **Settings** → **Environment Variables** :
- Ajouter `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY`

---

## Flux utilisateur complet

```
1. Utilisateur ouvre l'app
2. AuthScreen → inscription email ou magic link
3. Email de confirmation reçu → clic lien
4. Retour app → CompanySelector
5. Créer première entreprise (nom, RCCM, IFU, plan OHADA/PCG)
6. Plan comptable initialisé automatiquement
7. AppAccounting s'ouvre → saisie des écritures
8. [Phase 3] Paiement abonnement en Pi pour accès continu
9. Export PDF bilan/liasse depuis chaque module
```

---

## Limites par plan

| Plan       | Prix Pi/mois | Entreprises | Écritures  |
|------------|-------------|-------------|------------|
| Starter    | 5 π         | 1           | 200/mois   |
| Business   | 15 π        | 1           | Illimitées |
| Enterprise | 35 π        | 5           | Illimitées |

---

## Sécurité — Row Level Security

Chaque utilisateur ne peut accéder qu'à ses propres données grâce à RLS :

```sql
-- Exemple : un utilisateur ne voit que les écritures de ses entreprises
CREATE POLICY "company_isolation" ON public.ecritures
  USING (company_id IN (SELECT public.my_company_ids()));
```

Un utilisateur A ne peut jamais lire ou modifier les données de l'utilisateur B.

---

## Phase 3 — Pi Network (prochaine étape)

Une fois l'app déployée et fonctionnelle :

1. S'inscrire sur **developer.minepi.com**
2. Créer l'app `africompta`
3. Ajouter le Pi SDK dans `index.html`
4. Implémenter `Pi.authenticate()` et `Pi.createPayment()`
5. Webhook Supabase Edge Function pour valider les paiements Pi
